import { createFileRoute, Outlet, useRouterState } from "@tanstack/react-router";
import { AuthGateError, requireSignedIn } from "@/components/auth/AuthGate";
import AppShell from "@/components/layout/AppShell";

export const Route = createFileRoute("/_authed")({
  ssr: false,
  beforeLoad: requireSignedIn,
  errorComponent: AuthGateError,
  component: AuthedLayout,
});

const FULL_BLEED = ["/", "/onboarding"];

function AuthedLayout() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  if (FULL_BLEED.includes(pathname)) {
    return (
      <div className="min-h-dvh text-bgc-ink">
        <Outlet />
      </div>
    );
  }

  return (
    <AppShell>
      <Outlet />
    </AppShell>
  );
}