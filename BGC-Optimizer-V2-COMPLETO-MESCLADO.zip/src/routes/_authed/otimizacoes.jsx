const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { SlidersHorizontal, TriangleAlert } from "lucide-react";
import { toast } from "sonner";

import PageHeader from "@/components/glass/PageHeader";
import EmptyState from "@/components/glass/EmptyState";
import OptimizationCard from "@/components/optimizations/OptimizationCard";
import { CATEGORY_META } from "@/lib/constants";
import { logActivity, optimizationSettingsQuery, recommendationsQuery } from "@/lib/queries";
import { useEnsureProfiles } from "@/hooks/useProfiles";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authed/otimizacoes")({
  head: () => ({ meta: [{ title: "Otimizações · BGC Optimizer" }] }),
  component: OptimizationsPage,
});

const FILTERS = [
  { id: "all", label: "Todas" },
  { id: "recommended", label: "Recomendadas" },
  { id: "applied", label: "Aplicadas no app" },
  { id: "pending", label: "Pendentes" },
  { id: "incompatible", label: "Incompatíveis" },
];

function OptimizationsPage() {
  const queryClient = useQueryClient();
  const { data: settings = [], isLoading } = useQuery(optimizationSettingsQuery());
  const { data: recommendations = [] } = useQuery(recommendationsQuery());
  const { active } = useEnsureProfiles();

  const [filter, setFilter] = useState("all");
  const [category, setCategory] = useState("all");

  const appliedKeys = new Set(active?.settings ?? []);
  const recommendedKeys = new Set(recommendations.map((r) => r.linked_setting));

  const counts = useMemo(() => {
    const byCategory = {};
    settings.forEach((s) => {
      byCategory[s.category] = (byCategory[s.category] ?? 0) + 1;
    });
    return byCategory;
  }, [settings]);

  const list = useMemo(() => {
    return settings.filter((s) => {
      if (category !== "all" && s.category !== category) return false;
      const applied = appliedKeys.has(s.key);
      if (filter === "applied") return applied;
      if (filter === "pending") return !applied && !s.requires_agent;
      if (filter === "incompatible") return !!s.requires_agent;
      if (filter === "recommended") return recommendedKeys.has(s.key) || (s.recommended_for ?? []).includes(active?.kind);
      return true;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [settings, filter, category, active, recommendations]);

  const toggle = async (setting, nextApplied) => {
    if (!active) return;
    const current = active.settings ?? [];
    const nextSettings = nextApplied ? [...current, setting.key] : current.filter((k) => k !== setting.key);
    await db.entities.OptimizationProfile.update(active.id, { settings: nextSettings });
    await logActivity({
      action_type: "settings_applied",
      title: nextApplied ? `Ajuste marcado — ${setting.title}` : `Ajuste removido — ${setting.title}`,
      detail: `Perfil ativo: ${active.name}.`,
      entity_ref: active.id,
      entity_name: "OptimizationProfile",
      snapshot: { settings: current },
    });
    queryClient.invalidateQueries({ queryKey: ["optimization-profiles"] });
    queryClient.invalidateQueries({ queryKey: ["history"] });
    toast.success(nextApplied ? "Ajuste registrado no perfil ativo." : "Ajuste removido do perfil ativo.");
  };

  const incompatible = settings.filter((s) => s.requires_agent).length;

  return (
    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
      <PageHeader
        eyebrow="Otimizações"
        title="Central de otimizações"
        description="Cada ajuste com explicação, objetivo, compatibilidade, benefícios e riscos. Marcar como aplicada registra a decisão no seu perfil — não altera o Windows por aqui."
      />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        {Object.entries(CATEGORY_META).map(([key, meta]) => (
          <button
            key={key}
            type="button"
            onClick={() => setCategory(category === key ? "all" : key)}
            className={cn(
              "glass glass-hover rounded-glass p-4 text-left transition",
              category === key && "border-bgc-glow/40 shadow-[0_0_40px_-16px_rgba(57,255,136,0.85)]"
            )}
          >
            <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-bgc-dim">{meta.label}</p>
            <p className="mt-2 font-heading text-2xl font-semibold text-bgc-ink">{counts[key] ?? 0}</p>
            <p className="mt-0.5 text-[11px] text-bgc-dim">opções disponíveis</p>
          </button>
        ))}
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-2">
        {FILTERS.map((f) => (
          <button
            key={f.id}
            type="button"
            onClick={() => setFilter(f.id)}
            className={cn(
              "rounded-full border px-3.5 py-1.5 text-[11.5px] font-medium transition",
              filter === f.id
                ? "border-bgc-glow/45 bg-bgc-glow/10 text-bgc-glow"
                : "border-white/10 bg-white/[0.03] text-bgc-dim hover:border-white/25 hover:text-bgc-ink"
            )}
          >
            {f.label}
          </button>
        ))}
        {category !== "all" && (
          <button
            type="button"
            onClick={() => setCategory("all")}
            className="rounded-full border border-white/10 px-3 py-1.5 text-[11px] text-bgc-dim hover:text-bgc-ink"
          >
            Limpar categoria · {CATEGORY_META[category]?.label}
          </button>
        )}
        <span className="ml-auto inline-flex items-center gap-1.5 text-[11px] text-bgc-dim">
          <TriangleAlert className="h-3.5 w-3.5 text-amber-300" /> {incompatible} ajustes exigem o agente Windows
        </span>
      </div>

      <div className="mt-4 space-y-3">
        {isLoading ? (
          [0, 1, 2, 3].map((i) => <div key={i} className="glass h-24 animate-pulse" />)
        ) : list.length === 0 ? (
          <EmptyState
            icon={SlidersHorizontal}
            title="Nenhum ajuste neste filtro"
            description="Troque o filtro ou selecione outra categoria para ver mais opções."
          />
        ) : (
          list.map((setting) => (
            <OptimizationCard
              key={setting.key}
              setting={setting}
              applied={appliedKeys.has(setting.key)}
              recommended={recommendedKeys.has(setting.key) || (setting.recommended_for ?? []).includes(active?.kind)}
              onToggle={toggle}
            />
          ))
        )}
      </div>
    </div>
  );
}