const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { History, RotateCcw } from "lucide-react";
import { toast } from "sonner";

import PageHeader from "@/components/glass/PageHeader";
import EmptyState from "@/components/glass/EmptyState";
import { GlassPanel } from "@/components/glass/GlassPanel";
import StatusPill from "@/components/glass/StatusPill";
import { fmtDateTime } from "@/lib/format";
import { historyQuery } from "@/lib/queries";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authed/historico")({
  head: () => ({ meta: [{ title: "Histórico · BGC Optimizer" }] }),
  component: HistoryPage,
});

const GROUPS = {
  profile_created: "profiles",
  profile_updated: "profiles",
  profile_deleted: "profiles",
  settings_applied: "settings",
  game_added: "games",
  game_configured: "games",
  checklist_started: "games",
  checklist_completed: "games",
  session_recorded: "sessions",
  preferences_changed: "system",
  cleanup_logged: "system",
  hardware_updated: "system",
  onboarding_completed: "system",
};

const FILTERS = [
  { id: "all", label: "Tudo" },
  { id: "profiles", label: "Perfis" },
  { id: "settings", label: "Ajustes" },
  { id: "games", label: "Jogos" },
  { id: "sessions", label: "Sessões" },
  { id: "system", label: "Sistema" },
];

const UNDOABLE = ["settings_applied", "profile_updated"];

function HistoryPage() {
  const queryClient = useQueryClient();
  const { data: history = [], isLoading } = useQuery(historyQuery());
  const [filter, setFilter] = useState("all");

  const list = history.filter((item) => filter === "all" || GROUPS[item.action_type] === filter);

  const undo = async (item) => {
    const snapshot = item.snapshot ? JSON.parse(item.snapshot) : null;
    if (!snapshot || !item.entity_ref) return;
    await db.entities.OptimizationProfile.update(item.entity_ref, { settings: snapshot.settings ?? [] });
    await db.entities.ActivityHistory.update(item.id, { undone: true });
    await logChange(item);
    queryClient.invalidateQueries({ queryKey: ["optimization-profiles"] });
    queryClient.invalidateQueries({ queryKey: ["history"] });
    toast.success("Alteração interna desfeita.");
  };

  const logChange = async (item) => {
    await db.entities.ActivityHistory.create({
      action_type: "preferences_changed",
      title: `Alteração desfeita — ${item.title}`,
      detail: "Ajustes internos restaurados para o estado anterior.",
      entity_ref: item.entity_ref ?? "",
      entity_name: item.entity_name ?? "",
      snapshot: "",
      undone: false,
    });
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
      <PageHeader
        eyebrow="Histórico"
        title="Tudo o que aconteceu, registrado"
        description="Perfis, ajustes, jogos, checklists e sessões. O desfazer restaura preferências internas do aplicativo — não altera configurações do Windows."
      />

      <div className="mb-5 flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <button
            key={f.id}
            type="button"
            onClick={() => setFilter(f.id)}
            className={cn(
              "rounded-full border px-3.5 py-1.5 text-[11.5px] font-medium transition",
              filter === f.id
                ? "border-bgc-glow/45 bg-bgc-glow/10 text-bgc-glow"
                : "border-white/10 bg-white/[0.03] text-bgc-dim hover:border-white/25 hover:text-bgc-ink"
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="glass h-52 animate-pulse" />
      ) : list.length === 0 ? (
        <EmptyState
          icon={History}
          title="Nenhum registro neste filtro"
          description="Suas ações no aplicativo aparecem aqui na ordem em que acontecem."
        />
      ) : (
        <GlassPanel className="p-5">
          <ol className="relative space-y-5 border-l border-white/[0.10] pl-5">
            {list.map((item) => (
              <li key={item.id} className="relative">
                <span
                  className={cn(
                    "absolute -left-[26px] top-1.5 h-2.5 w-2.5 rounded-full border",
                    item.undone
                      ? "border-white/25 bg-white/15"
                      : "border-bgc-glow/60 bg-bgc-glow shadow-[0_0_12px_2px_rgba(57,255,136,0.45)]"
                  )}
                />
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className={cn("text-[13px] font-medium", item.undone ? "text-bgc-dim line-through" : "text-bgc-ink")}>
                        {item.title}
                      </p>
                      {item.undone && <StatusPill tone="gray">desfeito</StatusPill>}
                    </div>
                    {item.detail && <p className="mt-0.5 text-[11.5px] leading-relaxed text-bgc-dim">{item.detail}</p>}
                    <p className="mt-1 text-[10px] uppercase tracking-wider text-bgc-dim/60">{fmtDateTime(item.created_date)}</p>
                  </div>
                  {item.snapshot && !item.undone && UNDOABLE.includes(item.action_type) && (
                    <button
                      type="button"
                      onClick={() => undo(item)}
                      className="inline-flex items-center gap-1.5 rounded-full border border-white/10 px-2.5 py-1 text-[10.5px] text-bgc-dim transition hover:border-bgc-glow/40 hover:text-bgc-glow"
                    >
                      <RotateCcw className="h-3 w-3" /> Desfazer
                    </button>
                  )}
                </div>
              </li>
            ))}
          </ol>
        </GlassPanel>
      )}
    </div>
  );
}