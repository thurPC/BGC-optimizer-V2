import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { ClipboardCheck, ShieldCheck } from "lucide-react";
import PageHeader from "@/components/glass/PageHeader";
import ActionButton from "@/components/glass/ActionButton";
import { GlassPanel } from "@/components/glass/GlassPanel";
import StatusPill from "@/components/glass/StatusPill";
import MaintenanceList from "@/components/cleanup/MaintenanceList";
import SpaceCard from "@/components/cleanup/SpaceCard";
import { usePreferences } from "@/lib/usePreferences";
import { computerQuery, historyQuery, logActivity, optimizationSettingsQuery } from "@/lib/queries";
import { fmtDateTime } from "@/lib/format";

export const Route = createFileRoute("/_authed/limpeza")({
  head: () => ({ meta: [{ title: "Limpeza e manutenção · BGC Optimizer" }] }),
  component: CleanupPage,
});

function CleanupPage() {
  const queryClient = useQueryClient();
  const { prefs, save } = usePreferences();
  const { data: computer } = useQuery(computerQuery());
  const { data: settings = [] } = useQuery(optimizationSettingsQuery());
  const { data: history = [] } = useQuery(historyQuery());

  const checks = prefs.maintenance_checks ?? [];
  const storageTips = settings.filter((s) => s.category === "storage");
  const cleanupHistory = history.filter((h) => h.action_type === "cleanup_logged").slice(0, 6);

  const toggle = async (id) => {
    const next = checks.includes(id) ? checks.filter((c) => c !== id) : [...checks, id];
    await save({ maintenance_checks: next });
  };

  const register = async () => {
    await logActivity({
      action_type: "cleanup_logged",
      title: "Rotina de manutenção registrada",
      detail: `${checks.length} itens concluídos no checklist de limpeza.`,
      entity_name: "MaintenanceChecklist",
    });
    queryClient.invalidateQueries({ queryKey: ["history"] });
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
      <PageHeader
        eyebrow="Limpeza e manutenção"
        title="Organize a rotina, sem riscos"
        description="Checklists e recomendações de armazenamento. O BGC Optimizer orienta e registra — nunca exclui arquivos pessoais nem executa limpeza no Windows."
        actions={
          <ActionButton size="sm" onClick={register}>
            <ClipboardCheck className="h-4 w-4" /> Registrar rotina
          </ActionButton>
        }
      />

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_340px]">
        <MaintenanceList checks={checks} onToggle={toggle} />

        <div className="space-y-4">
          <SpaceCard computer={computer} />

          <GlassPanel className="p-5">
            <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-bgc-dim">Recomendações de armazenamento</p>
            <div className="mt-3 space-y-2.5">
              {storageTips.map((tip) => (
                <div key={tip.key} className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-3">
                  <p className="text-[12px] font-medium text-bgc-ink">{tip.title}</p>
                  <p className="mt-0.5 text-[11px] leading-relaxed text-bgc-dim">{tip.summary}</p>
                </div>
              ))}
            </div>
          </GlassPanel>

          <GlassPanel className="p-5">
            <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-bgc-dim">Histórico de limpeza</p>
            <div className="mt-3 space-y-3">
              {cleanupHistory.length === 0 && (
                <p className="text-xs text-bgc-dim">Nenhuma rotina registrada ainda.</p>
              )}
              {cleanupHistory.map((item) => (
                <div key={item.id} className="border-l border-white/10 pl-3">
                  <p className="text-[12px] font-medium text-bgc-ink">{item.title}</p>
                  {item.detail && <p className="text-[11px] text-bgc-dim">{item.detail}</p>}
                  <p className="mt-0.5 text-[10px] uppercase tracking-wider text-bgc-dim/60">
                    {fmtDateTime(item.created_date)}
                  </p>
                </div>
              ))}
            </div>
          </GlassPanel>

          <div className="flex items-start gap-2 rounded-xl border border-white/[0.08] bg-white/[0.02] p-3">
            <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-bgc-glow" />
            <p className="text-[10.5px] leading-relaxed text-bgc-dim">
              Nenhum arquivo é apagado pelo aplicativo. Itens como temporários e lixeira são executados por você,
              no Windows, seguindo o checklist.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}