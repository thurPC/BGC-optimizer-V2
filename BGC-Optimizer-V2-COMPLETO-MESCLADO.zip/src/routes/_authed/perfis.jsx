const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { Layers, Plus } from "lucide-react";
import { toast } from "sonner";

import PageHeader from "@/components/glass/PageHeader";
import ActionButton from "@/components/glass/ActionButton";
import EmptyState from "@/components/glass/EmptyState";
import ProfileCard from "@/components/profiles/ProfileCard";
import ProfileDialog from "@/components/profiles/ProfileDialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useEnsureProfiles } from "@/hooks/useProfiles";
import { PROFILE_KINDS } from "@/lib/constants";
import { logActivity, optimizationSettingsQuery } from "@/lib/queries";

export const Route = createFileRoute("/_authed/perfis")({
  head: () => ({ meta: [{ title: "Perfis · BGC Optimizer" }] }),
  component: ProfilesPage,
});

function ProfilesPage() {
  const queryClient = useQueryClient();
  const { profiles, active, isLoading } = useEnsureProfiles();
  const { data: settings = [] } = useQuery(optimizationSettingsQuery());
  const [editing, setEditing] = useState(null);
  const [saving, setSaving] = useState(false);
  const [toDelete, setToDelete] = useState(null);

  const settingsMap = Object.fromEntries(settings.map((s) => [s.key, s.title]));

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["optimization-profiles"] });

  const save = async (data) => {
    setSaving(true);
    try {
      const payload = { ...data, accent: PROFILE_KINDS[data.kind]?.accent ?? "#22C55E" };
      if (editing?.id) {
        await db.entities.OptimizationProfile.update(editing.id, payload);
        await logActivity({
          action_type: "profile_updated",
          title: `Perfil atualizado — ${payload.name}`,
          detail: `${payload.settings.length} ajustes.`,
          entity_ref: editing.id,
          entity_name: "OptimizationProfile",
          snapshot: { settings: editing.settings ?? [] },
        });
      } else {
        await db.entities.OptimizationProfile.create({ ...payload, is_active: false, built_in: false });
        await logActivity({
          action_type: "profile_created",
          title: `Perfil criado — ${payload.name}`,
          detail: `${payload.settings.length} ajustes.`,
          entity_name: "OptimizationProfile",
        });
      }
      await refresh();
      queryClient.invalidateQueries({ queryKey: ["history"] });
      setEditing(null);
      toast.success("Perfil salvo.");
    } finally {
      setSaving(false);
    }
  };

  const activate = async (profile) => {
    await db.entities.OptimizationProfile.bulkUpdate(
      profiles.map((p) => ({ id: p.id, is_active: p.id === profile.id }))
    );
    await refresh();
    toast.success(`Perfil ${profile.name} ativado.`);
  };

  const duplicate = async (profile) => {
    await db.entities.OptimizationProfile.create({
      name: `${profile.name} (cópia)`,
      kind: profile.kind,
      description: profile.description,
      settings: profile.settings ?? [],
      is_active: false,
      built_in: false,
      accent: profile.accent,
    });
    await logActivity({
      action_type: "profile_created",
      title: `Perfil duplicado — ${profile.name}`,
      detail: "Cópia criada a partir de um perfil existente.",
      entity_name: "OptimizationProfile",
    });
    await refresh();
    queryClient.invalidateQueries({ queryKey: ["history"] });
    toast.success("Perfil duplicado.");
  };

  const remove = async () => {
    if (!toDelete) return;
    await db.entities.OptimizationProfile.delete(toDelete.id);
    await logActivity({
      action_type: "profile_deleted",
      title: `Perfil excluído — ${toDelete.name}`,
      entity_name: "OptimizationProfile",
    });
    await refresh();
    queryClient.invalidateQueries({ queryKey: ["history"] });
    setToDelete(null);
    toast.success("Perfil excluído.");
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
      <PageHeader
        eyebrow="Perfis de desempenho"
        title="Cada partida, um conjunto de ajustes"
        description="Perfis organizam quais configurações pertencem a cada cenário. O perfil ativo define o checklist padrão dos jogos."
        actions={
          <ProfileDialog
            settings={settings}
            trigger={
              <ActionButton size="sm">
                <Plus className="h-4 w-4" /> Novo perfil
              </ActionButton>
            }
            onSave={async (data) => {
              setEditing(null);
              await save(data);
            }}
            saving={saving}
          />
        }
      />

      {isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {[0, 1, 2].map((i) => (
            <div key={i} className="glass h-48 animate-pulse" />
          ))}
        </div>
      ) : profiles.length === 0 ? (
        <EmptyState icon={Layers} title="Nenhum perfil" description="Crie um perfil para organizar seus ajustes." />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {profiles.map((profile) => (
            <ProfileCard
              key={profile.id}
              profile={profile}
              settingsMap={settingsMap}
              onActivate={activate}
              onEdit={(p) => setEditing(p)}
              onDuplicate={duplicate}
              onDelete={(p) => setToDelete(p)}
            />
          ))}
        </div>
      )}

      {editing && (
        <ProfileDialog
          key={editing.id}
          profile={editing}
          settings={settings}
          onSave={save}
          saving={saving}
          open
          onOpenChange={(value) => !value && setEditing(null)}
        />
      )}

      <AlertDialog open={!!toDelete} onOpenChange={(open) => !open && setToDelete(null)}>
        <AlertDialogContent className="glass-strong border-white/12 bg-[#0A0F18]/96 text-bgc-ink">
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir {toDelete?.name}?</AlertDialogTitle>
            <AlertDialogDescription className="text-bgc-dim">
              O perfil será removido da sua conta. Jogos que usam esse perfil mantêm o próprio checklist.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-white/15 bg-transparent text-bgc-ink hover:bg-white/10">
              Cancelar
            </AlertDialogCancel>
            <AlertDialogAction onClick={remove} className="bg-red-500/90 text-white hover:bg-red-500">
              Excluir perfil
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <p className="mt-6 text-[11px] text-bgc-dim">
        Perfil ativo atual: <span className="text-bgc-ink">{active?.name ?? "—"}</span> · {active?.settings?.length ?? 0} ajustes
      </p>
    </div>
  );
}