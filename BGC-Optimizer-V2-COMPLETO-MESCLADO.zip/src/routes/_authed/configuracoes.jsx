import { createFileRoute, Link } from "@tanstack/react-router";
import { Bell, LogOut, Palette, ShieldCheck, UserRound } from "lucide-react";
import PageHeader from "@/components/glass/PageHeader";
import ActionButton from "@/components/glass/ActionButton";
import { GlassPanel } from "@/components/glass/GlassPanel";
import { ToggleRow } from "@/components/appearance/AppearanceControls";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { NOTIFICATION_CATEGORIES } from "@/lib/constants";
import { useAuth } from "@/lib/AuthContext";
import { usePreferences } from "@/lib/usePreferences";

export const Route = createFileRoute("/_authed/configuracoes")({
  head: () => ({ meta: [{ title: "Configurações · BGC Optimizer" }] }),
  component: SettingsPage,
});

function SettingsPage() {
  const { user, logout } = useAuth();
  const { prefs, save } = usePreferences();

  return (
    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
      <PageHeader
        eyebrow="Configurações"
        title="Preferências da conta"
        description="Notificações, conta e atalhos. As preferências de aparência ficam na área de personalização."
      />

      <div className="grid gap-5 lg:grid-cols-2">
        <GlassPanel className="p-5">
          <div className="flex items-center gap-2">
            <Bell className="h-4 w-4 text-bgc-glow" />
            <p className="font-heading text-sm font-semibold text-bgc-ink">Notificações</p>
          </div>
          <div className="mt-4 space-y-2">
            {NOTIFICATION_CATEGORIES.map((category) => (
              <ToggleRow
                key={category.id}
                label={category.label}
                checked={prefs[category.field] !== false}
                onChange={(value) => save({ [category.field]: value })}
              />
            ))}
            <div className="rounded-xl border border-white/[0.07] bg-white/[0.02] px-3 py-2.5">
              <p className="text-[12.5px] font-medium text-bgc-ink">Frequência</p>
              <Select
                value={prefs.notification_frequency}
                onValueChange={(value) => save({ notification_frequency: value })}
              >
                <SelectTrigger className="mt-2 h-9 border-white/10 bg-white/[0.04] text-bgc-ink">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="border-white/10 bg-[#0A0F18] text-bgc-ink">
                  <SelectItem value="realtime">Tempo real</SelectItem>
                  <SelectItem value="daily">Resumo diário</SelectItem>
                  <SelectItem value="weekly">Resumo semanal</SelectItem>
                  <SelectItem value="off">Desativadas</SelectItem>
                </SelectContent>
              </Select>
              <p className="mt-2 text-[10.5px] leading-relaxed text-bgc-dim">
                A frequência organiza como os avisos aparecem no app. Nenhum e-mail é enviado por aqui.
              </p>
            </div>
          </div>
        </GlassPanel>

        <div className="space-y-4">
          <GlassPanel className="p-5">
            <div className="flex items-center gap-2">
              <UserRound className="h-4 w-4 text-bgc-glow" />
              <p className="font-heading text-sm font-semibold text-bgc-ink">Conta</p>
            </div>
            <div className="mt-3 space-y-2 text-[13px]">
              <div className="flex items-center justify-between gap-3">
                <span className="text-bgc-dim">Nome</span>
                <span className="truncate text-bgc-ink">{user?.full_name || "—"}</span>
              </div>
              <div className="flex items-center justify-between gap-3">
                <span className="text-bgc-dim">E-mail</span>
                <span className="truncate text-bgc-ink">{user?.email}</span>
              </div>
              <div className="flex items-center justify-between gap-3">
                <span className="text-bgc-dim">Perfil de acesso</span>
                <span className="text-bgc-ink">{user?.role === "admin" ? "Administrador" : "Usuário"}</span>
              </div>
            </div>
            <Link to="/perfil" className="mt-4 inline-block">
              <ActionButton variant="secondary" size="sm">
                Editar perfil
              </ActionButton>
            </Link>
          </GlassPanel>

          <GlassPanel className="p-5">
            <div className="flex items-center gap-2">
              <Palette className="h-4 w-4 text-bgc-glow" />
              <p className="font-heading text-sm font-semibold text-bgc-ink">Aparência</p>
            </div>
            <p className="mt-2 text-[12px] leading-relaxed text-bgc-dim">
              Tema atual: <span className="text-bgc-ink">{prefs.theme}</span> · cor de destaque{" "}
              <span className="text-bgc-ink">{prefs.accent_color}</span>
            </p>
            <Link to="/personalizacao" className="mt-4 inline-block">
              <ActionButton variant="secondary" size="sm">
                Abrir personalização
              </ActionButton>
            </Link>
          </GlassPanel>

          {user?.role === "admin" && (
            <GlassPanel className="p-5">
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-bgc-glow" />
                <p className="font-heading text-sm font-semibold text-bgc-ink">Administração</p>
              </div>
              <p className="mt-2 text-[12px] text-bgc-dim">Gerencie usuários, jogos e recomendações.</p>
              <Link to="/admin" className="mt-4 inline-block">
                <ActionButton variant="secondary" size="sm">
                  Abrir painel administrativo
                </ActionButton>
              </Link>
            </GlassPanel>
          )}

          <GlassPanel className="p-5">
            <p className="font-heading text-sm font-semibold text-bgc-ink">Sessão</p>
            <p className="mt-2 text-[12px] text-bgc-dim">Sair encerra a sessão neste dispositivo.</p>
            <ActionButton variant="danger" size="sm" className="mt-3" onClick={() => logout()}>
              <LogOut className="h-3.5 w-3.5" /> Sair da conta
            </ActionButton>
          </GlassPanel>
        </div>
      </div>

      <p className="mt-6 text-[11px] text-bgc-dim/70">BGC Optimizer v1.0 · Aplicação web. Agente Windows em desenvolvimento.</p>
    </div>
  );
}