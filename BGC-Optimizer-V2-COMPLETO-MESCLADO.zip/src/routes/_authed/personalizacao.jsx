import { createFileRoute } from "@tanstack/react-router";
import { Palette, RotateCcw, Wind } from "lucide-react";
import { toast } from "sonner";
import PageHeader from "@/components/glass/PageHeader";
import ActionButton from "@/components/glass/ActionButton";
import { GlassPanel } from "@/components/glass/GlassPanel";
import {
  ColorRow,
  SliderRow,
  ThemeGrid,
  ToggleRow,
  WidgetPicker,
} from "@/components/appearance/AppearanceControls";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { appearanceDefaults, THEMES } from "@/lib/appearance";
import { usePreferences } from "@/lib/usePreferences";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authed/personalizacao")({
  head: () => ({ meta: [{ title: "Personalização · BGC Optimizer" }] }),
  component: PersonalizationPage,
});

const ACCENTS = ["#22C55E", "#39FF88", "#38BDF8", "#A78BFA", "#F43F5E", "#F59E0B"];

function PersonalizationPage() {
  const { prefs, save } = usePreferences();
  const set = (patch) => save(patch);

  const restore = async () => {
    await save(appearanceDefaults());
    toast.success("Aparência original restaurada.");
  };

  const toggleWidget = (id) => {
    const current = prefs.widgets ?? [];
    set({ widgets: current.includes(id) ? current.filter((w) => w !== id) : [...current, id] });
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
      <PageHeader
        eyebrow="Personalização"
        title="Seu app, do seu jeito"
        description="Temas, intensidade do vidro, cores e densidade. Cada preferência é salva individualmente na sua conta."
        actions={
          <ActionButton variant="secondary" size="sm" onClick={restore}>
            <RotateCcw className="h-3.5 w-3.5" /> Restaurar aparência original
          </ActionButton>
        }
      />

      <div className="grid gap-5 lg:grid-cols-2">
        <GlassPanel className="p-5 lg:col-span-2">
          <div className="flex items-center gap-2">
            <Palette className="h-4 w-4 text-bgc-glow" />
            <p className="font-heading text-sm font-semibold text-bgc-ink">Temas</p>
          </div>
          <div className="mt-4">
            <ThemeGrid
              value={prefs.theme}
              onChange={(theme) => {
                const preset = THEMES.find((t) => t.id === theme);
                set({ theme, accent_color: preset?.accent ?? prefs.accent_color });
              }}
            />
          </div>
        </GlassPanel>

        <GlassPanel className="p-5">
          <div className="flex items-center gap-2">
            <Wind className="h-4 w-4 text-bgc-glow" />
            <p className="font-heading text-sm font-semibold text-bgc-ink">Vidro (glassmorphism)</p>
          </div>
          <div className="mt-4 space-y-4">
            <SliderRow
              label="Intensidade do blur"
              value={Number(prefs.glass_blur)}
              min={0}
              max={40}
              onChange={(v) => set({ glass_blur: v })}
              format={(v) => `${v}px`}
            />
            <SliderRow
              label="Transparência dos cartões"
              value={Number(prefs.glass_alpha)}
              min={0.015}
              max={0.14}
              step={0.005}
              onChange={(v) => set({ glass_alpha: v })}
              format={(v) => `${Math.round((v / 0.14) * 100)}%`}
            />
            <SliderRow
              label="Intensidade do brilho"
              value={Number(prefs.glow_strength)}
              min={0}
              max={0.6}
              step={0.02}
              onChange={(v) => set({ glow_strength: v })}
              format={(v) => `${Math.round(v * 100)}%`}
            />
            <SliderRow
              label="Arredondamento"
              value={Number(prefs.corner_radius)}
              min={4}
              max={34}
              onChange={(v) => set({ corner_radius: v })}
              format={(v) => `${v}px`}
            />
            <SliderRow
              label="Intensidade das sombras"
              value={Number(prefs.shadow_strength)}
              min={0}
              max={0.9}
              step={0.05}
              onChange={(v) => set({ shadow_strength: v })}
              format={(v) => `${Math.round(v * 100)}%`}
            />
            <SliderRow
              label="Opacidade do fundo"
              value={Number(prefs.bg_opacity)}
              min={0.3}
              max={1}
              step={0.05}
              onChange={(v) => set({ bg_opacity: v })}
              format={(v) => `${Math.round(v * 100)}%`}
            />
            <ToggleRow
              label="Efeitos de borda"
              hint="Destaque luminoso nas bordas dos cartões"
              checked={!!prefs.border_glow}
              onChange={(v) => set({ border_glow: v })}
            />
            <ToggleRow
              label="Iluminação ambiental"
              hint="Luzes verdes difusas no fundo"
              checked={!!prefs.ambient_light}
              onChange={(v) => set({ ambient_light: v })}
            />
          </div>
        </GlassPanel>

        <GlassPanel className="p-5">
          <p className="font-heading text-sm font-semibold text-bgc-ink">Interface</p>
          <div className="mt-4 space-y-4">
            <ColorRow label="Cor principal" value={prefs.accent_color} presets={ACCENTS} onChange={(c) => set({ accent_color: c })} />
            <ColorRow
              label="Cor secundária"
              value={prefs.secondary_color}
              presets={["#0EA5E9", "#38BDF8", "#A78BFA", "#F59E0B", "#F43F5E", "#22C55E"]}
              onChange={(c) => set({ secondary_color: c })}
            />

            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <p className="mb-2 text-[11.5px] font-medium text-bgc-dim">Sidebar</p>
                <Select value={prefs.sidebar_mode} onValueChange={(v) => set({ sidebar_mode: v })}>
                  <SelectTrigger className="h-10 border-white/10 bg-white/[0.04] text-bgc-ink">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-white/10 bg-[#0A0F18] text-bgc-ink">
                    <SelectItem value="expanded">Expandida</SelectItem>
                    <SelectItem value="compact">Compacta</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <p className="mb-2 text-[11.5px] font-medium text-bgc-dim">Densidade dos cartões</p>
                <Select value={prefs.card_density} onValueChange={(v) => set({ card_density: v })}>
                  <SelectTrigger className="h-10 border-white/10 bg-white/[0.04] text-bgc-ink">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-white/10 bg-[#0A0F18] text-bgc-ink">
                    <SelectItem value="comfortable">Confortável</SelectItem>
                    <SelectItem value="compact">Compacta</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <ToggleRow label="Animações" hint="Transições e movimentos da interface" checked={!!prefs.animations} onChange={(v) => set({ animations: v })} />
            <ToggleRow label="Efeitos de hover" hint="Elevação e brilho ao passar o mouse" checked={!!prefs.hover_effects} onChange={(v) => set({ hover_effects: v })} />

            <div>
              <p className="mb-2 text-[11.5px] font-medium text-bgc-dim">Widgets visíveis</p>
              <WidgetPicker value={prefs.widgets ?? []} onToggle={toggleWidget} />
            </div>
          </div>
        </GlassPanel>

        <GlassPanel className="p-5 lg:col-span-2">
          <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-bgc-dim">Prévia</p>
          <div
            className={cn("mt-3 rounded-glass border border-white/10 p-5")}
            style={{ background: "rgba(255,255,255,0.045)", backdropFilter: "blur(18px)" }}
          >
            <p className="font-heading text-sm font-semibold text-bgc-ink">Superfície de vidro</p>
            <p className="mt-1 text-[12px] text-bgc-dim">
              É assim que os cartões aparecem com as suas configurações atuais de blur, transparência e brilho.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <ActionButton size="sm">Primário</ActionButton>
              <ActionButton size="sm" variant="secondary">Secundário</ActionButton>
              <ActionButton size="sm" variant="ghost">Ghost</ActionButton>
            </div>
          </div>
        </GlassPanel>
      </div>
    </div>
  );
}