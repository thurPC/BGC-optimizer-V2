import { useQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Cpu, HardDrive, MemoryStick, MonitorPlay, Pencil, Plus } from "lucide-react";
import PageHeader from "@/components/glass/PageHeader";
import EmptyState from "@/components/glass/EmptyState";
import StatusPill from "@/components/glass/StatusPill";
import MeterBar from "@/components/glass/MeterBar";
import ActionButton from "@/components/glass/ActionButton";
import { GlassPanel } from "@/components/glass/GlassPanel";
import ComputerForm from "@/components/hardware/ComputerForm";
import ConnectionPanel from "@/components/hardware/ConnectionPanel";
import { computerQuery } from "@/lib/queries";
import { fmtNumber } from "@/lib/format";

export const Route = createFileRoute("/_authed/hardware")({
  head: () => ({ meta: [{ title: "Hardware · BGC Optimizer" }] }),
  component: HardwarePage,
});

const show = (value, suffix = "") =>
  value === null || value === undefined || value === "" ? "—" : `${fmtNumber(value)}${suffix}`;

function DetailCard({ icon: Icon, title, subtitle, rows, children, accent }) {
  return (
    <GlassPanel className="p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-bgc-dim">{title}</p>
          <p className="mt-1 truncate font-heading text-base font-semibold text-bgc-ink">{subtitle || "Não informado"}</p>
        </div>
        <span
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border"
          style={{ borderColor: `${accent}44`, background: `${accent}18`, color: accent }}
        >
          <Icon className="h-4 w-4" />
        </span>
      </div>
      <div className="mt-4 space-y-1.5">
        {rows.map((row) => (
          <div key={row.label} className="flex items-baseline justify-between gap-3">
            <span className="text-[11px] uppercase tracking-wider text-bgc-dim/80">{row.label}</span>
            <span className="truncate font-mono text-[12px] text-bgc-ink">{row.value}</span>
          </div>
        ))}
      </div>
      {children}
    </GlassPanel>
  );
}

function HardwarePage() {
  const { data: computer, isLoading } = useQuery(computerQuery());

  if (isLoading) return <div className="glass h-64 animate-pulse rounded-glass" />;

  if (!computer) {
    return (
      <div className="animate-in fade-in duration-400">
        <PageHeader eyebrow="Hardware" title="Seu computador" description="Cadastre o hardware para receber recomendações compatíveis." />
        <EmptyState
          icon={Cpu}
          title="Nenhum computador cadastrado"
          description="Você pode cadastrar manualmente agora — a detecção automática chega com o agente Windows."
          action={
            <div className="flex flex-wrap gap-2">
              <Link to="/onboarding">
                <ActionButton size="sm">
                  <Plus className="h-4 w-4" /> Cadastrar no assistente
                </ActionButton>
              </Link>
              <ComputerForm
                trigger={
                  <ActionButton variant="secondary" size="sm">
                    Cadastro rápido
                  </ActionButton>
                }
              />
            </div>
          }
        />
      </div>
    );
  }

  const freePct =
    computer.total_space_gb && computer.free_space_gb
      ? (computer.free_space_gb / computer.total_space_gb) * 100
      : 0;

  return (
    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
      <PageHeader
        eyebrow="Hardware"
        title={computer.name}
        description="Informações cadastradas por você. Uso e temperatura ao vivo dependem do agente Windows conectado."
        actions={
          <>
            <StatusPill tone={computer.detection_mode === "manual" ? "gray" : "green"}>
              {computer.detection_mode === "manual" ? "Preenchimento manual" : "Detectado pelo agente"}
            </StatusPill>
            <ComputerForm
              computer={computer}
              trigger={
                <ActionButton size="sm">
                  <Pencil className="h-3.5 w-3.5" /> Editar
                </ActionButton>
              }
            />
          </>
        }
      />

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_330px]">
        <div className="grid gap-4 sm:grid-cols-2">
          <DetailCard
            icon={Cpu}
            title="Processador"
            subtitle={computer.cpu_model}
            accent="#22C55E"
            rows={[
              { label: "Núcleos", value: show(computer.cpu_cores) },
              { label: "Utilização", value: "Aguardando conexão" },
              { label: "Temperatura", value: "Aguardando conexão" },
              { label: "Frequência", value: "Aguardando conexão" },
            ]}
          />
          <DetailCard
            icon={MonitorPlay}
            title="Placa de vídeo"
            subtitle={computer.gpu_model}
            accent="#38BDF8"
            rows={[
              { label: "VRAM", value: show(computer.gpu_vram_gb, " GB") },
              { label: "Utilização", value: "Aguardando conexão" },
              { label: "Temperatura", value: "Aguardando conexão" },
              { label: "Driver", value: "Registre no perfil do jogo" },
            ]}
          />
          <DetailCard
            icon={MemoryStick}
            title="Memória RAM"
            subtitle={computer.ram_gb ? `${fmtNumber(computer.ram_gb)} GB` : null}
            accent="#A78BFA"
            rows={[
              { label: "Frequência", value: show(computer.ram_speed_mhz, " MHz") },
              { label: "Em uso", value: "Aguardando conexão" },
              { label: "Disponível", value: "Aguardando conexão" },
            ]}
          />
          <DetailCard
            icon={HardDrive}
            title="Armazenamento"
            subtitle={computer.storage_label || computer.storage_type}
            accent="#F59E0B"
            rows={[
              { label: "Tipo", value: computer.storage_type || "—" },
              { label: "Livre", value: show(computer.free_space_gb, " GB") },
              { label: "Total", value: show(computer.total_space_gb, " GB") },
              { label: "Saúde", value: show(computer.storage_health, "%") },
              { label: "Temperatura", value: show(computer.storage_temp_c, " °C") },
            ]}
          >
            <MeterBar
              className="mt-4"
              value={computer.free_space_gb ?? 0}
              max={computer.total_space_gb ?? 1}
              tone={freePct < 15 ? "red" : freePct < 30 ? "yellow" : "green"}
              label="Espaço livre"
              sublabel={`${fmtNumber(freePct, 0)}%`}
            />
          </DetailCard>

          <GlassPanel className="p-5 sm:col-span-2">
            <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-bgc-dim">Sistema</p>
            <div className="mt-3 grid gap-3 sm:grid-cols-3">
              <div>
                <p className="text-[10px] uppercase tracking-wider text-bgc-dim/70">Sistema operacional</p>
                <p className="mt-1 text-[13px] text-bgc-ink">{computer.os || "—"}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wider text-bgc-dim/70">Versão do Windows</p>
                <p className="mt-1 text-[13px] text-bgc-ink">{computer.windows_version || "—"}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wider text-bgc-dim/70">Observações</p>
                <p className="mt-1 text-[13px] text-bgc-ink">{computer.notes || "—"}</p>
              </div>
            </div>
          </GlassPanel>
        </div>

        <ConnectionPanel computer={computer} />
      </div>
    </div>
  );
}