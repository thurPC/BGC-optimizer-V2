import { useQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Cpu, Gamepad2, Gauge, Activity } from "lucide-react";
import PageHeader from "@/components/glass/PageHeader";
import ActionButton from "@/components/glass/ActionButton";
import EmptyState from "@/components/glass/EmptyState";
import HardwareOverview from "@/components/dashboard/HardwareOverview";
import PerformanceSummary from "@/components/dashboard/PerformanceSummary";
import OverviewSidebar from "@/components/dashboard/OverviewSidebar";
import { useEnsureProfiles } from "@/hooks/useProfiles";
import {
  computerQuery,
  gameProfilesQuery,
  recommendationsQuery,
  sessionsQuery,
} from "@/lib/queries";
import { usePreferences } from "@/lib/usePreferences";

export const Route = createFileRoute("/_authed/dashboard")({
  head: () => ({ meta: [{ title: "Visão geral · BGC Optimizer" }] }),
  component: DashboardPage,
});

function DashboardPage() {
  const { prefs } = usePreferences();
  const { data: computer } = useQuery(computerQuery());
  const { data: sessions = [] } = useQuery(sessionsQuery());
  const { data: gameProfiles = [] } = useQuery(gameProfilesQuery());
  const { data: recommendations = [] } = useQuery(recommendationsQuery());
  const { active } = useEnsureProfiles();

  const applied = new Set(active?.settings ?? []);
  const pendingList = recommendations.filter((r) => !applied.has(r.linked_setting));
  const density = prefs.card_density === "compact" ? "gap-3" : "gap-5";

  return (
    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
      <PageHeader
        eyebrow="Visão geral"
        title="Seu ambiente em um só lugar"
        description="Hardware, perfil ativo e desempenho registrado — sem valores inventados: o que aparece aqui é o que você informou ou mediu."
        actions={
          <>
            <Link to="/booster">
              <ActionButton variant="secondary" size="sm">
                <Gamepad2 className="h-4 w-4" /> Game Booster
              </ActionButton>
            </Link>
            <Link to="/monitoramento">
              <ActionButton size="sm">
                <Activity className="h-4 w-4" /> Registrar sessão
              </ActionButton>
            </Link>
          </>
        }
      />

      {!computer ? (
        <EmptyState
          icon={Cpu}
          title="Vamos cadastrar seu computador"
          description="Informe CPU, GPU, memória e armazenamento para receber recomendações compatíveis com a sua máquina."
          action={
            <Link to="/onboarding">
              <ActionButton>
                Iniciar cadastro <ArrowRight className="h-4 w-4" />
              </ActionButton>
            </Link>
          }
        />
      ) : (
        <div className={`grid ${density} xl:grid-cols-[minmax(0,1fr)_340px]`}>
          <div className={prefs.card_density === "compact" ? "space-y-3" : "space-y-5"}>
            <HardwareOverview computer={computer} />
            <PerformanceSummary sessions={sessions} />
            <div className="grid gap-4 sm:grid-cols-3">
              {[
                { to: "/otimizacoes", icon: Gauge, label: "Otimizações", hint: `${applied.size} ajustes no perfil ativo` },
                { to: "/booster", icon: Gamepad2, label: "Game Booster", hint: `${gameProfiles.length} jogos configurados` },
                { to: "/perfis", icon: Cpu, label: "Perfis", hint: "Criar, duplicar e ativar" },
              ].map((q) => (
                <Link key={q.to} to={q.to}>
                  <div className="glass glass-hover flex items-center gap-3 p-4">
                    <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-bgc-glow/25 bg-bgc-glow/10 text-bgc-glow">
                      <q.icon className="h-4 w-4" />
                    </span>
                    <div className="min-w-0">
                      <p className="truncate font-heading text-sm font-semibold text-bgc-ink">{q.label}</p>
                      <p className="truncate text-xs text-bgc-dim">{q.hint}</p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          <OverviewSidebar
            active={active}
            computer={computer}
            gameCount={gameProfiles.length}
            pending={pendingList.length}
            recommendations={pendingList}
          />
        </div>
      )}
    </div>
  );
}