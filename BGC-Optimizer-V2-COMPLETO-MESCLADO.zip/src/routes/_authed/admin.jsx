import { createFileRoute } from "@tanstack/react-router";
import { ShieldAlert } from "lucide-react";
import PageHeader from "@/components/glass/PageHeader";
import EmptyState from "@/components/glass/EmptyState";
import AdminStats from "@/components/admin/AdminStats";
import AdminUsers from "@/components/admin/AdminUsers";
import AdminGames from "@/components/admin/AdminGames";
import AdminRecommendations from "@/components/admin/AdminRecommendations";
import AdminNotifications from "@/components/admin/AdminNotifications";
import { useAuth } from "@/lib/AuthContext";

export const Route = createFileRoute("/_authed/admin")({
  head: () => ({ meta: [{ title: "Administração · BGC Optimizer" }] }),
  component: AdminPage,
});

function Section({ title, description, children }) {
  return (
    <section className="mt-8">
      <h2 className="font-heading text-lg font-semibold text-bgc-ink">{title}</h2>
      <p className="mb-3 mt-1 text-[12px] text-bgc-dim">{description}</p>
      {children}
    </section>
  );
}

function AdminPage() {
  const { user, isLoadingAuth } = useAuth();

  if (isLoadingAuth) return <div className="glass h-40 animate-pulse rounded-glass" />;

  if (user?.role !== "admin") {
    return (
      <EmptyState
        icon={ShieldAlert}
        title="Área restrita"
        description="Somente administradores autorizados podem acessar o painel administrativo."
      />
    );
  }

  return (
    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
      <PageHeader
        eyebrow="Administração"
        title="Controle do aplicativo"
        description="Usuários, catálogo de jogos, recomendações e comunicados globais — com acesso restrito a administradores."
      />

      <AdminStats />

      <Section title="Usuários" description="Consulte contas e envie convites.">
        <AdminUsers />
      </Section>

      <Section title="Catálogo de jogos" description="Títulos disponíveis no Game Booster para todos os usuários.">
        <AdminGames />
      </Section>

      <Section title="Recomendações" description="Sugestões exibidas no painel, nas otimizações e nos jogos.">
        <AdminRecommendations />
      </Section>

      <Section title="Notificações globais" description="Comunicados enviados para todos os usuários.">
        <AdminNotifications />
      </Section>
    </div>
  );
}