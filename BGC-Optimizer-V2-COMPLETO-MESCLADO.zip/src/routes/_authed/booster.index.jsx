import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { Gamepad2, Info } from "lucide-react";
import PageHeader from "@/components/glass/PageHeader";
import EmptyState from "@/components/glass/EmptyState";
import StatusPill from "@/components/glass/StatusPill";
import GameCard from "@/components/booster/GameCard";
import AddGameDialog from "@/components/booster/AddGameDialog";
import { gameProfilesQuery, gamesQuery } from "@/lib/queries";

export const Route = createFileRoute("/_authed/booster/")({
  head: () => ({ meta: [{ title: "Game Booster · BGC Optimizer" }] }),
  component: BoosterPage,
});

function BoosterPage() {
  const { data: games = [], isLoading } = useQuery(gamesQuery());
  const { data: gameProfiles = [] } = useQuery(gameProfilesQuery());

  return (
    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
      <PageHeader
        eyebrow="Game Booster"
        title="Configure seu ambiente para cada partida"
        description="Um perfil e um checklist dedicados por jogo. Tudo registrado na sua conta — nada é alterado no Windows sem o agente autorizado."
        actions={<AddGameDialog />}
      />

      <div className="mb-5 flex flex-wrap items-center gap-2">
        <StatusPill tone="gray">{games.length} jogos</StatusPill>
        <StatusPill tone="green">{gameProfiles.length} configurados</StatusPill>
        <span className="inline-flex items-center gap-1.5 text-[11px] text-bgc-dim">
          <Info className="h-3.5 w-3.5" /> O checklist registra as ações dentro do aplicativo.
        </span>
      </div>

      {isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="glass h-[240px] animate-pulse" />
          ))}
        </div>
      ) : games.length === 0 ? (
        <EmptyState
          icon={Gamepad2}
          title="Sua biblioteca está vazia"
          description="Adicione um jogo para criar o primeiro perfil de desempenho."
          action={<AddGameDialog />}
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {games.map((game) => (
            <GameCard key={game.id} game={game} gameProfile={gameProfiles.find((p) => p.game_id === game.id)} />
          ))}
        </div>
      )}
    </div>
  );
}