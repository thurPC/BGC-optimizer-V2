import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, createFileRoute } from "@tanstack/react-router";
import { ArrowLeft, GitCompareArrows, History, Layers } from "lucide-react";
import PageHeader from "@/components/glass/PageHeader";
import { GlassPanel } from "@/components/glass/GlassPanel";
import EmptyState from "@/components/glass/EmptyState";
import StatusPill from "@/components/glass/StatusPill";
import ActionButton from "@/components/glass/ActionButton";
import { prepareSessionsQuery } from "@/lib/queries";
import { METRIC_DEFS, compareMetrics, fmtMetric, summarizeComparison } from "@/lib/prepare";
import { PROFILE_KINDS } from "@/lib/constants";
import { fmtDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authed/sessoes")({
  head: () => ({ meta: [{ title: "Sessões · BGC Optimizer" }] }),
  component: SessionsPage,
});

function parseBefore(session) {
  try {
    return session?.before_state ? JSON.parse(session.before_state) : null;
  } catch {
    return null;
  }
}

function SessionRow({ session, selected, onToggle }) {
  const before = parseBefore(session);
  const metricCount = before?.metric
    ? METRIC_DEFS.filter((d) => before.metric[d.key] !== null && before.metric[d.key] !== undefined).length
    : 0;
  return (
    <GlassPanel className="p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <Link
              to="/sessao/$sessionId"
              params={{ sessionId: session.id }}
              className="font-heading text-[15px] font-semibold text-bgc-ink hover:text-bgc-glow"
            >
              {session.game_name}
            </Link>
            <StatusPill tone="green">{PROFILE_KINDS[session.profile_kind]?.label ?? session.profile_kind}</StatusPill>
          </div>
          <p className="mt-1 text-[11px] text-bgc-dim">{fmtDateTime(session.completed_at ?? session.started_at)}</p>
          <div className="mt-2 flex flex-wrap gap-2">
            <StatusPill tone="green">{session.checklist_done?.length ?? 0} verificados</StatusPill>
            <StatusPill tone="yellow">{session.checklist_pending?.length ?? 0} pendentes</StatusPill>
            <StatusPill tone={before?.agent?.connected ? "green" : "amber"}>
              {before?.agent?.connected ? "Agente online" : "Agente offline"}
            </StatusPill>
            <StatusPill tone={metricCount ? "green" : "gray"}>{metricCount ? `${metricCount} métricas` : "Sem métricas"}</StatusPill>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onToggle(session.id)}
            className={cn(
              "rounded-lg border px-2.5 py-1.5 text-[11px] font-medium transition",
              selected
                ? "border-bgc-glow/50 bg-bgc-glow/15 text-bgc-glow"
                : "border-white/15 bg-white/[0.03] text-bgc-dim hover:border-white/30"
            )}
          >
            {selected ? "Selecionada" : "Selecionar"}
          </button>
          <Link to="/sessao/$sessionId" params={{ sessionId: session.id }}>
            <ActionButton size="sm" variant="ghost">Ver</ActionButton>
          </Link>
        </div>
      </div>
    </GlassPanel>
  );
}

function CompareTwo({ sessions }) {
  const a = sessions[0];
  const b = sessions[1];
  const beforeA = parseBefore(a)?.metric ?? null;
  const beforeB = parseBefore(b)?.metric ?? null;
  const rows = compareMetrics(beforeA, beforeB);
  const summary = summarizeComparison(rows);

  return (
    <GlassPanel tone="strong" className="p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <GitCompareArrows className="h-4 w-4 text-bgc-glow" />
          <p className="font-heading text-sm font-semibold text-bgc-ink">Comparação entre duas sessões</p>
        </div>
        <div className="flex items-center gap-2 text-[11px]">
          <span className="inline-flex items-center gap-1 rounded-full border border-bgc-glow/30 bg-bgc-glow/10 px-2 py-0.5 text-bgc-glow">
            {summary.improved} melhores
          </span>
          <span className="inline-flex items-center gap-1 rounded-full border border-rose-400/30 bg-rose-400/10 px-2 py-0.5 text-rose-300">
            {summary.regressed} piores
          </span>
          <span className="inline-flex items-center gap-1 rounded-full border border-white/15 bg-white/5 px-2 py-0.5 text-bgc-dim">
            {summary.stable} estáveis
          </span>
        </div>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {[
          { s: a, label: "Sessão A" },
          { s: b, label: "Sessão B" },
        ].map(({ s, label }) => (
          <div key={label} className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-3">
            <p className="text-[10px] uppercase tracking-wider text-bgc-dim">{label}</p>
            <p className="mt-0.5 text-[13px] font-semibold text-bgc-ink">{s.game_name}</p>
            <p className="text-[11px] text-bgc-dim">{fmtDateTime(s.completed_at ?? s.started_at)}</p>
            <p className="mt-1 text-[10px] text-bgc-dim/70">
              {PROFILE_KINDS[s.profile_kind]?.label ?? s.profile_kind} · {s.checklist_done?.length ?? 0} ajustes verificados
            </p>
          </div>
        ))}
      </div>

      {rows.length === 0 ? (
        <p className="mt-4 rounded-xl border border-white/[0.08] bg-white/[0.02] p-3 text-[12px] text-bgc-dim">
          Estas sessões não têm métricas reais em comum registradas. Conecte o agente Windows e registre sessões de
          monitoramento para comparar.
        </p>
      ) : (
        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[420px] border-collapse text-[12px]">
            <thead>
              <tr className="text-left text-[10px] uppercase tracking-wider text-bgc-dim">
                <th className="pb-2 font-medium">Métrica</th>
                <th className="pb-2 text-right font-medium">Sessão A</th>
                <th className="pb-2 text-right font-medium">Sessão B</th>
                <th className="pb-2 text-right font-medium">Diferença</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const sign = r.delta > 0 ? "+" : "";
                return (
                  <tr key={r.key} className="border-t border-white/[0.06]">
                    <td className="py-2 font-medium text-bgc-ink">{r.label}</td>
                    <td className="py-2 text-right text-bgc-dim">{fmtMetric(r.before, r.unit)}</td>
                    <td className="py-2 text-right text-bgc-ink">{fmtMetric(r.after, r.unit)}</td>
                    <td className="py-2 text-right text-bgc-glow">
                      {sign}
                      {fmtMetric(Math.abs(r.delta), r.unit, r.unit === "ms" ? 2 : 0)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </GlassPanel>
  );
}

function SessionsPage() {
  const { data: sessions = [], isLoading } = useQuery(prepareSessionsQuery());
  const [selected, setSelected] = useState([]);

  const toggle = (id) =>
    setSelected((cur) => {
      if (cur.includes(id)) return cur.filter((x) => x !== id);
      if (cur.length >= 2) return [cur[1], id];
      return [...cur, id];
    });

  const selectedSessions = useMemo(
    () => selected.map((id) => sessions.find((s) => s.id === id)).filter(Boolean),
    [selected, sessions]
  );

  return (
    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
      <PageHeader
        eyebrow="Histórico"
        title="Sessões de preparação"
        description="Todas as suas preparações registradas, isoladas por usuário. Selecione duas para comparar métricas reais."
      />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <StatusPill tone="green">{sessions.length} sessões</StatusPill>
        <StatusPill tone={selected.length === 2 ? "green" : "gray"}>
          {selected.length}/2 selecionadas para comparar
        </StatusPill>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[0, 1, 2].map((i) => (
            <div key={i} className="glass h-28 animate-pulse rounded-glass" />
          ))}
        </div>
      ) : sessions.length === 0 ? (
        <EmptyState
          icon={History}
          title="Nenhuma sessão registrada"
          description="Use o botão Preparar para jogar em um jogo para registrar a primeira sessão."
          action={
            <Link to="/booster">
              <ActionButton size="sm" variant="ghost">
                <ArrowLeft className="h-3.5 w-3.5" /> Ir para Game Booster
              </ActionButton>
            </Link>
          }
        />
      ) : (
        <div className="space-y-3">
          {sessions.map((s) => (
            <SessionRow key={s.id} session={s} selected={selected.includes(s.id)} onToggle={toggle} />
          ))}
        </div>
      )}

      {selectedSessions.length === 2 && (
        <div className="mt-5">
          <CompareTwo sessions={selectedSessions} />
        </div>
      )}

      {selectedSessions.length === 2 && (
        <div className="mt-3">
          <button
            type="button"
            onClick={() => setSelected([])}
            className="text-[11px] font-medium text-bgc-dim transition hover:text-bgc-ink"
          >
            Limpar seleção
          </button>
        </div>
      )}
    </div>
  );
}