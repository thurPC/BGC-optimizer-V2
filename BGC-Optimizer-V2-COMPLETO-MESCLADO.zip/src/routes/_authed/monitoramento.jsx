const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { Activity, Info, Trash2 } from "lucide-react";
import { toast } from "sonner";

import PageHeader from "@/components/glass/PageHeader";
import EmptyState from "@/components/glass/EmptyState";
import StatTile from "@/components/glass/StatTile";
import StatusPill from "@/components/glass/StatusPill";
import { GlassPanel } from "@/components/glass/GlassPanel";
import SessionChart from "@/components/monitoring/SessionChart";
import SessionForm from "@/components/monitoring/SessionForm";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { fmtDateTime, fmtNumber } from "@/lib/format";
import { gamesQuery, logActivity, optimizationProfilesQuery, sessionsQuery } from "@/lib/queries";

export const Route = createFileRoute("/_authed/monitoramento")({
  head: () => ({ meta: [{ title: "Monitoramento · BGC Optimizer" }] }),
  component: MonitoringPage,
});

const SOURCE_LABEL = { manual: "Manual", imported: "Importado", agent: "Agente" };
const SOURCE_TONE = { manual: "yellow", imported: "blue", agent: "green" };

function MonitoringPage() {
  const queryClient = useQueryClient();
  const { data: sessions = [] } = useQuery(sessionsQuery());
  const { data: games = [] } = useQuery(gamesQuery());
  const { data: profiles = [] } = useQuery(optimizationProfilesQuery());

  const latest = sessions[0];
  const avgFps = sessions.length
    ? sessions.reduce((sum, s) => sum + (Number(s.fps_avg) || 0), 0) / sessions.filter((s) => s.fps_avg).length
    : null;
  const bestLow = sessions.length ? Math.max(...sessions.map((s) => Number(s.fps_1_low) || 0)) : null;

  const remove = async (session) => {
    await db.entities.PerformanceSession.delete(session.id);
    await logActivity({
      action_type: "session_recorded",
      title: `Sessão removida — ${session.game_name}`,
      detail: "Registro excluído do histórico de métricas.",
      entity_name: "PerformanceSession",
    });
    queryClient.invalidateQueries({ queryKey: ["sessions"] });
    queryClient.invalidateQueries({ queryKey: ["history"] });
    toast.success("Sessão removida.");
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
      <PageHeader
        eyebrow="Monitoramento"
        title="Desempenho medido, não estimado"
        description="Registre sessões e compare resultados ao longo do tempo. Medições automáticas chegam com o agente Windows."
        actions={<SessionForm games={games} profiles={profiles} />}
      />

      <div className="mb-5 flex items-start gap-2 rounded-xl border border-white/[0.08] bg-white/[0.02] p-3">
        <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-bgc-glow" />
        <p className="text-[11px] leading-relaxed text-bgc-dim">
          Os dados abaixo são <span className="text-bgc-ink">registrados manualmente por você</span> e aparecem marcados como
          “Manual”. O BGC Optimizer não gera métricas próprias nem estima FPS.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile label="Sessões registradas" value={sessions.length} icon={Activity} />
        <StatTile label="FPS médio geral" value={avgFps ? fmtNumber(avgFps, 0) : "—"} tone="blue" />
        <StatTile label="Melhor 1% low" value={bestLow ? fmtNumber(bestLow, 0) : "—"} tone="purple" />
        <StatTile
          label="Última sessão"
          value={latest ? latest.game_name : "—"}
          hint={latest ? fmtDateTime(latest.recorded_at) : "Nenhum registro"}
          tone="yellow"
        />
      </div>

      {sessions.length === 0 ? (
        <div className="mt-5">
          <EmptyState
            icon={Activity}
            title="Nenhuma sessão registrada"
            description="Registre a primeira medição para começar a comparar desempenho entre jogos, perfis e versões de driver."
          />
        </div>
      ) : (
        <>
          <GlassPanel className="mt-5 p-5">
            <div className="flex items-center justify-between">
              <p className="font-heading text-base font-semibold text-bgc-ink">Comparação das últimas sessões</p>
              <StatusPill tone="gray">até 10 registros</StatusPill>
            </div>
            <div className="mt-4">
              <SessionChart sessions={sessions} />
            </div>
          </GlassPanel>

          <GlassPanel className="mt-5 overflow-hidden p-0">
            <div className="border-b border-white/[0.07] px-5 py-4">
              <p className="font-heading text-base font-semibold text-bgc-ink">Sessões</p>
            </div>
            <div className="divide-y divide-white/[0.06]">
              {sessions.map((session) => (
                <div key={session.id} className="flex flex-wrap items-center gap-3 px-5 py-3.5">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="truncate text-[13px] font-medium text-bgc-ink">{session.game_name}</p>
                      <StatusPill tone={SOURCE_TONE[session.source] ?? "gray"}>{SOURCE_LABEL[session.source] ?? session.source}</StatusPill>
                      {session.profile_name && <StatusPill tone="gray">{session.profile_name}</StatusPill>}
                    </div>
                    <p className="mt-0.5 text-[11px] text-bgc-dim">
                      {fmtDateTime(session.recorded_at)}
                      {session.duration_min ? ` · ${session.duration_min} min` : ""}
                      {session.notes ? ` · ${session.notes}` : ""}
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-4 font-mono text-[11px] text-bgc-dim">
                    <span>FPS <span className="text-bgc-ink">{fmtNumber(session.fps_avg)}</span></span>
                    <span>1% <span className="text-bgc-ink">{fmtNumber(session.fps_1_low)}</span></span>
                    <span>0,1% <span className="text-bgc-ink">{fmtNumber(session.fps_01_low)}</span></span>
                    <span>ft <span className="text-bgc-ink">{fmtNumber(session.frametime_ms, 2)}</span></span>
                  </div>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <button
                        type="button"
                        className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 text-bgc-dim transition hover:border-red-400/40 hover:text-red-300"
                        aria-label="Excluir sessão"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </AlertDialogTrigger>
                    <AlertDialogContent className="glass-strong border-white/12 bg-[#0A0F18]/96 text-bgc-ink">
                      <AlertDialogHeader>
                        <AlertDialogTitle>Excluir esta sessão?</AlertDialogTitle>
                        <AlertDialogDescription className="text-bgc-dim">
                          O registro de {session.game_name} será removido do seu histórico de métricas.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel className="border-white/15 bg-transparent text-bgc-ink hover:bg-white/10">
                          Cancelar
                        </AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => remove(session)}
                          className="bg-red-500/90 text-white hover:bg-red-500"
                        >
                          Excluir
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              ))}
            </div>
          </GlassPanel>
        </>
      )}
    </div>
  );
}