import { createFileRoute } from "@tanstack/react-router";
import AmbientBackground from "@/components/glass/AmbientBackground";
import OnboardingWizard from "@/components/onboarding/OnboardingWizard";

export const Route = createFileRoute("/_authed/onboarding")({
  head: () => ({ meta: [{ title: "Configuração inicial · BGC Optimizer" }] }),
  component: OnboardingPage,
});

function OnboardingPage() {
  return (
    <div className="relative min-h-dvh overflow-hidden grain">
      <AmbientBackground />
      <OnboardingWizard />
    </div>
  );
}