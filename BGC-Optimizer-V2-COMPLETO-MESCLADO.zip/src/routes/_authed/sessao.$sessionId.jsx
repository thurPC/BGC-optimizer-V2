import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { Clock } from "lucide-react";
import PrepareResult from "@/components/prepare/PrepareResult";
import { prepareSessionQuery } from "@/lib/queries";

export const Route = createFileRoute("/_authed/sessao/$sessionId")({
  head: ({ params }) => ({ meta: [{ title: `Sessão · BGC Optimizer` }] }),
  component: SessionResultPage,
});

function SessionResultPage() {
  const { sessionId } = Route.useParams();
  const { data: session, isLoading } = useQuery(prepareSessionQuery(sessionId));

  if (isLoading) return <div className="glass h-64 animate-pulse rounded-glass" />;
  return <PrepareResult session={session} />;
}