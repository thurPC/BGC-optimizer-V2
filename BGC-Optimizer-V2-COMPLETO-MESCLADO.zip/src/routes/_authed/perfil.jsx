const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Camera, Save } from "lucide-react";
import { toast } from "sonner";

import PageHeader from "@/components/glass/PageHeader";
import ActionButton from "@/components/glass/ActionButton";
import { GlassPanel } from "@/components/glass/GlassPanel";
import UserAvatar from "@/components/layout/UserAvatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/lib/AuthContext";
import { usePreferences } from "@/lib/usePreferences";

export const Route = createFileRoute("/_authed/perfil")({
  head: () => ({ meta: [{ title: "Perfil · BGC Optimizer" }] }),
  component: ProfilePage,
});

function ProfilePage() {
  const { user, refresh } = useAuth();
  const { prefs, save } = usePreferences();
  const [name, setName] = useState(user?.full_name ?? "");
  const [username, setUsername] = useState(prefs.username ?? "");
  const [bio, setBio] = useState(prefs.bio ?? "");
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const upload = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_uri } = await db.integrations.Core.UploadPrivateFile({ file });
      await save({ avatar_url: file_uri });
      toast.success("Foto de perfil atualizada.");
    } finally {
      setUploading(false);
    }
  };

  const submit = async (event) => {
    event.preventDefault();
    setSaving(true);
    try {
      await db.auth.updateMe({ full_name: name.trim() });
      await save({ username: username.trim(), bio: bio.trim() });
      await refresh();
      toast.success("Perfil salvo.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
      <PageHeader eyebrow="Perfil" title="Sua identidade no BGC" description="Nome, foto e preferências pessoais." />

      <div className="grid gap-5 lg:grid-cols-[320px_minmax(0,1fr)]">
        <GlassPanel className="p-5 text-center">
          <div className="relative mx-auto h-24 w-24">
            <UserAvatar
              uri={prefs.avatar_url}
              name={username || user?.full_name || "BG"}
              className="h-24 w-24"
              textClassName="text-2xl"
            />
            <label className="absolute -bottom-1 -right-1 flex h-8 w-8 cursor-pointer items-center justify-center rounded-full border border-bgc-glow/40 bg-[#0A0F18] text-bgc-glow transition hover:bg-bgc-glow/15">
              <Camera className="h-3.5 w-3.5" />
              <input type="file" accept="image/*" onChange={upload} className="hidden" />
            </label>
          </div>
          <p className="mt-4 font-heading text-base font-semibold text-bgc-ink">{username || user?.full_name || "Jogador"}</p>
          <p className="truncate text-xs text-bgc-dim">{user?.email}</p>
          {uploading && <p className="mt-2 text-[11px] text-bgc-glow">Enviando imagem…</p>}
          <p className="mt-4 text-[10.5px] leading-relaxed text-bgc-dim/70">
            A foto é armazenada de forma privada: só você a visualiza, por um link temporário.
          </p>
        </GlassPanel>

        <GlassPanel className="p-5">
          <form onSubmit={submit} className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <Label className="text-[10px] uppercase tracking-[0.14em] text-bgc-dim">Nome</Label>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="mt-1.5 h-10 border-white/10 bg-white/[0.04] text-bgc-ink"
                  placeholder="Seu nome"
                />
              </div>
              <div>
                <Label className="text-[10px] uppercase tracking-[0.14em] text-bgc-dim">Nome de usuário</Label>
                <Input
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="mt-1.5 h-10 border-white/10 bg-white/[0.04] text-bgc-ink"
                  placeholder="ex.: bgc_player"
                />
              </div>
              <div className="sm:col-span-2">
                <Label className="text-[10px] uppercase tracking-[0.14em] text-bgc-dim">E-mail</Label>
                <Input
                  value={user?.email ?? ""}
                  readOnly
                  className="mt-1.5 h-10 cursor-not-allowed border-white/10 bg-white/[0.02] text-bgc-dim"
                />
              </div>
              <div className="sm:col-span-2">
                <Label className="text-[10px] uppercase tracking-[0.14em] text-bgc-dim">Bio</Label>
                <Textarea
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="mt-1.5 min-h-[90px] border-white/10 bg-white/[0.04] text-bgc-ink"
                  placeholder="Conte como você joga e qual é o seu setup."
                />
              </div>
            </div>
            <div className="flex justify-end">
              <ActionButton type="submit" size="sm" loading={saving}>
                <Save className="h-3.5 w-3.5" /> Salvar perfil
              </ActionButton>
            </div>
          </form>
        </GlassPanel>
      </div>
    </div>
  );
}