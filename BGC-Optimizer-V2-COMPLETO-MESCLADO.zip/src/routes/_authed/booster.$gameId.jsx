const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useQuery } from "@tanstack/react-query";
import { Link, createFileRoute } from "@tanstack/react-router";
import { ArrowLeft, Clock, History, Sparkles } from "lucide-react";

import GameArt from "@/components/booster/GameArt";
import GameSettingsPanel from "@/components/booster/GameSettingsPanel";
import PrepareChecklist from "@/components/booster/PrepareChecklist";
import { GlassPanel } from "@/components/glass/GlassPanel";
import EmptyState from "@/components/glass/EmptyState";
import StatusPill from "@/components/glass/StatusPill";
import { PROFILE_KINDS } from "@/lib/constants";
import { fmtDateTime, fmtRelative } from "@/lib/format";
import {
  gameProfilesQuery,
  historyQuery,
  optimizationSettingsQuery,
  recommendationsQuery,
} from "@/lib/queries";
import { useEnsureProfiles } from "@/hooks/useProfiles";

export const Route = createFileRoute("/_authed/booster/$gameId")({
  head: () => ({ meta: [{ title: "Jogo · BGC Optimizer" }] }),
  component: GamePage,
});

function GamePage() {
  const { gameId } = Route.useParams();
  const { data: game, isLoading } = useQuery({
    queryKey: ["game", gameId],
    queryFn: () => db.entities.Game.get(gameId),
  });
  const { data: gameProfiles = [] } = useQuery(gameProfilesQuery());
  const { data: settings = [] } = useQuery(optimizationSettingsQuery());
  const { data: recommendations = [] } = useQuery(recommendationsQuery());
  const { data: history = [] } = useQuery(historyQuery());
  const { active } = useEnsureProfiles();

  if (isLoading) return <div className="glass h-64 animate-pulse rounded-glass" />;

  if (!game) {
    return (
      <EmptyState
        icon={History}
        title="Jogo não encontrado"
        description="Este jogo não está mais na sua biblioteca."
        action={
          <Link to="/booster" className="text-sm font-medium text-bgc-glow hover:underline">
            Voltar ao Game Booster
          </Link>
        }
      />
    );
  }

  const gameProfile = gameProfiles.find((p) => p.game_id === game.id);
  const defaultKeys = active?.settings ?? [];
  const kind = gameProfile?.profile_kind ?? active?.kind ?? "gaming";
  const gameHistory = history.filter((h) => h.entity_ref === game.id).slice(0, 6);
  const relevant = recommendations.filter((r) => r.applies_to === "all" || r.applies_to === kind).slice(0, 4);

  return (
    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
      <Link
        to="/booster"
        className="inline-flex items-center gap-2 text-[11px] font-medium text-bgc-dim transition hover:text-bgc-ink"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Game Booster
      </Link>

      <GlassPanel tone="strong" className="mt-4 overflow-hidden p-0">
        <div className="relative h-52 sm:h-60">
          <GameArt game={game} className="absolute inset-0 h-full w-full" initialsClassName="text-[180px] sm:text-[220px]" />
          <div className="absolute inset-0 flex flex-col justify-end p-5 sm:p-6">
            <div className="flex flex-wrap items-center gap-2">
              <StatusPill tone="green">{game.category || "Jogo"}</StatusPill>
              <StatusPill tone="gray">{PROFILE_KINDS[kind]?.label ?? kind}</StatusPill>
            </div>
            <h1 className="mt-3 font-heading text-3xl font-semibold tracking-tight text-white drop-shadow-lg sm:text-4xl">
              {game.name}
            </h1>
            <p className="mt-1.5 max-w-2xl text-[13px] leading-relaxed text-white/75">{game.description}</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-white/10 p-4 sm:px-6">
          <div className="flex flex-wrap items-center gap-4 text-[11px] text-bgc-dim">
            <span className="inline-flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5" />
              {gameProfile?.last_prepared ? `Preparado ${fmtRelative(gameProfile.last_prepared)}` : "Ainda não preparado"}
            </span>
            <span>{gameProfile?.prepares ?? 0} preparações registradas</span>
            <span>{(gameProfile?.settings ?? defaultKeys).length} ajustes</span>
          </div>
          <PrepareChecklist
            game={game}
            gameProfile={gameProfile}
            settings={settings}
            defaultKeys={defaultKeys}
          />
        </div>
      </GlassPanel>

      <div className="mt-5 grid gap-5 lg:grid-cols-[minmax(0,1fr)_330px]">
        <GameSettingsPanel
          game={game}
          gameProfile={gameProfile}
          settings={settings}
          defaultKeys={defaultKeys}
        />

        <div className="space-y-4">
          <GlassPanel className="p-5">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-bgc-glow" />
              <p className="font-heading text-sm font-semibold text-bgc-ink">Recomendações</p>
            </div>
            <div className="mt-3 space-y-2.5">
              {relevant.length === 0 && <p className="text-xs text-bgc-dim">Nenhuma recomendação para este perfil.</p>}
              {relevant.map((r) => (
                <div key={r.id} className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-3">
                  <p className="text-[12.5px] font-medium text-bgc-ink">{r.title}</p>
                  <p className="mt-1 text-[11px] leading-relaxed text-bgc-dim">{r.reason}</p>
                </div>
              ))}
            </div>
            <Link to="/otimizacoes" className="mt-3 inline-block text-[11px] font-medium text-bgc-glow hover:underline">
              Ver todas →
            </Link>
          </GlassPanel>

          <GlassPanel className="p-5">
            <div className="flex items-center gap-2">
              <History className="h-4 w-4 text-bgc-glow" />
              <p className="font-heading text-sm font-semibold text-bgc-ink">Histórico do jogo</p>
            </div>
            <div className="mt-3 space-y-3">
              {gameHistory.length === 0 && (
                <p className="text-xs text-bgc-dim">Nenhuma ação registrada ainda para este jogo.</p>
              )}
              {gameHistory.map((h) => (
                <div key={h.id} className="border-l border-white/10 pl-3">
                  <p className="text-[12px] font-medium text-bgc-ink">{h.title}</p>
                  {h.detail && <p className="text-[11px] text-bgc-dim">{h.detail}</p>}
                  <p className="mt-0.5 text-[10px] uppercase tracking-wider text-bgc-dim/60">
                    {fmtDateTime(h.created_date)}
                  </p>
                </div>
              ))}
            </div>
            <Link to="/historico" className="mt-3 inline-block text-[11px] font-medium text-bgc-glow hover:underline">
              Histórico completo →
            </Link>
          </GlassPanel>
        </div>
      </div>
    </div>
  );
}