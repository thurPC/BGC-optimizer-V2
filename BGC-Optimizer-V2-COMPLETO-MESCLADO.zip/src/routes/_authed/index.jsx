import { createFileRoute } from "@tanstack/react-router";
import AmbientBackground from "@/components/glass/AmbientBackground";
import WelcomeHero from "@/components/welcome/WelcomeHero";

export const Route = createFileRoute("/_authed/")({
  head: () => ({ meta: [{ title: "Bem-vindo · BGC Optimizer" }] }),
  component: WelcomePage,
});

function WelcomePage() {
  return (
    <div className="relative min-h-dvh overflow-hidden grain">
      <AmbientBackground dense />
      <WelcomeHero />
    </div>
  );
}