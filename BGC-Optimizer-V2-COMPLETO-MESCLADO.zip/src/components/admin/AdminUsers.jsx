const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { UserPlus } from "lucide-react";
import { toast } from "sonner";

import ActionButton from "@/components/glass/ActionButton";
import { GlassPanel } from "@/components/glass/GlassPanel";
import StatusPill from "@/components/glass/StatusPill";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { fmtDate } from "@/lib/format";

export default function AdminUsers() {
  const queryClient = useQueryClient();
  const { data: users = [] } = useQuery({
    queryKey: ["admin-users"],
    queryFn: async () => {
      const result = await db.entities.User.list();
      return Array.isArray(result) ? result : result?.items ?? [];
    },
  });

  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("user");
  const [sending, setSending] = useState(false);

  const invite = async (event) => {
    event.preventDefault();
    if (!email.trim()) return;
    setSending(true);
    try {
      await db.users.inviteUser(email.trim(), role);
      toast.success("Convite enviado.");
      setEmail("");
      setOpen(false);
      queryClient.invalidateQueries({ queryKey: ["admin-users"] });
    } catch {
      toast.error("Não foi possível enviar o convite.");
    } finally {
      setSending(false);
    }
  };

  return (
    <GlassPanel className="overflow-hidden p-0">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/[0.07] px-5 py-4">
        <div>
          <p className="font-heading text-sm font-semibold text-bgc-ink">Usuários</p>
          <p className="text-[11px] text-bgc-dim">{users.length} contas neste aplicativo</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <ActionButton size="sm" variant="secondary">
              <UserPlus className="h-3.5 w-3.5" /> Convidar
            </ActionButton>
          </DialogTrigger>
          <DialogContent className="glass-strong border-white/12 bg-[#0A0F18]/96 text-bgc-ink backdrop-blur-2xl sm:max-w-sm">
            <DialogHeader>
              <DialogTitle className="font-heading">Convidar usuário</DialogTitle>
              <DialogDescription className="text-bgc-dim">
                O convite é enviado por e-mail pela plataforma.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={invite} className="space-y-3">
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="email@exemplo.com"
                className="h-10 border-white/10 bg-white/[0.04] text-bgc-ink"
              />
              <Select value={role} onValueChange={setRole}>
                <SelectTrigger className="h-10 border-white/10 bg-white/[0.04] text-bgc-ink">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="border-white/10 bg-[#0A0F18] text-bgc-ink">
                  <SelectItem value="user">Usuário</SelectItem>
                  <SelectItem value="admin">Administrador</SelectItem>
                </SelectContent>
              </Select>
              <ActionButton type="submit" size="sm" className="w-full" loading={sending} disabled={!email.trim()}>
                Enviar convite
              </ActionButton>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="divide-y divide-white/[0.06]">
        {users.map((user) => (
          <div key={user.id} className="flex flex-wrap items-center gap-3 px-5 py-3">
            <div className="min-w-0 flex-1">
              <p className="truncate text-[13px] font-medium text-bgc-ink">{user.full_name || "Sem nome"}</p>
              <p className="truncate text-[11px] text-bgc-dim">{user.email}</p>
            </div>
            <StatusPill tone={user.role === "admin" ? "green" : "gray"}>
              {user.role === "admin" ? "Administrador" : "Usuário"}
            </StatusPill>
            <span className="text-[10px] uppercase tracking-wider text-bgc-dim/60">{fmtDate(user.created_date)}</span>
          </div>
        ))}
      </div>
    </GlassPanel>
  );
}