const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Megaphone, Trash2 } from "lucide-react";
import { toast } from "sonner";

import ActionButton from "@/components/glass/ActionButton";
import { GlassPanel } from "@/components/glass/GlassPanel";
import StatusPill from "@/components/glass/StatusPill";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { fmtRelative } from "@/lib/format";
import { notificationsQuery } from "@/lib/queries";

const FIELD = "mt-1.5 border-white/10 bg-white/[0.04] text-bgc-ink placeholder:text-bgc-dim/60";

export default function AdminNotifications() {
  const queryClient = useQueryClient();
  const { data: notifications = [] } = useQuery(notificationsQuery());
  const globals = notifications.filter((n) => n.is_global);
  const [form, setForm] = useState({ title: "", message: "", category: "system" });
  const [saving, setSaving] = useState(false);

  const create = async (event) => {
    event.preventDefault();
    if (!form.title.trim() || !form.message.trim()) return;
    setSaving(true);
    try {
      await db.entities.Notification.create({
        title: form.title.trim(),
        message: form.message.trim(),
        category: form.category,
        is_global: true,
        read: false,
      });
      queryClient.invalidateQueries({ queryKey: ["notifications"] });
      toast.success("Notificação global publicada.");
      setForm({ title: "", message: "", category: "system" });
    } finally {
      setSaving(false);
    }
  };

  const remove = async (notification) => {
    await db.entities.Notification.delete(notification.id);
    queryClient.invalidateQueries({ queryKey: ["notifications"] });
    toast.success("Notificação removida.");
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
      <GlassPanel className="p-5">
        <div className="flex items-center gap-2">
          <Megaphone className="h-4 w-4 text-bgc-glow" />
          <p className="font-heading text-sm font-semibold text-bgc-ink">Notificação global</p>
        </div>
        <p className="mt-1 text-[11px] text-bgc-dim">Visível para todos os usuários do aplicativo.</p>
        <form onSubmit={create} className="mt-3 space-y-3">
          <Input
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            placeholder="Título"
            className={FIELD}
          />
          <Textarea
            value={form.message}
            onChange={(e) => setForm({ ...form, message: e.target.value })}
            placeholder="Mensagem"
            className={`${FIELD} min-h-[70px]`}
          />
          <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
            <SelectTrigger className={FIELD}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="border-white/10 bg-[#0A0F18] text-bgc-ink">
              <SelectItem value="system">Sistema</SelectItem>
              <SelectItem value="recommendation">Recomendação</SelectItem>
              <SelectItem value="game">Jogos</SelectItem>
              <SelectItem value="account">Conta</SelectItem>
            </SelectContent>
          </Select>
          <ActionButton
            type="submit"
            size="sm"
            className="w-full"
            loading={saving}
            disabled={!form.title.trim() || !form.message.trim()}
          >
            Publicar
          </ActionButton>
        </form>
      </GlassPanel>

      <GlassPanel className="overflow-hidden p-0">
        <div className="border-b border-white/[0.07] px-5 py-4">
          <p className="font-heading text-sm font-semibold text-bgc-ink">Publicadas</p>
          <p className="text-[11px] text-bgc-dim">{globals.length} notificações globais</p>
        </div>
        <div className="divide-y divide-white/[0.06]">
          {globals.length === 0 && <p className="px-5 py-6 text-xs text-bgc-dim">Nenhuma notificação global publicada.</p>}
          {globals.map((notification) => (
            <div key={notification.id} className="flex items-start gap-3 px-5 py-3">
              <div className="min-w-0 flex-1">
                <p className="truncate text-[13px] font-medium text-bgc-ink">{notification.title}</p>
                <p className="line-clamp-2 text-[11px] text-bgc-dim">{notification.message}</p>
                <p className="mt-1 text-[10px] uppercase tracking-wider text-bgc-dim/60">
                  {fmtRelative(notification.created_date)}
                </p>
              </div>
              <StatusPill tone="gray">{notification.category}</StatusPill>
              <button
                type="button"
                onClick={() => remove(notification)}
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 text-bgc-dim transition hover:border-red-400/40 hover:text-red-300"
                aria-label="Remover notificação"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>
      </GlassPanel>
    </div>
  );
}