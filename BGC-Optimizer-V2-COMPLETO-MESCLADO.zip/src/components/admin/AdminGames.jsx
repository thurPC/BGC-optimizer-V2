const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";

import { GlassPanel } from "@/components/glass/GlassPanel";
import GameArt from "@/components/booster/GameArt";
import AddGameDialog from "@/components/booster/AddGameDialog";
import { gamesQuery } from "@/lib/queries";

export default function AdminGames() {
  const queryClient = useQueryClient();
  const { data: games = [] } = useQuery(gamesQuery());

  const remove = async (game) => {
    await db.entities.Game.delete(game.id);
    queryClient.invalidateQueries({ queryKey: ["games"] });
    toast.success(`${game.name} removido do catálogo.`);
  };

  return (
    <GlassPanel className="overflow-hidden p-0">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/[0.07] px-5 py-4">
        <div>
          <p className="font-heading text-sm font-semibold text-bgc-ink">Jogos do catálogo</p>
          <p className="text-[11px] text-bgc-dim">{games.length} títulos disponíveis para todos os usuários</p>
        </div>
        <AddGameDialog />
      </div>
      <div className="divide-y divide-white/[0.06]">
        {games.map((game) => (
          <div key={game.id} className="flex items-center gap-3 px-5 py-3">
            <GameArt game={game} className="h-10 w-16 shrink-0 rounded-lg" initialsClassName="text-[18px]" />
            <div className="min-w-0 flex-1">
              <p className="truncate text-[13px] font-medium text-bgc-ink">{game.name}</p>
              <p className="truncate text-[11px] text-bgc-dim">{game.category}</p>
            </div>
            <button
              type="button"
              onClick={() => remove(game)}
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 text-bgc-dim transition hover:border-red-400/40 hover:text-red-300"
              aria-label={`Remover ${game.name}`}
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        ))}
      </div>
    </GlassPanel>
  );
}