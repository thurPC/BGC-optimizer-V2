const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useQuery } from "@tanstack/react-query";

import StatTile from "@/components/glass/StatTile";
import { Activity, Gamepad2, Layers, Sparkles, Users } from "lucide-react";

export default function AdminStats() {
  const { data } = useQuery({
    queryKey: ["admin-stats"],
    queryFn: async () => {
      const [users, games, sessions, profiles, recommendations] = await Promise.all([
        db.entities.User.list(),
        db.entities.Game.count({}),
        db.entities.PerformanceSession.count({}),
        db.entities.OptimizationProfile.count({}),
        db.entities.Recommendation.count({}),
      ]);
      const userList = Array.isArray(users) ? users : users?.items ?? [];
      return {
        users: userList.length,
        admins: userList.filter((u) => u.role === "admin").length,
        games,
        sessions,
        profiles,
        recommendations,
      };
    },
  });

  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
      <StatTile label="Usuários" value={data?.users ?? "—"} hint={`${data?.admins ?? 0} administradores`} icon={Users} />
      <StatTile label="Jogos" value={data?.games ?? "—"} icon={Gamepad2} tone="blue" />
      <StatTile label="Sessões" value={data?.sessions ?? "—"} icon={Activity} tone="purple" />
      <StatTile label="Perfis" value={data?.profiles ?? "—"} icon={Layers} tone="yellow" />
      <StatTile label="Recomendações" value={data?.recommendations ?? "—"} icon={Sparkles} tone="gray" />
    </div>
  );
}