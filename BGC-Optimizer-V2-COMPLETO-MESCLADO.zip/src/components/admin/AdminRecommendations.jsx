const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

import ActionButton from "@/components/glass/ActionButton";
import { GlassPanel } from "@/components/glass/GlassPanel";
import StatusPill from "@/components/glass/StatusPill";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { CATEGORY_META } from "@/lib/constants";

const FIELD = "mt-1.5 border-white/10 bg-white/[0.04] text-bgc-ink placeholder:text-bgc-dim/60";

export default function AdminRecommendations() {
  const queryClient = useQueryClient();
  const { data: recommendations = [] } = useQuery({
    queryKey: ["admin-recommendations"],
    queryFn: async () => (await db.entities.Recommendation.filter({}, { limit: 100 })).items ?? [],
  });
  const { data: settings = [] } = useQuery({
    queryKey: ["optimization-settings"],
    queryFn: async () => (await db.entities.OptimizationSetting.filter({}, { limit: 100 })).items ?? [],
  });

  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    title: "",
    category: "windows",
    description: "",
    reason: "",
    impact: "medium",
    linked_setting: "",
    applies_to: "all",
  });

  const create = async (event) => {
    event.preventDefault();
    if (!form.title.trim()) return;
    setSaving(true);
    try {
      await db.entities.Recommendation.create({ ...form, title: form.title.trim(), active: true });
      queryClient.invalidateQueries({ queryKey: ["admin-recommendations"] });
      queryClient.invalidateQueries({ queryKey: ["recommendations"] });
      toast.success("Recomendação criada.");
      setOpen(false);
      setForm({ ...form, title: "", description: "", reason: "" });
    } finally {
      setSaving(false);
    }
  };

  const remove = async (recommendation) => {
    await db.entities.Recommendation.delete(recommendation.id);
    queryClient.invalidateQueries({ queryKey: ["admin-recommendations"] });
    queryClient.invalidateQueries({ queryKey: ["recommendations"] });
    toast.success("Recomendação removida.");
  };

  return (
    <GlassPanel className="overflow-hidden p-0">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/[0.07] px-5 py-4">
        <div>
          <p className="font-heading text-sm font-semibold text-bgc-ink">Recomendações</p>
          <p className="text-[11px] text-bgc-dim">{recommendations.length} recomendações no catálogo</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <ActionButton size="sm" variant="secondary">
              <Plus className="h-3.5 w-3.5" /> Nova
            </ActionButton>
          </DialogTrigger>
          <DialogContent className="glass-strong max-h-[88vh] overflow-y-auto border-white/12 bg-[#0A0F18]/96 text-bgc-ink backdrop-blur-2xl sm:max-w-lg">
            <DialogHeader>
              <DialogTitle className="font-heading">Nova recomendação</DialogTitle>
              <DialogDescription className="text-bgc-dim">
                Aparece para todos os usuários conforme o objetivo e o perfil.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={create} className="space-y-3">
              <Input
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="Título"
                className={FIELD}
              />
              <Textarea
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="Descrição"
                className={`${FIELD} min-h-[70px]`}
              />
              <Input
                value={form.reason}
                onChange={(e) => setForm({ ...form, reason: e.target.value })}
                placeholder="Por que é recomendada"
                className={FIELD}
              />
              <div className="grid gap-3 sm:grid-cols-2">
                <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                  <SelectTrigger className={FIELD}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-white/10 bg-[#0A0F18] text-bgc-ink">
                    {Object.entries(CATEGORY_META).map(([key, meta]) => (
                      <SelectItem key={key} value={key}>
                        {meta.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={form.impact} onValueChange={(v) => setForm({ ...form, impact: v })}>
                  <SelectTrigger className={FIELD}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-white/10 bg-[#0A0F18] text-bgc-ink">
                    <SelectItem value="low">Impacto baixo</SelectItem>
                    <SelectItem value="medium">Impacto médio</SelectItem>
                    <SelectItem value="high">Impacto alto</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={form.linked_setting} onValueChange={(v) => setForm({ ...form, linked_setting: v })}>
                  <SelectTrigger className={FIELD}>
                    <SelectValue placeholder="Ajuste vinculado" />
                  </SelectTrigger>
                  <SelectContent className="max-h-64 border-white/10 bg-[#0A0F18] text-bgc-ink">
                    {settings.map((s) => (
                      <SelectItem key={s.key} value={s.key}>
                        {s.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={form.applies_to} onValueChange={(v) => setForm({ ...form, applies_to: v })}>
                  <SelectTrigger className={FIELD}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-white/10 bg-[#0A0F18] text-bgc-ink">
                    {["all", "games", "latency", "stability", "balance", "experience", "windows"].map((o) => (
                      <SelectItem key={o} value={o}>
                        {o}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <ActionButton type="submit" size="sm" className="w-full" loading={saving} disabled={!form.title.trim()}>
                Criar recomendação
              </ActionButton>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="divide-y divide-white/[0.06]">
        {recommendations.map((recommendation) => (
          <div key={recommendation.id} className="flex items-center gap-3 px-5 py-3">
            <div className="min-w-0 flex-1">
              <p className="truncate text-[13px] font-medium text-bgc-ink">{recommendation.title}</p>
              <p className="truncate text-[11px] text-bgc-dim">{recommendation.reason || recommendation.description}</p>
            </div>
            <StatusPill tone="gray">{CATEGORY_META[recommendation.category]?.label ?? recommendation.category}</StatusPill>
            <StatusPill tone={recommendation.impact === "high" ? "green" : recommendation.impact === "medium" ? "yellow" : "gray"}>
              {recommendation.impact}
            </StatusPill>
            <button
              type="button"
              onClick={() => remove(recommendation)}
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 text-bgc-dim transition hover:border-red-400/40 hover:text-red-300"
              aria-label="Remover recomendação"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        ))}
      </div>
    </GlassPanel>
  );
}