import { Link } from "@tanstack/react-router";
import { ArrowUpRight, Settings2 } from "lucide-react";
import GameArt from "@/components/booster/GameArt";
import StatusPill from "@/components/glass/StatusPill";
import { PROFILE_KINDS } from "@/lib/constants";
import { fmtRelative } from "@/lib/format";

const TONE = { gaming: "green", competitive: "blue", performance: "purple", balanced: "yellow", custom: "red" };

export default function GameCard({ game, gameProfile }) {
  const kind = gameProfile?.profile_kind;

  return (
    <Link to="/booster/$gameId" params={{ gameId: game.id }} className="group block">
      <div className="glass glass-hover overflow-hidden">
        <GameArt game={game} className="h-32" />
        <div className="p-4">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <p className="truncate font-heading text-[15px] font-semibold text-bgc-ink">{game.name}</p>
              <p className="truncate text-[11px] uppercase tracking-wider text-bgc-dim">{game.category || "Jogo"}</p>
            </div>
            <ArrowUpRight className="h-4 w-4 shrink-0 text-bgc-dim transition group-hover:text-bgc-glow" />
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-2">
            {kind ? (
              <StatusPill tone={TONE[kind] ?? "green"}>{PROFILE_KINDS[kind]?.label ?? kind}</StatusPill>
            ) : (
              <StatusPill tone="gray">Sem perfil</StatusPill>
            )}
            {gameProfile?.last_prepared && (
              <span className="text-[10px] uppercase tracking-wider text-bgc-dim/70">
                {fmtRelative(gameProfile.last_prepared)}
              </span>
            )}
          </div>

          <div className="mt-4 flex items-center justify-between border-t border-white/[0.07] pt-3">
            <span className="inline-flex items-center gap-1.5 text-[11px] font-medium text-bgc-dim">
              <Settings2 className="h-3.5 w-3.5" />
              {(gameProfile?.settings ?? []).length} ajustes
            </span>
            <span className="text-[11px] font-semibold text-bgc-glow">Configurar →</span>
          </div>
        </div>
      </div>
    </Link>
  );
}