import { cn } from "@/lib/utils";

/** Generated cover art for a game — gradient, light and typographic watermark. */
export default function GameArt({ game, className, initialsClassName }) {
  const from = game?.accent_from ?? "#22C55E";
  const to = game?.accent_to ?? "#0F3D2A";

  return (
    <div className={cn("relative overflow-hidden", className)} style={{ background: `linear-gradient(135deg, ${from}, ${to})` }}>
      <div
        className="absolute inset-0"
        style={{ background: "radial-gradient(ellipse 70% 90% at 15% 10%, rgba(255,255,255,0.30), transparent 55%)" }}
      />
      <div
        className="absolute inset-0 opacity-50"
        style={{
          backgroundImage:
            "repeating-linear-gradient(115deg, rgba(255,255,255,0.09) 0 1px, transparent 1px 24px)",
        }}
      />
      <div
        className={cn(
          "absolute -bottom-6 right-2 select-none font-heading font-extrabold leading-none tracking-tighter text-white/15",
          initialsClassName ?? "text-[92px]"
        )}
      >
        {game?.initials || "BGC"}
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/10 to-transparent" />
    </div>
  );
}