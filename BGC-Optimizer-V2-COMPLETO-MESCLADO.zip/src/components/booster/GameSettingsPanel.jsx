const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Check, Save } from "lucide-react";
import { toast } from "sonner";

import ActionButton from "@/components/glass/ActionButton";
import { GlassPanel } from "@/components/glass/GlassPanel";
import { CATEGORY_META, PROFILE_KINDS } from "@/lib/constants";
import { logActivity } from "@/lib/queries";
import { cn } from "@/lib/utils";

export default function GameSettingsPanel({ game, gameProfile, settings, defaultKeys, onSaved }) {
  const queryClient = useQueryClient();
  const [selected, setSelected] = useState([]);
  const [kind, setKind] = useState("gaming");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setSelected(gameProfile?.settings?.length ? gameProfile.settings : defaultKeys ?? []);
    setKind(gameProfile?.profile_kind ?? "gaming");
    setNotes(gameProfile?.notes ?? "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gameProfile?.id]);

  const toggle = (key) =>
    setSelected((current) => (current.includes(key) ? current.filter((k) => k !== key) : [...current, key]));

  const save = async () => {
    setSaving(true);
    try {
      const payload = {
        game_id: game.id,
        game_name: game.name,
        profile_kind: kind,
        settings: selected,
        notes,
        prepares: gameProfile?.prepares ?? 0,
        last_prepared: gameProfile?.last_prepared ?? null,
      };
      if (gameProfile?.id) await db.entities.GameProfile.update(gameProfile.id, payload);
      else await db.entities.GameProfile.create(payload);

      await logActivity({
        action_type: "game_configured",
        title: `Configurações salvas — ${game.name}`,
        detail: `${selected.length} ajustes no perfil ${PROFILE_KINDS[kind]?.label ?? kind}.`,
        entity_ref: game.id,
        entity_name: "Game",
        snapshot: { settings: selected, profile_kind: kind },
      });
      queryClient.invalidateQueries({ queryKey: ["game-profiles"] });
      queryClient.invalidateQueries({ queryKey: ["history"] });
      onSaved?.();
      toast.success("Configurações do jogo salvas.");
    } finally {
      setSaving(false);
    }
  };

  const grouped = {};
  settings.forEach((s) => {
    grouped[s.category] = grouped[s.category] ?? [];
    grouped[s.category].push(s);
  });

  return (
    <GlassPanel className="p-5">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-bgc-dim">Perfil de desempenho</p>
          <p className="mt-1 font-heading text-base font-semibold text-bgc-ink">Configurações salvas</p>
        </div>
        <ActionButton size="sm" onClick={save} loading={saving}>
          <Save className="h-3.5 w-3.5" /> Salvar
        </ActionButton>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {Object.entries(PROFILE_KINDS).map(([key, meta]) => (
          <button
            key={key}
            type="button"
            onClick={() => setKind(key)}
            className={cn(
              "rounded-full border px-3 py-1.5 text-[11px] font-medium transition",
              kind === key
                ? "border-bgc-glow/50 bg-bgc-glow/10 text-bgc-glow"
                : "border-white/10 bg-white/[0.03] text-bgc-dim hover:border-white/25 hover:text-bgc-ink"
            )}
          >
            {meta.label}
          </button>
        ))}
      </div>

      <div className="mt-5 space-y-4">
        {Object.entries(grouped).map(([category, items]) => (
          <div key={category}>
            <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-bgc-dim">
              {CATEGORY_META[category]?.label ?? category}
            </p>
            <div className="grid gap-1.5 sm:grid-cols-2">
              {items.map((item) => {
                const active = selected.includes(item.key);
                return (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => toggle(item.key)}
                    className={cn(
                      "flex items-center gap-2.5 rounded-lg border px-3 py-2 text-left transition",
                      active
                        ? "border-bgc-glow/30 bg-bgc-glow/[0.06]"
                        : "border-white/[0.07] bg-white/[0.02] hover:border-white/20"
                    )}
                  >
                    <span
                      className={cn(
                        "flex h-4 w-4 shrink-0 items-center justify-center rounded border",
                        active ? "border-bgc-glow bg-bgc-glow text-[#04140B]" : "border-white/25 text-transparent"
                      )}
                    >
                      <Check className="h-2.5 w-2.5" />
                    </span>
                    <span className="truncate text-[12px] text-bgc-ink">{item.title}</span>
                    {item.requires_agent && (
                      <span className="ml-auto shrink-0 text-[9px] uppercase tracking-wider text-amber-300/80">agente</span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-5">
        <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-bgc-dim">Anotações do jogo</p>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={3}
          placeholder="Ex.: usar preset gráfico médio, vsync desligado, driver 566.36 validado."
          className="w-full rounded-xl border border-white/10 bg-white/[0.03] p-3 text-[13px] text-bgc-ink placeholder:text-bgc-dim/60 focus:border-bgc-glow/40 focus:outline-none"
        />
      </div>
    </GlassPanel>
  );
}