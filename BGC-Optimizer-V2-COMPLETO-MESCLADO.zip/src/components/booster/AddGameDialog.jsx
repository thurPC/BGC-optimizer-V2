const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Plus } from "lucide-react";

import ActionButton from "@/components/glass/ActionButton";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const PALETTE = [
  { from: "#22C55E", to: "#0F3D2A" },
  { from: "#38BDF8", to: "#0C4A6E" },
  { from: "#A78BFA", to: "#2E1065" },
  { from: "#F59E0B", to: "#7C2D12" },
  { from: "#F43F5E", to: "#4C0519" },
  { from: "#22D3EE", to: "#083344" },
];

const initialsFor = (name) =>
  name
    .trim()
    .split(/\s+/)
    .map((w) => w[0])
    .join("")
    .slice(0, 3)
    .toUpperCase();

export default function AddGameDialog() {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [saving, setSaving] = useState(false);

  const create = async (event) => {
    event.preventDefault();
    if (!name.trim()) return;
    setSaving(true);
    try {
      const colors = PALETTE[Math.floor(Math.random() * PALETTE.length)];
      await db.entities.Game.create({
        name: name.trim(),
        slug: name.trim().toLowerCase().replace(/\s+/g, "-"),
        category: category.trim() || "Personalizado",
        initials: initialsFor(name) || "BGC",
        accent_from: colors.from,
        accent_to: colors.to,
        is_custom: true,
        active: true,
        sort_order: 500,
      });
      queryClient.invalidateQueries({ queryKey: ["games"] });
      setName("");
      setCategory("");
      setOpen(false);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <ActionButton size="sm">
          <Plus className="h-4 w-4" /> Adicionar jogo
        </ActionButton>
      </DialogTrigger>
      <DialogContent className="glass-strong border-white/12 bg-[#0A0F18]/95 text-bgc-ink backdrop-blur-2xl sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-heading">Adicionar jogo personalizado</DialogTitle>
          <DialogDescription className="text-bgc-dim">
            O jogo entra na sua biblioteca e pode receber perfil e checklist próprios.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={create} className="space-y-4">
          <div>
            <Label className="text-[11px] uppercase tracking-[0.14em] text-bgc-dim">Nome do jogo</Label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex.: Apex Legends"
              className="mt-1.5 h-11 border-white/10 bg-white/[0.04] text-bgc-ink placeholder:text-bgc-dim/60"
            />
          </div>
          <div>
            <Label className="text-[11px] uppercase tracking-[0.14em] text-bgc-dim">Categoria</Label>
            <Input
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              placeholder="Ex.: FPS tático"
              className="mt-1.5 h-11 border-white/10 bg-white/[0.04] text-bgc-ink placeholder:text-bgc-dim/60"
            />
          </div>
          <div className="flex justify-end gap-2 pt-1">
            <ActionButton variant="ghost" size="sm" onClick={() => setOpen(false)}>
              Cancelar
            </ActionButton>
            <ActionButton type="submit" size="sm" loading={saving} disabled={!name.trim()}>
              Adicionar
            </ActionButton>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}