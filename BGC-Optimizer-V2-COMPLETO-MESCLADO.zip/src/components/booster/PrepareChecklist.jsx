const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Ban, Check, Clock, Rocket, ShieldAlert, Thermometer, Cpu } from "lucide-react";
import { toast } from "sonner";

import ActionButton from "@/components/glass/ActionButton";
import StatusPill from "@/components/glass/StatusPill";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { CATEGORY_META, PROFILE_KINDS } from "@/lib/constants";
import { fetchComputer, fetchLatestGameMetric, logActivity } from "@/lib/queries";
import { buildBeforeState } from "@/lib/prepare";
import { fmtDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";

const STATUS = { pending: "pending", done: "done", skipped: "skipped" };

export default function PrepareChecklist({ game, gameProfile, settings, defaultKeys }) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [statuses, setStatuses] = useState({});
  const [beforeState, setBeforeState] = useState(null);
  const [startedAt, setStartedAt] = useState(null);
  const [capturing, setCapturing] = useState(false);

  const { data: computer } = useQuery({
    queryKey: ["computer"],
    queryFn: fetchComputer,
  });

  const planned = useMemo(() => {
    const keys = gameProfile?.settings?.length ? gameProfile.settings : defaultKeys;
    return settings.filter((s) => keys.includes(s.key));
  }, [gameProfile, defaultKeys, settings]);

  const grouped = useMemo(() => {
    const map = {};
    planned.forEach((s) => {
      map[s.category] = map[s.category] ?? [];
      map[s.category].push(s);
    });
    return map;
  }, [planned]);

  const openChecklist = async () => {
    setOpen(true);
    setCapturing(true);
    const start = new Date().toISOString();
    setStartedAt(start);
    setStatuses(Object.fromEntries(planned.map((s) => [s.key, STATUS.pending])));
    try {
      const metric = await fetchLatestGameMetric(game.name, start);
      setBeforeState(buildBeforeState({ computer, metric }));
    } catch {
      setBeforeState(buildBeforeState({ computer, metric: null }));
    } finally {
      setCapturing(false);
    }
    logActivity({
      action_type: "checklist_started",
      title: `Checklist iniciado — ${game.name}`,
      detail: `${planned.length} configurações no checklist.`,
      entity_ref: game.id,
      entity_name: "Game",
    }).then(() => queryClient.invalidateQueries({ queryKey: ["history"] }));
  };

  const cycle = (key) =>
    setStatuses((cur) => {
      const next = { ...cur };
      const order = [STATUS.pending, STATUS.done, STATUS.skipped];
      next[key] = order[(order.indexOf(cur[key] ?? STATUS.pending) + 1) % order.length];
      return next;
    });

  const done = planned.filter((s) => statuses[s.key] === STATUS.done);
  const skipped = planned.filter((s) => statuses[s.key] === STATUS.skipped);
  const pending = planned.filter((s) => statuses[s.key] === STATUS.pending);

  const complete = async () => {
    setSaving(true);
    try {
      const completedAt = new Date().toISOString();
      const doneKeys = done.map((s) => s.key);
      const skippedKeys = skipped.map((s) => s.key);
      const pendingKeys = pending.map((s) => s.key);

      const payload = {
        game_id: game.id,
        game_name: game.name,
        profile_kind: gameProfile?.profile_kind ?? "gaming",
        profile_name: PROFILE_KINDS[gameProfile?.profile_kind ?? "gaming"]?.label ?? "",
        started_at: startedAt ?? completedAt,
        completed_at: completedAt,
        before_state: beforeState ? JSON.stringify(beforeState) : "",
        after_session_id: "",
        checklist_total: planned.length,
        checklist_done: doneKeys,
        checklist_skipped: skippedKeys,
        checklist_pending: pendingKeys,
        adjustments: done.map((s) => s.title),
        pending_items: pending.map((s) => s.title),
        has_real_comparison: false,
        source: "web",
        notes: gameProfile?.notes ?? "",
      };
      const prepareSession = await db.entities.PrepareSession.create(payload);

      const profilePayload = {
        game_id: game.id,
        game_name: game.name,
        profile_kind: gameProfile?.profile_kind ?? "gaming",
        settings: doneKeys.length ? doneKeys : gameProfile?.settings ?? defaultKeys,
        notes: gameProfile?.notes ?? "",
        prepares: (gameProfile?.prepares ?? 0) + 1,
        last_prepared: completedAt,
      };
      if (gameProfile?.id) await db.entities.GameProfile.update(gameProfile.id, profilePayload);
      else await db.entities.GameProfile.create(profilePayload);

      await logActivity({
        action_type: "session_recorded",
        title: `Preparação concluída — ${game.name}`,
        detail: `${doneKeys.length} verificados, ${pendingKeys.length} pendentes, ${skippedKeys.length} ignorados.`,
        entity_ref: game.id,
        entity_name: "Game",
        snapshot: { prepare_session: prepareSession.id, done: doneKeys, pending: pendingKeys, skipped: skippedKeys },
      });
      await db.entities.Notification.create({
        title: "Preparação registrada",
        message: `${game.name} está pronto. ${doneKeys.length} ajustes verificados no aplicativo.`,
        category: "game",
        read: false,
        is_global: false,
        link: `/sessao/${prepareSession.id}`,
      });

      queryClient.invalidateQueries({ queryKey: ["prepare-sessions"] });
      queryClient.invalidateQueries({ queryKey: ["game-profiles"] });
      queryClient.invalidateQueries({ queryKey: ["history"] });
      queryClient.invalidateQueries({ queryKey: ["notifications"] });
      toast.success("Preparação registrada na sua conta.");
      setOpen(false);
      navigate({ to: "/sessao/$sessionId", params: { sessionId: prepareSession.id } });
    } finally {
      setSaving(false);
    }
  };

  const agentConnected = beforeState?.agent?.connected ?? computer?.connection_state === "connected";
  const hasMetric = !!beforeState?.metric;

  return (
    <Dialog open={open} onOpenChange={(value) => (value ? openChecklist() : setOpen(false))}>
      <DialogTrigger asChild>
        <ActionButton size="lg" onClick={openChecklist}>
          <Rocket className="h-4 w-4" /> Preparar para jogar
        </ActionButton>
      </DialogTrigger>
      <DialogContent className="glass-strong max-h-[88vh] overflow-y-auto border-white/12 bg-[#0A0F18]/96 text-bgc-ink backdrop-blur-2xl sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-heading">Preparar — {game.name}</DialogTitle>
          <DialogDescription className="text-bgc-dim">
            Toque em cada item para alternar: pendente → verificado → ignorado. O estado real do PC é capturado agora.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-2.5 sm:grid-cols-3">
          <div className="rounded-xl border border-white/[0.08] bg-white/[0.02] p-3">
            <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-bgc-dim">
              <Cpu className="h-3 w-3" /> Agente Windows
            </div>
            <p className="mt-1 text-[12px] font-medium text-bgc-ink">
              {capturing ? "Verificando…" : agentConnected ? "Conectado" : "Não conectado"}
            </p>
          </div>
          <div className="rounded-xl border border-white/[0.08] bg-white/[0.02] p-3">
            <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-bgc-dim">
              <Thermometer className="h-3 w-3" /> Métrica anterior
            </div>
            <p className="mt-1 text-[12px] font-medium text-bgc-ink">
              {capturing ? "Buscando…" : hasMetric ? "Disponível" : "Sem medição"}
            </p>
          </div>
          <div className="rounded-xl border border-white/[0.08] bg-white/[0.02] p-3">
            <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-bgc-dim">
              <Clock className="h-3 w-3" /> Iniciado em
            </div>
            <p className="mt-1 text-[12px] font-medium text-bgc-ink">{startedAt ? fmtDateTime(startedAt) : "—"}</p>
          </div>
        </div>

        {!agentConnected && !capturing && (
          <div className="rounded-xl border border-amber-400/20 bg-amber-400/[0.06] p-3">
            <p className="flex items-start gap-2 text-[11px] leading-relaxed text-amber-200/90">
              <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              O agente Windows não está conectado. Hardware e métricas reais ficarão indisponíveis até a conexão — nada é inventado.
            </p>
          </div>
        )}

        {planned.length === 0 ? (
          <p className="rounded-xl border border-white/10 bg-white/[0.03] p-4 text-sm text-bgc-dim">
            Nenhuma configuração definida para este jogo ainda. Salve as configurações abaixo para montar seu checklist.
          </p>
        ) : (
          <div className="space-y-4">
            {Object.entries(grouped).map(([category, items]) => (
              <div key={category}>
                <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-bgc-dim">
                  {CATEGORY_META[category]?.label ?? category}
                </p>
                <div className="space-y-1.5">
                  {items.map((item) => {
                    const st = statuses[item.key] ?? STATUS.pending;
                    return (
                      <button
                        key={item.key}
                        type="button"
                        onClick={() => cycle(item.key)}
                        className={cn(
                          "flex w-full items-start gap-3 rounded-xl border px-3 py-2.5 text-left transition",
                          st === STATUS.done
                            ? "border-bgc-glow/35 bg-bgc-glow/[0.07]"
                            : st === STATUS.skipped
                              ? "border-white/10 bg-white/[0.01] opacity-60"
                              : "border-white/[0.08] bg-white/[0.02] hover:border-white/20"
                        )}
                      >
                        <span
                          className={cn(
                            "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border",
                            st === STATUS.done
                              ? "border-bgc-glow bg-bgc-glow text-[#04140B]"
                              : st === STATUS.skipped
                                ? "border-white/30 bg-white/5 text-white/70"
                                : "border-white/25 text-transparent"
                          )}
                        >
                          {st === STATUS.done ? (
                            <Check className="h-2.5 w-2.5" />
                          ) : st === STATUS.skipped ? (
                            <Ban className="h-2.5 w-2.5" />
                          ) : null}
                        </span>
                        <span className="min-0 flex-1">
                          <span className="block text-[13px] font-medium text-bgc-ink">{item.title}</span>
                          <span className="mt-0.5 block text-[11px] leading-relaxed text-bgc-dim">{item.summary}</span>
                        </span>
                        <span
                          className={cn(
                            "ml-auto shrink-0 text-[9px] font-semibold uppercase tracking-wider",
                            st === STATUS.done
                              ? "text-bgc-glow"
                              : st === STATUS.skipped
                                ? "text-bgc-dim"
                                : "text-amber-300/80"
                          )}
                        >
                          {st === STATUS.done ? "Verificado" : st === STATUS.skipped ? "Ignorado" : "Pendente"}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="rounded-xl border border-amber-400/20 bg-amber-400/[0.06] p-3">
          <p className="flex items-start gap-2 text-[11px] leading-relaxed text-amber-200/90">
            <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            O BGC Optimizer registra a preparação no aplicativo. Nenhuma alteração é aplicada no Windows nesta versão — checklist concluído não significa otimização aplicada.
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="flex flex-wrap items-center gap-2">
            <StatusPill tone="green">{done.length} verificados</StatusPill>
            <StatusPill tone="yellow">{pending.length} pendentes</StatusPill>
            <StatusPill tone="gray">{skipped.length} ignorados</StatusPill>
          </div>
          <ActionButton onClick={complete} loading={saving} disabled={planned.length === 0}>
            Concluir e ver resumo
          </ActionButton>
        </div>
      </DialogContent>
    </Dialog>
  );
}