import { Check, Sparkles } from "lucide-react";
import { GlassPanel } from "@/components/glass/GlassPanel";
import MeterBar from "@/components/glass/MeterBar";
import { MAINTENANCE_TASKS } from "@/lib/constants";
import { cn } from "@/lib/utils";

export default function MaintenanceList({ checks, onToggle }) {
  const done = MAINTENANCE_TASKS.filter((t) => checks.includes(t.id)).length;

  return (
    <GlassPanel className="p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-bgc-dim">Checklist de manutenção</p>
          <p className="mt-1 font-heading text-base font-semibold text-bgc-ink">Rotina recomendada</p>
        </div>
        <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-bgc-glow/25 bg-bgc-glow/10 text-bgc-glow">
          <Sparkles className="h-4 w-4" />
        </span>
      </div>

      <MeterBar
        className="mt-4"
        value={done}
        max={MAINTENANCE_TASKS.length}
        label="Itens concluídos"
        sublabel={`${done}/${MAINTENANCE_TASKS.length}`}
        tone={done === MAINTENANCE_TASKS.length ? "green" : "blue"}
      />

      <div className="mt-4 space-y-1.5">
        {MAINTENANCE_TASKS.map((task) => {
          const active = checks.includes(task.id);
          return (
            <button
              key={task.id}
              type="button"
              onClick={() => onToggle(task.id)}
              className={cn(
                "flex w-full items-start gap-3 rounded-xl border px-3 py-2.5 text-left transition",
                active
                  ? "border-bgc-glow/30 bg-bgc-glow/[0.06]"
                  : "border-white/[0.07] bg-white/[0.02] hover:border-white/20"
              )}
            >
              <span
                className={cn(
                  "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border",
                  active ? "border-bgc-glow bg-bgc-glow text-[#04140B]" : "border-white/25 text-transparent"
                )}
              >
                <Check className="h-2.5 w-2.5" />
              </span>
              <span className="min-w-0">
                <span className={cn("block text-[12.5px] font-medium", active ? "text-bgc-ink" : "text-bgc-ink/85")}>
                  {task.title}
                </span>
                <span className="mt-0.5 block text-[11px] leading-relaxed text-bgc-dim">{task.hint}</span>
              </span>
            </button>
          );
        })}
      </div>
    </GlassPanel>
  );
}