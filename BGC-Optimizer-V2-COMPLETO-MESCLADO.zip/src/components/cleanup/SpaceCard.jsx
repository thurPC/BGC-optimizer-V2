const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { HardDrive, Save } from "lucide-react";
import { toast } from "sonner";

import { GlassPanel } from "@/components/glass/GlassPanel";
import MeterBar from "@/components/glass/MeterBar";
import ActionButton from "@/components/glass/ActionButton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { fmtNumber } from "@/lib/format";
import { logActivity } from "@/lib/queries";

export default function SpaceCard({ computer }) {
  const queryClient = useQueryClient();
  const [free, setFree] = useState("");
  const [total, setTotal] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setFree(computer?.free_space_gb ?? "");
    setTotal(computer?.total_space_gb ?? "");
  }, [computer]);

  const save = async () => {
    if (!computer?.id) return;
    setSaving(true);
    try {
      await db.entities.ComputerProfile.update(computer.id, {
        free_space_gb: free === "" ? null : Number(free),
        total_space_gb: total === "" ? null : Number(total),
      });
      await logActivity({
        action_type: "cleanup_logged",
        title: "Espaço em disco atualizado",
        detail: `${fmtNumber(free)} GB livres de ${fmtNumber(total)} GB.`,
        entity_ref: computer.id,
        entity_name: "ComputerProfile",
      });
      queryClient.invalidateQueries({ queryKey: ["computer"] });
      queryClient.invalidateQueries({ queryKey: ["history"] });
      toast.success("Espaço atualizado.");
    } finally {
      setSaving(false);
    }
  };

  const pct = total && free ? (Number(free) / Number(total)) * 100 : 0;

  return (
    <GlassPanel className="p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-bgc-dim">Espaço informado</p>
          <p className="mt-1 font-heading text-base font-semibold text-bgc-ink">
            {computer?.storage_label || computer?.name || "Sem computador"}
          </p>
        </div>
        <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-amber-400/25 bg-amber-400/10 text-amber-300">
          <HardDrive className="h-4 w-4" />
        </span>
      </div>

      <MeterBar
        className="mt-4"
        value={Number(free) || 0}
        max={Number(total) || 1}
        label="Livre"
        sublabel={`${fmtNumber(pct, 0)}%`}
        tone={pct < 15 ? "red" : pct < 30 ? "yellow" : "green"}
      />

      <div className="mt-4 grid grid-cols-2 gap-3">
        <div>
          <Label className="text-[10px] uppercase tracking-[0.14em] text-bgc-dim">Livre (GB)</Label>
          <Input
            type="number"
            value={free}
            onChange={(e) => setFree(e.target.value)}
            className="mt-1.5 h-10 border-white/10 bg-white/[0.04] text-bgc-ink"
          />
        </div>
        <div>
          <Label className="text-[10px] uppercase tracking-[0.14em] text-bgc-dim">Total (GB)</Label>
          <Input
            type="number"
            value={total}
            onChange={(e) => setTotal(e.target.value)}
            className="mt-1.5 h-10 border-white/10 bg-white/[0.04] text-bgc-ink"
          />
        </div>
      </div>

      <ActionButton size="sm" className="mt-3 w-full" onClick={save} loading={saving} disabled={!computer?.id}>
        <Save className="h-3.5 w-3.5" /> Atualizar espaço
      </ActionButton>

      <p className="mt-3 text-[10.5px] leading-relaxed text-bgc-dim/70">
        Você informa os valores. O BGC Optimizer não acessa nem apaga arquivos do seu computador.
      </p>
    </GlassPanel>
  );
}