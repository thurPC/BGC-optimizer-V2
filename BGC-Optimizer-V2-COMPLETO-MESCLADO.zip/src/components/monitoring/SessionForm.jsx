const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Plus } from "lucide-react";
import { toast } from "sonner";

import ActionButton from "@/components/glass/ActionButton";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { logActivity } from "@/lib/queries";
import { localInputValue } from "@/lib/format";

const FIELD = "mt-1.5 h-10 border-white/10 bg-white/[0.04] text-bgc-ink placeholder:text-bgc-dim/60";
const num = (v) => (v === "" || v === null || v === undefined ? null : Number(v));

function Field({ label, children }) {
  return (
    <div>
      <Label className="text-[10px] font-medium uppercase tracking-[0.14em] text-bgc-dim">{label}</Label>
      {children}
    </div>
  );
}

export default function SessionForm({ games = [], profiles = [] }) {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    game_name: "",
    recorded_at: localInputValue(),
    fps_avg: "",
    fps_1_low: "",
    fps_01_low: "",
    frametime_ms: "",
    cpu_usage: "",
    gpu_usage: "",
    ram_usage: "",
    gpu_temp_c: "",
    cpu_temp_c: "",
    duration_min: "",
    profile_name: "",
    notes: "",
  });

  const set = (key) => (event) => setForm({ ...form, [key]: event.target.value });

  const save = async (event) => {
    event.preventDefault();
    if (!form.game_name.trim()) return;
    setSaving(true);
    try {
      await db.entities.PerformanceSession.create({
        game_name: form.game_name.trim(),
        source: "manual",
        fps_avg: num(form.fps_avg),
        fps_1_low: num(form.fps_1_low),
        fps_01_low: num(form.fps_01_low),
        frametime_ms: num(form.frametime_ms),
        cpu_usage: num(form.cpu_usage),
        gpu_usage: num(form.gpu_usage),
        ram_usage: num(form.ram_usage),
        gpu_temp_c: num(form.gpu_temp_c),
        cpu_temp_c: num(form.cpu_temp_c),
        duration_min: num(form.duration_min),
        profile_name: form.profile_name,
        notes: form.notes,
        recorded_at: new Date(form.recorded_at).toISOString(),
      });
      await logActivity({
        action_type: "session_recorded",
        title: `Sessão registrada — ${form.game_name.trim()}`,
        detail: form.fps_avg ? `FPS médio ${form.fps_avg} · 1% low ${form.fps_1_low || "—"}` : "Registro manual",
        entity_name: "PerformanceSession",
      });
      queryClient.invalidateQueries({ queryKey: ["sessions"] });
      queryClient.invalidateQueries({ queryKey: ["history"] });
      toast.success("Sessão registrada.");
      setOpen(false);
      setForm({ ...form, game_name: "", fps_avg: "", fps_1_low: "", fps_01_low: "", frametime_ms: "", notes: "" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <ActionButton size="sm">
          <Plus className="h-4 w-4" /> Registrar sessão
        </ActionButton>
      </DialogTrigger>
      <DialogContent className="glass-strong max-h-[88vh] overflow-y-auto border-white/12 bg-[#0A0F18]/96 text-bgc-ink backdrop-blur-2xl sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="font-heading">Registrar sessão</DialogTitle>
          <DialogDescription className="text-bgc-dim">
            Informe as métricas medidas pelo seu jogo, launcher ou ferramenta de captura. Fonte: manual.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={save} className="grid gap-3 sm:grid-cols-2">
          <Field label="Jogo">
            <Select value={form.game_name} onValueChange={(v) => setForm({ ...form, game_name: v })}>
              <SelectTrigger className={FIELD}>
                <SelectValue placeholder="Selecione o jogo" />
              </SelectTrigger>
              <SelectContent className="border-white/10 bg-[#0A0F18] text-bgc-ink">
                {games.map((g) => (
                  <SelectItem key={g.id} value={g.name}>
                    {g.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Data e hora">
            <Input className={FIELD} type="datetime-local" value={form.recorded_at} onChange={set("recorded_at")} />
          </Field>
          <Field label="Perfil usado">
            <Select value={form.profile_name} onValueChange={(v) => setForm({ ...form, profile_name: v })}>
              <SelectTrigger className={FIELD}>
                <SelectValue placeholder="Opcional" />
              </SelectTrigger>
              <SelectContent className="border-white/10 bg-[#0A0F18] text-bgc-ink">
                {profiles.map((p) => (
                  <SelectItem key={p.id} value={p.name}>
                    {p.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Duração (min)">
            <Input className={FIELD} type="number" value={form.duration_min} onChange={set("duration_min")} placeholder="45" />
          </Field>
          <Field label="FPS médio">
            <Input className={FIELD} type="number" value={form.fps_avg} onChange={set("fps_avg")} placeholder="240" />
          </Field>
          <Field label="1% low">
            <Input className={FIELD} type="number" value={form.fps_1_low} onChange={set("fps_1_low")} placeholder="180" />
          </Field>
          <Field label="0,1% low">
            <Input className={FIELD} type="number" value={form.fps_01_low} onChange={set("fps_01_low")} placeholder="150" />
          </Field>
          <Field label="Frametime (ms)">
            <Input className={FIELD} type="number" step="0.01" value={form.frametime_ms} onChange={set("frametime_ms")} placeholder="4.2" />
          </Field>
          <Field label="Uso de CPU (%)">
            <Input className={FIELD} type="number" value={form.cpu_usage} onChange={set("cpu_usage")} placeholder="62" />
          </Field>
          <Field label="Uso de GPU (%)">
            <Input className={FIELD} type="number" value={form.gpu_usage} onChange={set("gpu_usage")} placeholder="95" />
          </Field>
          <Field label="Uso de RAM (%)">
            <Input className={FIELD} type="number" value={form.ram_usage} onChange={set("ram_usage")} placeholder="58" />
          </Field>
          <Field label="Temp. GPU (°C)">
            <Input className={FIELD} type="number" value={form.gpu_temp_c} onChange={set("gpu_temp_c")} placeholder="71" />
          </Field>
          <Field label="Temp. CPU (°C)">
            <Input className={FIELD} type="number" value={form.cpu_temp_c} onChange={set("cpu_temp_c")} placeholder="68" />
          </Field>
          <div className="sm:col-span-2">
            <Field label="Observações">
              <Input className={FIELD} value={form.notes} onChange={set("notes")} placeholder="Ex.: driver 566.36, vsync off, mapa Dust2" />
            </Field>
          </div>
          <div className="sm:col-span-2 flex justify-end gap-2 pt-1">
            <ActionButton variant="ghost" size="sm" onClick={() => setOpen(false)}>
              Cancelar
            </ActionButton>
            <ActionButton type="submit" size="sm" loading={saving} disabled={!form.game_name}>
              Salvar sessão
            </ActionButton>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}