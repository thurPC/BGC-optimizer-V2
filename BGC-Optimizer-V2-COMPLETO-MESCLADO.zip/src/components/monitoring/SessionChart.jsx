import { Bar, CartesianGrid, ComposedChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { fmtNumber } from "@/lib/format";

function ChartTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-xl border border-white/12 bg-[#0A0F18]/95 px-3 py-2 text-xs backdrop-blur-xl">
      <p className="mb-1 font-medium text-bgc-ink">{label}</p>
      {payload.map((p) => (
        <p key={p.dataKey} className="text-bgc-dim">
          <span className="mr-2 inline-block h-2 w-2 rounded-full" style={{ background: p.color }} />
          {p.name}: <span className="font-mono text-bgc-ink">{fmtNumber(p.value, p.dataKey === "frametime" ? 2 : 0)}</span>
        </p>
      ))}
    </div>
  );
}

export default function SessionChart({ sessions }) {
  const data = [...sessions]
    .slice(0, 10)
    .reverse()
    .map((s) => ({
      name: s.game_name?.slice(0, 11) || "Sessão",
      fps: s.fps_avg,
      low: s.fps_1_low,
      frametime: s.frametime_ms,
    }));

  if (data.length === 0) return null;

  return (
    <div className="h-[260px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -20 }}>
          <defs>
            <linearGradient id="barFps" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#39FF88" stopOpacity={0.95} />
              <stop offset="100%" stopColor="#22C55E" stopOpacity={0.35} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
          <XAxis dataKey="name" tick={{ fill: "#94A3B8", fontSize: 10 }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fill: "#94A3B8", fontSize: 10 }} axisLine={false} tickLine={false} />
          <Tooltip content={<ChartTooltip />} cursor={{ fill: "rgba(255,255,255,0.04)" }} />
          <Bar dataKey="fps" name="FPS médio" fill="url(#barFps)" radius={[6, 6, 0, 0]} maxBarSize={34} />
          <Line type="monotone" dataKey="low" name="1% low" stroke="#38BDF8" strokeWidth={2} dot={{ r: 2 }} />
          <Line type="monotone" dataKey="frametime" name="Frametime" stroke="#F59E0B" strokeWidth={1.5} strokeDasharray="4 4" dot={false} />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}