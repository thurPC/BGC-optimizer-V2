import { Check, CircleAlert, Info, ShieldAlert, Sparkles, X } from "lucide-react";
import { GlassPanel } from "@/components/glass/GlassPanel";
import StatusPill from "@/components/glass/StatusPill";
import ActionButton from "@/components/glass/ActionButton";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { CATEGORY_META } from "@/lib/constants";
import { cn } from "@/lib/utils";

const IMPACT = {
  high: { tone: "green", label: "Impacto alto" },
  medium: { tone: "yellow", label: "Impacto médio" },
  low: { tone: "gray", label: "Impacto baixo" },
};

export default function OptimizationCard({ setting, applied, recommended, onToggle }) {
  const impact = IMPACT[setting.impact] ?? IMPACT.low;

  return (
    <GlassPanel hover className="p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[10px] font-semibold uppercase tracking-[0.18em] text-bgc-dim">
              {CATEGORY_META[setting.category]?.label ?? setting.category}
            </span>
            <StatusPill tone={impact.tone}>{impact.label}</StatusPill>
            {recommended && (
              <StatusPill tone="purple">
                <Sparkles className="h-3 w-3" /> Recomendada
              </StatusPill>
            )}
            {setting.requires_agent && <StatusPill tone="gray">Requer agente</StatusPill>}
          </div>
          <p className="mt-2 font-heading text-[14px] font-semibold text-bgc-ink">{setting.title}</p>
          <p className="mt-1 text-[12px] leading-relaxed text-bgc-dim">{setting.summary}</p>
        </div>

        <div className="flex shrink-0 flex-col items-end gap-2">
          <button
            type="button"
            onClick={() => onToggle(setting, !applied)}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-medium transition",
              applied
                ? "border-bgc-glow/40 bg-bgc-glow/12 text-bgc-glow hover:bg-bgc-glow/20"
                : "border-white/12 bg-white/[0.04] text-bgc-dim hover:border-white/25 hover:text-bgc-ink"
            )}
          >
            {applied ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />}
            {applied ? "Aplicada no app" : "Marcar aplicada"}
          </button>

          <Dialog>
            <DialogTrigger asChild>
              <button type="button" className="inline-flex items-center gap-1 text-[11px] text-bgc-dim hover:text-bgc-glow">
                <Info className="h-3 w-3" /> Detalhes
              </button>
            </DialogTrigger>
            <DialogContent className="glass-strong max-h-[86vh] overflow-y-auto border-white/12 bg-[#0A0F18]/96 text-bgc-ink backdrop-blur-2xl sm:max-w-lg">
              <DialogHeader>
                <DialogTitle className="font-heading text-lg">{setting.title}</DialogTitle>
                <DialogDescription className="text-bgc-dim">{setting.summary}</DialogDescription>
              </DialogHeader>

              <div className="space-y-4 text-[13px]">
                <div>
                  <p className="mb-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-bgc-dim">Explicação</p>
                  <p className="leading-relaxed text-bgc-ink/90">{setting.description}</p>
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="rounded-xl border border-white/[0.08] bg-white/[0.02] p-3">
                    <p className="text-[10px] uppercase tracking-[0.16em] text-bgc-dim">Objetivo</p>
                    <p className="mt-1 text-[12px] leading-relaxed text-bgc-ink/90">{setting.goal}</p>
                  </div>
                  <div className="rounded-xl border border-white/[0.08] bg-white/[0.02] p-3">
                    <p className="text-[10px] uppercase tracking-[0.16em] text-bgc-dim">Compatibilidade</p>
                    <p className="mt-1 text-[12px] leading-relaxed text-bgc-ink/90">{setting.compatibility}</p>
                  </div>
                </div>
                <div>
                  <p className="mb-1 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-bgc-dim">
                    <Check className="h-3 w-3 text-bgc-glow" /> Benefícios esperados
                  </p>
                  <ul className="space-y-1 text-[12px] text-bgc-ink/85">
                    {(setting.benefits ?? []).map((b) => (
                      <li key={b} className="flex gap-2">
                        <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-bgc-glow" /> {b}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <p className="mb-1 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-bgc-dim">
                    <CircleAlert className="h-3 w-3 text-amber-300" /> Possíveis riscos
                  </p>
                  <ul className="space-y-1 text-[12px] text-bgc-ink/85">
                    {(setting.risks ?? []).length === 0 && <li className="text-bgc-dim">Nenhum risco relevante conhecido.</li>}
                    {(setting.risks ?? []).map((r) => (
                      <li key={r} className="flex gap-2">
                        <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-amber-300" /> {r}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="rounded-xl border border-white/[0.08] bg-white/[0.02] p-3">
                  <p className="text-[10px] uppercase tracking-[0.16em] text-bgc-dim">Estado atual conhecido</p>
                  <p className="mt-1 text-[12px] text-bgc-ink/90">
                    {applied ? "Marcada como aplicada no seu perfil ativo." : "Pendente no seu perfil ativo."}
                    {setting.requires_agent ? " A alteração no Windows depende do agente nativo." : " O registro é feito no aplicativo."}
                  </p>
                </div>
                {setting.requires_agent && (
                  <p className="flex items-start gap-2 rounded-xl border border-amber-400/20 bg-amber-400/[0.06] p-3 text-[11px] leading-relaxed text-amber-200/90">
                    <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                    Esta ação altera o sistema e só será executada pelo agente Windows, após sua autorização.
                  </p>
                )}
              </div>

              <ActionButton onClick={() => onToggle(setting, !applied)} size="sm" className="w-full">
                {applied ? "Remover do perfil ativo" : "Marcar como aplicada no perfil"}
              </ActionButton>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </GlassPanel>
  );
}