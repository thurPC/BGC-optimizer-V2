import { Check } from "lucide-react";
import { OBJECTIVES } from "@/lib/constants";
import { cn } from "@/lib/utils";

export default function StepObjective({ value, onChange }) {
  return (
    <div>
      <h2 className="font-heading text-2xl font-semibold tracking-tight text-bgc-ink sm:text-3xl">Seu objetivo</h2>
      <p className="mt-2 max-w-xl text-sm leading-relaxed text-bgc-dim">
        Usamos isso para sugerir o perfil inicial e priorizar recomendações. Você pode mudar depois.
      </p>

      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        {OBJECTIVES.map((o) => {
          const active = value === o.id;
          return (
            <button
              key={o.id}
              type="button"
              onClick={() => onChange(o.id)}
              className={cn(
                "group flex items-start gap-3 rounded-xl border p-4 text-left transition-all duration-300",
                active
                  ? "border-bgc-glow/45 bg-bgc-glow/[0.08] shadow-[0_0_36px_-14px_rgba(57,255,136,0.8)]"
                  : "border-white/[0.08] bg-white/[0.03] hover:border-white/20 hover:bg-white/[0.05]"
              )}
            >
              <span
                className={cn(
                  "mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border transition",
                  active ? "border-bgc-glow bg-bgc-glow text-[#04140B]" : "border-white/25 text-transparent"
                )}
              >
                <Check className="h-3 w-3" />
              </span>
              <span className="min-w-0">
                <span className={cn("block font-heading text-[13px] font-semibold", active ? "text-bgc-ink" : "text-bgc-ink/90")}>
                  {o.label}
                </span>
                <span className="mt-1 block text-xs leading-relaxed text-bgc-dim">{o.hint}</span>
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}