import { Check } from "lucide-react";
import { THEMES } from "@/lib/appearance";
import { cn } from "@/lib/utils";

const ACCENTS = ["#22C55E", "#39FF88", "#38BDF8", "#A78BFA", "#F43F5E", "#F59E0B"];

export default function StepIdentity({ theme, accent, onChange }) {
  return (
    <div>
      <h2 className="font-heading text-2xl font-semibold tracking-tight text-bgc-ink sm:text-3xl">
        Sua identidade visual
      </h2>
      <p className="mt-2 max-w-xl text-sm leading-relaxed text-bgc-dim">
        Escolha um tema e uma cor de destaque. Tudo pode ser ajustado com precisão depois, em Personalização.
      </p>

      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {THEMES.map((t) => {
          const active = theme === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => onChange({ theme: t.id })}
              className={cn(
                "relative overflow-hidden rounded-xl border p-3 text-left transition-all duration-300",
                active ? "border-bgc-glow/50 shadow-[0_0_32px_-14px_rgba(57,255,136,0.9)]" : "border-white/[0.08] hover:border-white/25"
              )}
            >
              <div
                className="h-16 w-full rounded-lg border border-white/10"
                style={{ background: `linear-gradient(135deg, ${t.base}, ${t.accent}55)` }}
              >
                <div className="flex h-full items-center justify-center">
                  <span className="h-6 w-16 rounded-md border border-white/25" style={{ background: `${t.accent}33` }} />
                </div>
              </div>
              <div className="mt-2 flex items-center justify-between">
                <p className="font-heading text-[12.5px] font-semibold text-bgc-ink">{t.label}</p>
                {active && <Check className="h-3.5 w-3.5 text-bgc-glow" />}
              </div>
            </button>
          );
        })}
      </div>

      <div className="mt-6">
        <p className="mb-2 text-[11px] font-medium uppercase tracking-[0.16em] text-bgc-dim">Cor de destaque</p>
        <div className="flex flex-wrap items-center gap-2">
          {ACCENTS.map((color) => (
            <button
              key={color}
              type="button"
              onClick={() => onChange({ accent_color: color })}
              className={cn(
                "h-9 w-9 rounded-full border-2 transition",
                accent?.toUpperCase() === color ? "border-white scale-110" : "border-white/20 hover:border-white/50"
              )}
              style={{ background: color, boxShadow: `0 0 22px -6px ${color}` }}
              aria-label={`Cor ${color}`}
            />
          ))}
          <label className="relative flex h-9 w-9 cursor-pointer items-center justify-center overflow-hidden rounded-full border border-white/20 text-[10px] text-bgc-dim">
            <input
              type="color"
              value={accent}
              onChange={(e) => onChange({ accent_color: e.target.value })}
              className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
              aria-label="Cor personalizada"
            />
            +
          </label>
        </div>
      </div>
    </div>
  );
}