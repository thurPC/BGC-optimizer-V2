import { Check } from "lucide-react";
import GameArt from "@/components/booster/GameArt";
import { cn } from "@/lib/utils";

export default function StepGames({ games, value, onToggle }) {
  return (
    <div>
      <h2 className="font-heading text-2xl font-semibold tracking-tight text-bgc-ink sm:text-3xl">
        Sua biblioteca gamer
      </h2>
      <p className="mt-2 max-w-xl text-sm leading-relaxed text-bgc-dim">
        Selecione os jogos que você joga. Cada um recebe um perfil e um checklist próprios.
      </p>

      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {games.map((game) => {
          const active = value.includes(game.id);
          return (
            <button
              key={game.id}
              type="button"
              onClick={() => onToggle(game.id)}
              className={cn(
                "group relative overflow-hidden rounded-xl border text-left transition-all duration-300",
                active
                  ? "border-bgc-glow/50 shadow-[0_0_36px_-14px_rgba(57,255,136,0.9)]"
                  : "border-white/[0.08] hover:border-white/25"
              )}
            >
              <GameArt game={game} className="h-20" initialsClassName="text-[52px]" />
              <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-2 p-3">
                <div className="min-w-0">
                  <p className="truncate font-heading text-[13px] font-semibold text-white">{game.name}</p>
                  <p className="truncate text-[10px] uppercase tracking-wider text-white/70">{game.category}</p>
                </div>
                <span
                  className={cn(
                    "flex h-5 w-5 shrink-0 items-center justify-center rounded-full border transition",
                    active ? "border-bgc-glow bg-bgc-glow text-[#04140B]" : "border-white/40 text-transparent"
                  )}
                >
                  <Check className="h-3 w-3" />
                </span>
              </div>
            </button>
          );
        })}
      </div>

      <p className="mt-4 text-xs text-bgc-dim">
        {value.length === 0 ? "Nenhum jogo selecionado — você pode adicionar depois no Game Booster." : `${value.length} jogo(s) selecionado(s).`}
      </p>
    </div>
  );
}