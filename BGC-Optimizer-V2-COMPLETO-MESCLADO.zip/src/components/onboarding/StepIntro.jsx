import { Activity, Gamepad2, Layers, ShieldCheck, Sparkles, SlidersHorizontal } from "lucide-react";

const FEATURES = [
  { icon: SlidersHorizontal, title: "Otimizações explicadas", text: "Cada ajuste com objetivo, compatibilidade, benefícios e riscos." },
  { icon: Gamepad2, title: "Game Booster", text: "Perfil e checklist dedicados para cada jogo da sua biblioteca." },
  { icon: Activity, title: "Monitoramento", text: "Registre sessões e compare FPS, 1% low e frametime." },
  { icon: Layers, title: "Perfis de desempenho", text: "Gaming, Competitive, Performance, Balanced e o seu Custom." },
  { icon: Sparkles, title: "Limpeza e manutenção", text: "Checklists que organizam o que fazer — sem apagar nada por você." },
  { icon: ShieldCheck, title: "Nada automático sem você", text: "A versão web registra e orienta. Alterações no Windows exigem o agente autorizado." },
];

export default function StepIntro() {
  return (
    <div>
      <h2 className="font-heading text-2xl font-semibold tracking-tight text-bgc-ink sm:text-3xl">
        Conheça o BGC Optimizer
      </h2>
      <p className="mt-2 max-w-xl text-sm leading-relaxed text-bgc-dim">
        Uma central de controle para quem joga competitivamente: entenda seu hardware, organize seus
        ajustes e acompanhe o que realmente muda na consistência das partidas.
      </p>

      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        {FEATURES.map((f) => (
          <div key={f.title} className="rounded-xl border border-white/[0.08] bg-white/[0.03] p-4">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg border border-bgc-glow/25 bg-bgc-glow/10 text-bgc-glow">
              <f.icon className="h-3.5 w-3.5" />
            </span>
            <p className="mt-3 font-heading text-[13px] font-semibold text-bgc-ink">{f.title}</p>
            <p className="mt-1 text-xs leading-relaxed text-bgc-dim">{f.text}</p>
          </div>
        ))}
      </div>
    </div>
  );
}