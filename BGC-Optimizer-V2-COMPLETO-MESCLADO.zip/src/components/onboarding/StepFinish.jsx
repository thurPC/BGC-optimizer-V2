import { Check, Gamepad2, Laptop, Palette, Target } from "lucide-react";
import { OBJECTIVES } from "@/lib/constants";
import { THEMES } from "@/lib/appearance";

export default function StepFinish({ form, objective, gamesCount, theme }) {
  const objectiveLabel = OBJECTIVES.find((o) => o.id === objective)?.label ?? "Não definido";
  const themeLabel = THEMES.find((t) => t.id === theme)?.label ?? "BGC Dark";

  const rows = [
    { icon: Laptop, label: "Computador", value: form?.name || "Não informado" },
    { icon: Target, label: "Objetivo", value: objectiveLabel },
    { icon: Gamepad2, label: "Jogos", value: `${gamesCount} selecionado(s)` },
    { icon: Palette, label: "Tema", value: themeLabel },
  ];

  return (
    <div className="text-center">
      <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl border border-bgc-glow/40 bg-bgc-glow/10 text-bgc-glow shadow-[0_0_50px_-12px_rgba(57,255,136,0.9)]">
        <Check className="h-7 w-7" />
      </div>
      <h2 className="mt-5 font-heading text-2xl font-semibold tracking-tight text-bgc-ink sm:text-3xl">
        Seu ambiente está pronto.
      </h2>
      <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-bgc-dim">
        Tudo foi salvo na sua conta. Você pode voltar a qualquer momento e ajustar cada detalhe.
      </p>

      <div className="mx-auto mt-6 grid max-w-lg gap-2 text-left">
        {rows.map((row) => (
          <div
            key={row.label}
            className="flex items-center gap-3 rounded-xl border border-white/[0.08] bg-white/[0.03] px-4 py-3"
          >
            <row.icon className="h-4 w-4 shrink-0 text-bgc-glow" />
            <span className="text-[11px] uppercase tracking-wider text-bgc-dim">{row.label}</span>
            <span className="ml-auto truncate text-[13px] text-bgc-ink">{row.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}