const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useQueries } from "@tanstack/react-query";
import { ArrowLeft, ArrowRight, Check } from "lucide-react";

import Logo, { Wordmark } from "@/components/brand/Logo";
import ActionButton from "@/components/glass/ActionButton";
import { GlassPanel } from "@/components/glass/GlassPanel";
import ProgressRail from "@/components/onboarding/ProgressRail";
import StepIntro from "@/components/onboarding/StepIntro";
import StepComputer from "@/components/onboarding/StepComputer";
import StepObjective from "@/components/onboarding/StepObjective";
import StepGames from "@/components/onboarding/StepGames";
import StepIdentity from "@/components/onboarding/StepIdentity";
import StepFinish from "@/components/onboarding/StepFinish";
import { OBJECTIVES } from "@/lib/constants";
import { applyAppearance, THEMES } from "@/lib/appearance";
import { computerQuery, gameProfilesQuery, gamesQuery, logActivity } from "@/lib/queries";
import { usePreferences } from "@/lib/usePreferences";

const TITLES = [
  "Conheça o BGC Optimizer",
  "Cadastre seu computador",
  "Seu objetivo",
  "Sua biblioteca gamer",
  "Sua identidade visual",
  "Finalização",
];

const num = (value) => (value === "" || value === null || value === undefined ? null : Number(value));

export default function OnboardingWizard() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { prefs, save, isLoading } = usePreferences();
  const { data: computer } = useQuery(computerQuery());
  const { data: games = [] } = useQuery(gamesQuery());
  const [{ data: existingProfiles = [] }] = useQueries({ queries: [gameProfilesQuery()] });

  const [ready, setReady] = useState(false);
  const [step, setStep] = useState(1);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ os: "Windows", storage_type: "SSD NVMe" });
  const [objective, setObjective] = useState("");
  const [selectedGames, setSelectedGames] = useState([]);
  const [theme, setTheme] = useState("bgc-dark");
  const [accent, setAccent] = useState("#22C55E");

  useEffect(() => {
    if (ready || isLoading || computer === undefined) return;
    setForm({ os: "Windows", storage_type: "SSD NVMe", ...(computer ?? {}) });
    setObjective(prefs.objective || "");
    setSelectedGames(prefs.selected_games ?? []);
    setTheme(prefs.theme || "bgc-dark");
    setAccent(prefs.accent_color || "#22C55E");
    setStep(Math.min(Math.max(Number(prefs.onboarding_step) || 1, 1), 6));
    setReady(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, isLoading, computer]);

  const saveComputer = async () => {
    const payload = {
      name: form.name?.trim() || "Meu computador",
      cpu_model: form.cpu_model ?? "",
      cpu_cores: num(form.cpu_cores),
      gpu_model: form.gpu_model ?? "",
      gpu_vram_gb: num(form.gpu_vram_gb),
      ram_gb: num(form.ram_gb),
      ram_speed_mhz: num(form.ram_speed_mhz),
      storage_label: form.storage_label ?? "",
      storage_type: form.storage_type ?? "SSD NVMe",
      total_space_gb: num(form.total_space_gb),
      free_space_gb: num(form.free_space_gb),
      storage_health: num(form.storage_health),
      os: form.os ?? "Windows",
      windows_version: form.windows_version ?? "",
      connection_state: computer?.connection_state ?? "disconnected",
      detection_mode: "manual",
    };
    if (computer?.id) await db.entities.ComputerProfile.update(computer.id, payload);
    else await db.entities.ComputerProfile.create(payload);
    queryClient.invalidateQueries({ queryKey: ["computer"] });
  };

  const changeIdentity = (patch) => {
    const nextTheme = patch.theme ?? theme;
    const nextAccent = patch.accent_color ?? (patch.theme ? THEMES.find((t) => t.id === patch.theme)?.accent ?? accent : accent);
    setTheme(nextTheme);
    setAccent(nextAccent);
    applyAppearance({ ...prefs, theme: nextTheme, accent_color: nextAccent });
  };

  const finish = async () => {
    const kind = OBJECTIVES.find((o) => o.id === objective)?.profile ?? "gaming";
    const existingIds = new Set(existingProfiles.map((p) => p.game_id));
    const toCreate = games.filter((g) => selectedGames.includes(g.id) && !existingIds.has(g.id));
    if (toCreate.length) {
      await db.entities.GameProfile.bulkCreate(
        toCreate.map((g) => ({
          game_id: g.id,
          game_name: g.name,
          profile_kind: kind,
          settings: [],
          notes: "",
          prepares: 0,
          favorite: true,
        }))
      );
    }
    await db.entities.Notification.create({
      title: "Bem-vindo ao BGC Optimizer!",
      message: "Seu ambiente está pronto. Escolha um jogo no Game Booster para começar.",
      category: "system",
      read: false,
      is_global: false,
    });
    await logActivity({
      action_type: "onboarding_completed",
      title: "Onboarding concluído",
      detail: `Objetivo: ${objective || "não definido"} · ${selectedGames.length} jogo(s) na biblioteca.`,
    });
    await save({ onboarding_completed: true, onboarding_step: 6, theme, accent_color: accent });
    queryClient.invalidateQueries({ queryKey: ["game-profiles"] });
    queryClient.invalidateQueries({ queryKey: ["notifications"] });
    navigate({ to: "/dashboard" });
  };

  const handleNext = async () => {
    setSaving(true);
    try {
      if (step === 2) await saveComputer();
      if (step === 3) await save({ objective });
      if (step === 4) await save({ selected_games: selectedGames });
      if (step === 5) await save({ theme, accent_color: accent });
      if (step === 6) {
        await finish();
        return;
      }
      const next = step + 1;
      setStep(next);
      await save({ onboarding_step: next });
    } finally {
      setSaving(false);
    }
  };

  const toggleGame = (id) =>
    setSelectedGames((current) => (current.includes(id) ? current.filter((g) => g !== id) : [...current, id]));

  const canContinue = step !== 2 || !!form.name?.trim();

  const stepContent = {
    1: <StepIntro />,
    2: <StepComputer form={form} setForm={setForm} />,
    3: <StepObjective value={objective} onChange={setObjective} />,
    4: <StepGames games={games} value={selectedGames} onToggle={toggleGame} />,
    5: <StepIdentity theme={theme} accent={accent} onChange={changeIdentity} />,
    6: <StepFinish form={form} objective={objective} gamesCount={selectedGames.length} theme={theme} />,
  }[step];

  return (
    <div className="relative mx-auto w-full max-w-6xl px-5 py-8 lg:py-12">
      <div className="flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3">
          <Logo size={34} />
          <Wordmark size="sm" />
        </Link>
        <button
          type="button"
          onClick={() => navigate({ to: "/dashboard" })}
          className="text-[11px] font-medium text-bgc-dim transition hover:text-bgc-ink"
        >
          Ir para o painel
        </button>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[246px_minmax(0,1fr)]">
        <ProgressRail
          titles={TITLES}
          current={step}
          onSelect={(target) => setStep(target)}
        />

        <GlassPanel tone="strong" className="flex flex-col p-6 sm:p-8">
          <div key={step} className="flex-1 animate-in fade-in slide-in-from-bottom-2 duration-400">
            {stepContent}
          </div>

          <div className="mt-8 flex flex-col-reverse items-stretch gap-3 border-t border-white/[0.08] pt-5 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-3">
              {step > 1 && (
                <ActionButton variant="ghost" size="sm" onClick={() => setStep(step - 1)} disabled={saving}>
                  <ArrowLeft className="h-4 w-4" /> Voltar
                </ActionButton>
              )}
              <span className="text-[11px] text-bgc-dim">
                Etapa {step} de {TITLES.length}
              </span>
            </div>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => navigate({ to: "/dashboard" })}
                className="text-[11px] font-medium text-bgc-dim transition hover:text-bgc-ink"
              >
                Salvar e continuar depois
              </button>
              <ActionButton onClick={handleNext} loading={saving} disabled={!canContinue}>
                {step === 6 ? (
                  <>
                    Entrar no BGC Optimizer <Check className="h-4 w-4" />
                  </>
                ) : (
                  <>
                    Continuar <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </ActionButton>
            </div>
          </div>
        </GlassPanel>
      </div>
    </div>
  );
}