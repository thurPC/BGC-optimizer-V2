import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const FIELD = "h-11 border-white/10 bg-white/[0.04] text-bgc-ink placeholder:text-bgc-dim/60 focus-visible:ring-bgc-glow/40";

function Field({ label, hint, children }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[11px] font-medium uppercase tracking-[0.14em] text-bgc-dim">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-[11px] text-bgc-dim/70">{hint}</span>}
    </label>
  );
}

export default function StepComputer({ form, setForm }) {
  const set = (key) => (event) => setForm({ ...form, [key]: event.target.value });

  return (
    <div>
      <h2 className="font-heading text-2xl font-semibold tracking-tight text-bgc-ink sm:text-3xl">
        Cadastre seu computador
      </h2>
      <p className="mt-2 max-w-xl text-sm leading-relaxed text-bgc-dim">
        Preenchimento manual. A detecção automática será ativada quando o agente Windows estiver disponível.
      </p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <Field label="Nome do computador">
          <Input className={FIELD} value={form.name ?? ""} onChange={set("name")} placeholder="Ex.: Setup principal" />
        </Field>
        <Field label="Processador">
          <Input className={FIELD} value={form.cpu_model ?? ""} onChange={set("cpu_model")} placeholder="Ex.: Ryzen 5 5600" />
        </Field>
        <Field label="Núcleos">
          <Input className={FIELD} type="number" value={form.cpu_cores ?? ""} onChange={set("cpu_cores")} placeholder="6" />
        </Field>
        <Field label="Placa de vídeo">
          <Input className={FIELD} value={form.gpu_model ?? ""} onChange={set("gpu_model")} placeholder="Ex.: RTX 3060" />
        </Field>
        <Field label="VRAM (GB)">
          <Input className={FIELD} type="number" value={form.gpu_vram_gb ?? ""} onChange={set("gpu_vram_gb")} placeholder="12" />
        </Field>
        <Field label="Memória RAM (GB)">
          <Input className={FIELD} type="number" value={form.ram_gb ?? ""} onChange={set("ram_gb")} placeholder="16" />
        </Field>
        <Field label="Armazenamento">
          <Input className={FIELD} value={form.storage_label ?? ""} onChange={set("storage_label")} placeholder="Ex.: SSD NVMe 1 TB" />
        </Field>
        <Field label="Tipo de armazenamento">
          <Select value={form.storage_type ?? "SSD NVMe"} onValueChange={(v) => setForm({ ...form, storage_type: v })}>
            <SelectTrigger className={FIELD}>
              <SelectValue placeholder="Selecione" />
            </SelectTrigger>
            <SelectContent className="border-white/10 bg-[#0A0F18] text-bgc-ink">
              {["SSD NVMe", "SSD SATA", "HDD", "Híbrido", "Desconhecido"].map((t) => (
                <SelectItem key={t} value={t}>
                  {t}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
        <Field label="Espaço total (GB)">
          <Input className={FIELD} type="number" value={form.total_space_gb ?? ""} onChange={set("total_space_gb")} placeholder="1000" />
        </Field>
        <Field label="Espaço livre (GB)">
          <Input className={FIELD} type="number" value={form.free_space_gb ?? ""} onChange={set("free_space_gb")} placeholder="320" />
        </Field>
        <Field label="Sistema operacional">
          <Input className={FIELD} value={form.os ?? "Windows"} onChange={set("os")} placeholder="Windows" />
        </Field>
        <Field label="Versão do Windows">
          <Input className={FIELD} value={form.windows_version ?? ""} onChange={set("windows_version")} placeholder="Windows 11 23H2" />
        </Field>
      </div>
    </div>
  );
}