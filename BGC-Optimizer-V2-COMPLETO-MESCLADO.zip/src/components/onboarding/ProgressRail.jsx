import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

export default function ProgressRail({ titles, current, onSelect }) {
  return (
    <div className="glass rounded-glass p-4 lg:p-5">
      <p className="mb-4 text-[10px] font-medium uppercase tracking-[0.22em] text-bgc-dim">Progresso</p>
      <ol className="space-y-1">
        {titles.map((title, index) => {
          const step = index + 1;
          const done = step < current;
          const active = step === current;
          return (
            <li key={title}>
              <button
                type="button"
                disabled={!done}
                onClick={() => done && onSelect(step)}
                className={cn(
                  "flex w-full items-center gap-3 rounded-xl px-2 py-2 text-left transition",
                  done && "hover:bg-white/[0.05]",
                  !done && "cursor-default"
                )}
              >
                <span
                  className={cn(
                    "flex h-7 w-7 shrink-0 items-center justify-center rounded-full border text-[11px] font-semibold transition",
                    done && "border-bgc-glow/50 bg-bgc-glow/15 text-bgc-glow",
                    active && "border-bgc-glow bg-bgc-glow text-[#04140B] shadow-[0_0_20px_-4px_rgba(57,255,136,0.9)]",
                    !done && !active && "border-white/12 bg-white/[0.03] text-bgc-dim"
                  )}
                >
                  {done ? <Check className="h-3.5 w-3.5" /> : step}
                </span>
                <span
                  className={cn(
                    "truncate text-[12.5px]",
                    active ? "font-semibold text-bgc-ink" : done ? "text-bgc-dim" : "text-bgc-dim/60"
                  )}
                >
                  {title}
                </span>
              </button>
            </li>
          );
        })}
      </ol>
      <div className="mt-4 h-1 w-full overflow-hidden rounded-full bg-white/[0.07]">
        <div
          className="h-full rounded-full bg-gradient-to-r from-[#39FF88] to-[#22C55E] transition-all duration-500"
          style={{ width: `${(current / titles.length) * 100}%` }}
        />
      </div>
    </div>
  );
}