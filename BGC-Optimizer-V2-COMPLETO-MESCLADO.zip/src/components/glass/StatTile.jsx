import { cn } from "@/lib/utils";
import { GlassPanel } from "@/components/glass/GlassPanel";

export default function StatTile({ label, value, hint, icon: Icon, tone = "green", className }) {
  const tones = {
    green: "text-bgc-glow border-bgc-glow/25 bg-bgc-glow/10",
    blue: "text-sky-300 border-sky-400/25 bg-sky-400/10",
    purple: "text-violet-300 border-violet-400/25 bg-violet-400/10",
    yellow: "text-amber-300 border-amber-400/25 bg-amber-400/10",
    gray: "text-bgc-dim border-white/12 bg-white/5",
  };
  return (
    <GlassPanel hover className={cn("p-5", className)}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[11px] font-medium uppercase tracking-[0.18em] text-bgc-dim">{label}</p>
          <p className="mt-2 truncate font-heading text-2xl font-semibold text-bgc-ink">{value}</p>
          {hint && <p className="mt-1 truncate text-xs text-bgc-dim">{hint}</p>}
        </div>
        {Icon && (
          <span className={cn("flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border", tones[tone])}>
            <Icon className="h-4 w-4" />
          </span>
        )}
      </div>
    </GlassPanel>
  );
}