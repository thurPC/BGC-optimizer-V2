import { cn } from "@/lib/utils";

/**
 * Glass surface. `tone="strong"` adds depth for hero / modal level surfaces.
 */
export function GlassPanel({ as: Tag = "div", tone = "base", hover = false, edge = false, className, children, ...props }) {
  return (
    <Tag
      className={cn(
        tone === "strong" ? "glass-strong" : "glass",
        hover && "glass-hover",
        edge && "glass-edge",
        "relative overflow-hidden",
        className
      )}
      {...props}
    >
      {children}
    </Tag>
  );
}

/** Thin translucent divider with a soft green highlight. */
export function GlassDivider({ className }) {
  return (
    <div
      className={cn("h-px w-full", className)}
      style={{
        background:
          "linear-gradient(90deg, transparent, rgba(255,255,255,0.10) 20%, rgba(57,255,136,0.22) 50%, rgba(255,255,255,0.10) 80%, transparent)",
      }}
    />
  );
}