import { cn } from "@/lib/utils";

const TONES = {
  green: "border-bgc-glow/30 bg-bgc-glow/10 text-bgc-glow",
  blue: "border-sky-400/30 bg-sky-400/10 text-sky-300",
  yellow: "border-amber-400/30 bg-amber-400/10 text-amber-300",
  red: "border-red-400/30 bg-red-400/10 text-red-300",
  gray: "border-white/15 bg-white/5 text-bgc-dim",
  amber: "border-amber-400/30 bg-amber-400/10 text-amber-300",
  purple: "border-violet-400/30 bg-violet-400/10 text-violet-300",
};

export default function StatusPill({ tone = "gray", children, dot = false, className }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium tracking-wide",
        TONES[tone],
        className
      )}
    >
      {dot && <span className="h-1.5 w-1.5 rounded-full bg-current" />}
      {children}
    </span>
  );
}