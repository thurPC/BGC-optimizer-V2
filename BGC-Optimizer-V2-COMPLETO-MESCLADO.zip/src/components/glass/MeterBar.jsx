import { cn } from "@/lib/utils";

export default function MeterBar({ value = 0, max = 100, tone = "green", label, sublabel, className }) {
  const pct = Math.max(0, Math.min(100, max ? (Number(value) / Number(max)) * 100 : 0));
  const tones = {
    green: "from-[#39FF88] to-[#22C55E]",
    blue: "from-sky-300 to-sky-500",
    yellow: "from-amber-300 to-amber-500",
    red: "from-red-400 to-red-600",
    purple: "from-violet-300 to-violet-500",
  };
  return (
    <div className={cn("w-full", className)}>
      {(label || sublabel) && (
        <div className="mb-2 flex items-baseline justify-between gap-3">
          <span className="text-xs font-medium text-bgc-dim">{label}</span>
          <span className="font-mono text-xs text-bgc-ink">{sublabel}</span>
        </div>
      )}
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/[0.07]">
        <div
          className={cn("h-full rounded-full bg-gradient-to-r transition-[width] duration-700 ease-out", tones[tone])}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}