import { GlassPanel } from "@/components/glass/GlassPanel";
import { cn } from "@/lib/utils";

export default function EmptyState({ icon: Icon, title, description, action, className, tone = "glass" }) {
  return (
    <GlassPanel
      tone={tone}
      className={cn("flex flex-col items-center justify-center px-6 py-12 text-center", className)}
    >
      {Icon && (
        <span className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl border border-white/12 bg-white/[0.04] text-bgc-glow">
          <Icon className="h-5 w-5" />
        </span>
      )}
      <p className="font-heading text-base font-semibold text-bgc-ink">{title}</p>
      {description && <p className="mt-2 max-w-sm text-sm leading-relaxed text-bgc-dim">{description}</p>}
      {action && <div className="mt-5">{action}</div>}
    </GlassPanel>
  );
}