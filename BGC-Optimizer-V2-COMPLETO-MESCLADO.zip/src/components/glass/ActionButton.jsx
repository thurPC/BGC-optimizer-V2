import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";

const BASE =
  "group relative inline-flex items-center justify-center gap-2 rounded-full font-heading text-sm font-semibold tracking-wide transition-all duration-300 outline-none focus-visible:ring-2 focus-visible:ring-bgc-glow/60 focus-visible:ring-offset-2 focus-visible:ring-offset-[#070B12] disabled:pointer-events-none disabled:opacity-45 active:scale-[0.98]";

const VARIANTS = {
  primary:
    "text-[#04140B] bg-gradient-to-b from-[#4BFF9B] to-[#22C55E] shadow-[0_10px_34px_-10px_rgba(34,197,94,0.85),inset_0_1px_0_rgba(255,255,255,0.55)] hover:shadow-[0_14px_44px_-8px_rgba(57,255,136,0.9),inset_0_1px_0_rgba(255,255,255,0.65)] hover:brightness-110",
  secondary:
    "text-bgc-ink border border-white/12 bg-white/[0.055] backdrop-blur-xl hover:border-bgc-glow/35 hover:bg-white/[0.09] hover:shadow-[0_0_34px_-12px_rgba(34,197,94,0.55)]",
  ghost: "text-bgc-dim hover:text-bgc-ink hover:bg-white/[0.06]",
  danger:
    "text-red-100 border border-red-400/25 bg-red-500/10 backdrop-blur-xl hover:bg-red-500/20 hover:border-red-400/45",
};

const SIZES = {
  sm: "h-9 px-4 text-[13px]",
  md: "h-11 px-6",
  lg: "h-[52px] px-8 text-[15px]",
  icon: "h-10 w-10 p-0",
};

export default function ActionButton({
  variant = "primary",
  size = "md",
  loading = false,
  className,
  children,
  disabled,
  type = "button",
  ...props
}) {
  return (
    <button
      type={type}
      disabled={disabled || loading}
      className={cn(BASE, VARIANTS[variant], SIZES[size], className)}
      {...props}
    >
      {loading && <Loader2 className="h-4 w-4 animate-spin" />}
      {children}
      {variant === "primary" && !loading && (
        <span className="pointer-events-none absolute inset-0 rounded-full opacity-0 transition-opacity duration-300 group-hover:opacity-100"
          style={{ background: "radial-gradient(120% 100% at 50% 0%, rgba(255,255,255,0.35), transparent 60%)" }} />
      )}
    </button>
  );
}