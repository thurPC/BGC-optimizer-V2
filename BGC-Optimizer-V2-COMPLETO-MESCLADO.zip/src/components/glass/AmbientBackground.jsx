import { cn } from "@/lib/utils";

/**
 * Ambient environment: soft green light, tech grid, vignette and grain.
 * Purely decorative, sits behind all content.
 */
export default function AmbientBackground({ className, dense = false }) {
  return (
    <div className={cn("pointer-events-none fixed inset-0 -z-10 overflow-hidden", className)} aria-hidden="true">
      <div
        className="absolute -left-[15%] -top-[25%] h-[70vh] w-[70vh] rounded-full blur-[120px] animate-drift"
        style={{ background: "radial-gradient(circle, rgba(34,197,94,0.30), transparent 70%)" }}
      />
      <div
        className="absolute -right-[10%] top-[8%] h-[52vh] w-[52vh] rounded-full blur-[130px] animate-drift"
        style={{
          background: "radial-gradient(circle, rgba(57,255,136,0.18), transparent 70%)",
          animationDelay: "-6s",
        }}
      />
      <div
        className="absolute bottom-[-30%] left-1/3 h-[60vh] w-[60vh] rounded-full blur-[150px] animate-drift"
        style={{
          background: "radial-gradient(circle, rgba(18,61,43,0.85), transparent 70%)",
          animationDelay: "-11s",
        }}
      />
      {dense && (
        <div
          className="absolute left-1/2 top-1/4 h-[40vh] w-[40vh] -translate-x-1/2 rounded-full blur-[110px]"
          style={{ background: "radial-gradient(circle, rgba(57,255,136,0.16), transparent 70%)" }}
        />
      )}

      {/* tech grid */}
      <div
        className="absolute inset-0 opacity-[0.16]"
        style={{
          backgroundImage:
            "linear-gradient(to right, rgba(148,163,184,0.28) 1px, transparent 1px), linear-gradient(to bottom, rgba(148,163,184,0.28) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
          maskImage: "radial-gradient(ellipse 75% 60% at 50% 30%, #000 30%, transparent 85%)",
          WebkitMaskImage: "radial-gradient(ellipse 75% 60% at 50% 30%, #000 30%, transparent 85%)",
        }}
      />

      {/* vignette */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 90% 70% at 50% 40%, transparent 35%, rgba(4,7,12,0.72) 100%)",
        }}
      />
    </div>
  );
}