import { Check } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { THEMES } from "@/lib/appearance";
import { WIDGETS } from "@/lib/constants";
import { cn } from "@/lib/utils";

export function ThemeGrid({ value, onChange }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
      {THEMES.map((theme) => {
        const active = value === theme.id;
        return (
          <button
            key={theme.id}
            type="button"
            onClick={() => onChange(theme.id)}
            className={cn(
              "relative overflow-hidden rounded-xl border p-3 text-left transition-all duration-300",
              active ? "border-bgc-glow/50 shadow-[0_0_36px_-16px_rgba(57,255,136,0.9)]" : "border-white/[0.08] hover:border-white/25"
            )}
          >
            <div
              className="h-14 w-full rounded-lg border border-white/10"
              style={{ background: `linear-gradient(135deg, ${theme.base}, ${theme.accent}55)` }}
            />
            <div className="mt-2 flex items-center justify-between">
              <p className="font-heading text-[12.5px] font-semibold text-bgc-ink">{theme.label}</p>
              {active && <Check className="h-3.5 w-3.5 text-bgc-glow" />}
            </div>
          </button>
        );
      })}
    </div>
  );
}

export function SliderRow({ label, value, min, max, step = 1, format, onChange }) {
  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <span className="text-[11.5px] font-medium text-bgc-dim">{label}</span>
        <span className="font-mono text-[11px] text-bgc-ink">{format ? format(value) : value}</span>
      </div>
      <Slider
        value={[value]}
        min={min}
        max={max}
        step={step}
        onValueChange={([next]) => onChange(next)}
        className="[&_[role=slider]]:border-bgc-glow [&_[role=slider]]:bg-bgc-glow [&_.bg-primary]:bg-bgc-glow"
      />
    </div>
  );
}

export function ToggleRow({ label, hint, checked, onChange }) {
  return (
    <div className="flex items-center justify-between gap-4 rounded-xl border border-white/[0.07] bg-white/[0.02] px-3 py-2.5">
      <div className="min-w-0">
        <p className="text-[12.5px] font-medium text-bgc-ink">{label}</p>
        {hint && <p className="text-[10.5px] text-bgc-dim">{hint}</p>}
      </div>
      <Switch
        checked={checked}
        onCheckedChange={onChange}
        className="data-[state=checked]:bg-bgc-green data-[state=unchecked]:bg-white/15"
      />
    </div>
  );
}

export function ColorRow({ label, value, presets, onChange }) {
  return (
    <div>
      <p className="mb-2 text-[11.5px] font-medium text-bgc-dim">{label}</p>
      <div className="flex flex-wrap items-center gap-2">
        {presets.map((color) => (
          <button
            key={color}
            type="button"
            onClick={() => onChange(color)}
            className={cn(
              "h-8 w-8 rounded-full border-2 transition",
              value?.toUpperCase() === color.toUpperCase() ? "scale-110 border-white" : "border-white/20 hover:border-white/50"
            )}
            style={{ background: color, boxShadow: `0 0 18px -6px ${color}` }}
            aria-label={`Cor ${color}`}
          />
        ))}
        <label className="relative flex h-8 w-8 cursor-pointer items-center justify-center overflow-hidden rounded-full border border-white/20 text-[10px] text-bgc-dim">
          <input
            type="color"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
            aria-label="Cor personalizada"
          />
          +
        </label>
      </div>
    </div>
  );
}

export function WidgetPicker({ value, onToggle }) {
  return (
    <div className="grid gap-1.5 sm:grid-cols-2">
      {WIDGETS.map((widget) => {
        const active = value.includes(widget.id);
        return (
          <button
            key={widget.id}
            type="button"
            onClick={() => onToggle(widget.id)}
            className={cn(
              "flex items-center gap-2.5 rounded-lg border px-3 py-2 text-left transition",
              active ? "border-bgc-glow/30 bg-bgc-glow/[0.06]" : "border-white/[0.07] bg-white/[0.02] hover:border-white/20"
            )}
          >
            <span
              className={cn(
                "flex h-4 w-4 items-center justify-center rounded border",
                active ? "border-bgc-glow bg-bgc-glow text-[#04140B]" : "border-white/25 text-transparent"
              )}
            >
              <Check className="h-2.5 w-2.5" />
            </span>
            <span className="text-[12px] text-bgc-ink">{widget.label}</span>
          </button>
        );
      })}
    </div>
  );
}