const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Save } from "lucide-react";
import { toast } from "sonner";

import ActionButton from "@/components/glass/ActionButton";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { logActivity } from "@/lib/queries";

const FIELD = "mt-1.5 h-10 border-white/10 bg-white/[0.04] text-bgc-ink placeholder:text-bgc-dim/60";
const num = (v) => (v === "" || v === null || v === undefined ? null : Number(v));

function Field({ label, children }) {
  return (
    <div>
      <Label className="text-[10px] font-medium uppercase tracking-[0.14em] text-bgc-dim">{label}</Label>
      {children}
    </div>
  );
}

export default function ComputerForm({ computer, trigger }) {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({});

  useEffect(() => {
    if (open) setForm({ ...(computer ?? {}), os: computer?.os ?? "Windows", storage_type: computer?.storage_type ?? "SSD NVMe" });
  }, [open, computer]);

  const set = (key) => (event) => setForm({ ...form, [key]: event.target.value });

  const save = async (event) => {
    event.preventDefault();
    if (!form.name?.trim()) return;
    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        cpu_model: form.cpu_model ?? "",
        cpu_cores: num(form.cpu_cores),
        gpu_model: form.gpu_model ?? "",
        gpu_vram_gb: num(form.gpu_vram_gb),
        ram_gb: num(form.ram_gb),
        ram_speed_mhz: num(form.ram_speed_mhz),
        storage_label: form.storage_label ?? "",
        storage_type: form.storage_type ?? "SSD NVMe",
        total_space_gb: num(form.total_space_gb),
        free_space_gb: num(form.free_space_gb),
        storage_health: num(form.storage_health),
        storage_temp_c: num(form.storage_temp_c),
        os: form.os ?? "Windows",
        windows_version: form.windows_version ?? "",
        notes: form.notes ?? "",
        detection_mode: computer?.detection_mode ?? "manual",
        connection_state: computer?.connection_state ?? "disconnected",
      };
      if (computer?.id) await db.entities.ComputerProfile.update(computer.id, payload);
      else await db.entities.ComputerProfile.create(payload);
      await logActivity({
        action_type: "hardware_updated",
        title: "Hardware atualizado",
        detail: `${payload.name} · ${payload.cpu_model || "CPU não informada"} · ${payload.gpu_model || "GPU não informada"}`,
        entity_ref: computer?.id ?? "",
        entity_name: "ComputerProfile",
      });
      queryClient.invalidateQueries({ queryKey: ["computer"] });
      queryClient.invalidateQueries({ queryKey: ["history"] });
      toast.success("Hardware salvo.");
      setOpen(false);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="glass-strong max-h-[88vh] overflow-y-auto border-white/12 bg-[#0A0F18]/96 text-bgc-ink backdrop-blur-2xl sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-heading">Dados do computador</DialogTitle>
          <DialogDescription className="text-bgc-dim">
            Valores informados por você. Métricas ao vivo exigem o agente Windows conectado.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={save} className="grid gap-3 sm:grid-cols-2">
          <Field label="Nome do computador">
            <Input className={FIELD} value={form.name ?? ""} onChange={set("name")} />
          </Field>
          <Field label="Sistema operacional">
            <Input className={FIELD} value={form.os ?? ""} onChange={set("os")} />
          </Field>
          <Field label="Versão do Windows">
            <Input className={FIELD} value={form.windows_version ?? ""} onChange={set("windows_version")} placeholder="Windows 11 23H2" />
          </Field>
          <Field label="Processador">
            <Input className={FIELD} value={form.cpu_model ?? ""} onChange={set("cpu_model")} />
          </Field>
          <Field label="Núcleos">
            <Input className={FIELD} type="number" value={form.cpu_cores ?? ""} onChange={set("cpu_cores")} />
          </Field>
          <Field label="Placa de vídeo">
            <Input className={FIELD} value={form.gpu_model ?? ""} onChange={set("gpu_model")} />
          </Field>
          <Field label="VRAM (GB)">
            <Input className={FIELD} type="number" value={form.gpu_vram_gb ?? ""} onChange={set("gpu_vram_gb")} />
          </Field>
          <Field label="RAM (GB)">
            <Input className={FIELD} type="number" value={form.ram_gb ?? ""} onChange={set("ram_gb")} />
          </Field>
          <Field label="Frequência da RAM (MHz)">
            <Input className={FIELD} type="number" value={form.ram_speed_mhz ?? ""} onChange={set("ram_speed_mhz")} />
          </Field>
          <Field label="Armazenamento">
            <Input className={FIELD} value={form.storage_label ?? ""} onChange={set("storage_label")} />
          </Field>
          <Field label="Tipo">
            <Select value={form.storage_type ?? "SSD NVMe"} onValueChange={(v) => setForm({ ...form, storage_type: v })}>
              <SelectTrigger className={FIELD}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="border-white/10 bg-[#0A0F18] text-bgc-ink">
                {["SSD NVMe", "SSD SATA", "HDD", "Híbrido", "Desconhecido"].map((t) => (
                  <SelectItem key={t} value={t}>
                    {t}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Espaço total (GB)">
            <Input className={FIELD} type="number" value={form.total_space_gb ?? ""} onChange={set("total_space_gb")} />
          </Field>
          <Field label="Espaço livre (GB)">
            <Input className={FIELD} type="number" value={form.free_space_gb ?? ""} onChange={set("free_space_gb")} />
          </Field>
          <Field label="Saúde do disco (%)">
            <Input className={FIELD} type="number" value={form.storage_health ?? ""} onChange={set("storage_health")} />
          </Field>
          <Field label="Temperatura do disco (°C)">
            <Input className={FIELD} type="number" value={form.storage_temp_c ?? ""} onChange={set("storage_temp_c")} />
          </Field>
          <div className="sm:col-span-2">
            <Field label="Observações">
              <Input className={FIELD} value={form.notes ?? ""} onChange={set("notes")} placeholder="Ex.: gabinete com 3 fans, pasta térmica trocada em 03/2026" />
            </Field>
          </div>
          <div className="sm:col-span-2 flex justify-end gap-2 pt-1">
            <ActionButton variant="ghost" size="sm" onClick={() => setOpen(false)}>
              Cancelar
            </ActionButton>
            <ActionButton type="submit" size="sm" loading={saving}>
              <Save className="h-3.5 w-3.5" /> Salvar
            </ActionButton>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}