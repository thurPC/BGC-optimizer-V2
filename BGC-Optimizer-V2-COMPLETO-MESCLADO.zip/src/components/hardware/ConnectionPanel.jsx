import { Cable, CircleAlert, CircleCheck, CircleDashed, Loader2 } from "lucide-react";
import { GlassPanel } from "@/components/glass/GlassPanel";
import StatusPill from "@/components/glass/StatusPill";
import ActionButton from "@/components/glass/ActionButton";
import { fmtDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";

const STATES = [
  { id: "disconnected", label: "Desconectado", icon: CircleDashed, tone: "gray", text: "Nenhum agente conectado." },
  { id: "connecting", label: "Conectando", icon: Loader2, tone: "yellow", text: "Handshake com o agente local." },
  { id: "connected", label: "Conectado", icon: CircleCheck, tone: "green", text: "Métricas e ajustes autorizados." },
  { id: "error", label: "Erro", icon: CircleAlert, tone: "red", text: "Falha de autenticação ou versão." },
];

export default function ConnectionPanel({ computer }) {
  const current = computer?.connection_state ?? "disconnected";

  return (
    <GlassPanel className="p-5">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-bgc-dim">Agente Windows</p>
          <p className="mt-1 font-heading text-base font-semibold text-bgc-ink">Conexão com o computador</p>
        </div>
        <Cable className="h-4 w-4 text-bgc-glow" />
      </div>

      <div className="mt-4 space-y-2">
        {STATES.map((state) => {
          const active = current === state.id;
          return (
            <div
              key={state.id}
              className={cn(
                "flex items-center gap-3 rounded-xl border px-3 py-2",
                active ? "border-bgc-glow/35 bg-bgc-glow/[0.07]" : "border-white/[0.07] bg-white/[0.02]"
              )}
            >
              <state.icon className={cn("h-4 w-4", active ? "text-bgc-glow" : "text-bgc-dim")} />
              <div className="min-w-0">
                <p className={cn("text-[12.5px] font-medium", active ? "text-bgc-ink" : "text-bgc-dim")}>{state.label}</p>
                <p className="text-[10.5px] text-bgc-dim/70">{state.text}</p>
              </div>
              {active && (
                <StatusPill tone={state.tone} dot className="ml-auto">
                  atual
                </StatusPill>
              )}
            </div>
          );
        })}
      </div>

      <div className="mt-4 rounded-xl border border-white/[0.08] bg-white/[0.02] p-3">
        <p className="text-[11px] leading-relaxed text-bgc-dim">
          O agente nativo está em desenvolvimento. Quando disponível, ele poderá detectar hardware, coletar
          métricas, medir FPS e aplicar ajustes autorizados com backup e restauração.
        </p>
        <p className="mt-2 text-[10px] uppercase tracking-wider text-bgc-dim/60">
          Última sincronização: {computer?.last_sync ? fmtDateTime(computer.last_sync) : "—"}
        </p>
      </div>

      <ActionButton variant="secondary" size="sm" className="mt-3 w-full" disabled>
        Conectar agente · em breve
      </ActionButton>
    </GlassPanel>
  );
}