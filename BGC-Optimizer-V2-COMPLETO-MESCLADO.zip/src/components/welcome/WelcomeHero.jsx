import { motion } from "framer-motion";
import { useNavigate } from "@tanstack/react-router";
import { ArrowRight, Gauge, Timer, Swords } from "lucide-react";
import Logo from "@/components/brand/Logo";
import ActionButton from "@/components/glass/ActionButton";
import RotatingMessages from "@/components/welcome/RotatingMessages";

const PILLARS = [
  {
    icon: Timer,
    title: "Frametime estável",
    text: "Perfis pensados para consistência, não apenas picos de FPS.",
  },
  {
    icon: Gauge,
    title: "1% low sob controle",
    text: "Registre e compare quedas de desempenho entre sessões.",
  },
  {
    icon: Swords,
    title: "Latência primeiro",
    text: "Ajustes recomendados priorizando resposta por partida.",
  },
];

const ease = [0.22, 1, 0.36, 1];

export default function WelcomeHero() {
  const navigate = useNavigate();

  return (
    <div className="relative mx-auto flex min-h-dvh w-full max-w-6xl flex-col items-center justify-center px-6 py-16">
      <motion.div
        initial={{ opacity: 0, scale: 0.85, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.9, ease }}
        className="relative"
      >
        <div className="absolute inset-0 -z-10 blur-2xl" style={{ background: "radial-gradient(circle, rgba(57,255,136,0.55), transparent 70%)" }} />
        <Logo size={68} />
      </motion.div>

      <motion.p
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.7, ease }}
        className="mt-7 rounded-full border border-white/10 bg-white/[0.04] px-4 py-1.5 text-[11px] font-medium uppercase tracking-[0.28em] text-bgc-dim backdrop-blur-xl"
      >
        Performance competitiva · Windows 10 &amp; 11
      </motion.p>

      <motion.h1
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.8, ease }}
        className="mt-8 text-center font-heading text-[2.6rem] font-semibold leading-[1.05] tracking-[-0.02em] sm:text-6xl md:text-7xl"
      >
        Bem-vindo ao
        <br />
        <span className="text-gradient">próximo nível.</span>
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.42, duration: 0.8, ease }}
        className="mt-6 text-center font-heading text-lg text-bgc-ink/90 sm:text-xl"
      >
        Seu PC. Seu desempenho. Suas regras.
      </motion.p>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.55, duration: 0.8 }}
        className="mt-3 max-w-xl text-center text-[15px] leading-relaxed text-bgc-dim"
      >
        Ferramentas de análise, personalização e gerenciamento de desempenho para
        quem joga para ganhar — cada detecção, ajuste e métrica sob seu controle.
      </motion.p>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.7, duration: 0.8 }}
        className="mt-7 w-full"
      >
        <RotatingMessages />
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.78, duration: 0.8, ease }}
        className="mt-6 flex w-full flex-col items-center gap-3 sm:w-auto sm:flex-row"
      >
        <ActionButton size="lg" className="w-full sm:w-auto" onClick={() => navigate({ to: "/onboarding" })}>
          Começar agora
          <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
        </ActionButton>
        <ActionButton size="lg" variant="secondary" className="w-full sm:w-auto" onClick={() => navigate({ to: "/dashboard" })}>
          Ir para o painel
        </ActionButton>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 26 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.95, duration: 0.9, ease }}
        className="mt-16 grid w-full gap-4 sm:grid-cols-3"
      >
        {PILLARS.map((p, i) => (
          <motion.div
            key={p.title}
            animate={{ y: [0, -6, 0] }}
            transition={{ duration: 6 + i, repeat: Infinity, ease: "easeInOut", delay: i * 0.6 }}
            className="glass glass-hover rounded-glass p-5"
          >
            <div className="flex items-center gap-3">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-bgc-glow/25 bg-bgc-glow/10 text-bgc-glow">
                <p.icon className="h-4 w-4" />
              </span>
              <p className="font-heading text-sm font-semibold text-bgc-ink">{p.title}</p>
            </div>
            <p className="mt-3 text-[13px] leading-relaxed text-bgc-dim">{p.text}</p>
          </motion.div>
        ))}
      </motion.div>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.3, duration: 1 }}
        className="mt-12 max-w-xl text-center text-[11px] leading-relaxed text-bgc-dim/70"
      >
        Versão web. O BGC Optimizer registra e organiza suas configurações — nenhuma
        alteração é aplicada diretamente no Windows sem o agente autorizado.
      </motion.p>
    </div>
  );
}