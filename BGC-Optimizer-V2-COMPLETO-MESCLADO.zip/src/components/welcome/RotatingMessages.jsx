import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";

const MESSAGES = [
  "Mais controle sobre seu sistema.",
  "Uma experiência gamer personalizada.",
  "Seu hardware merece ser aproveitado.",
  "Desempenho com inteligência e segurança.",
];

export default function RotatingMessages({ className = "" }) {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setIndex((i) => (i + 1) % MESSAGES.length), 3800);
    return () => clearInterval(id);
  }, []);

  return (
    <div className={`relative flex h-7 items-center justify-center overflow-hidden ${className}`}>
      <AnimatePresence mode="wait">
        <motion.p
          key={index}
          initial={{ opacity: 0, y: 14, filter: "blur(6px)" }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          exit={{ opacity: 0, y: -14, filter: "blur(6px)" }}
          transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
          className="absolute text-[13px] font-medium tracking-[0.16em] uppercase text-bgc-glow/80"
        >
          {MESSAGES[index]}
        </motion.p>
      </AnimatePresence>
    </div>
  );
}