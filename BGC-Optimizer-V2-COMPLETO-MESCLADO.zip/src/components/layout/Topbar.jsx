import { Link } from "@tanstack/react-router";
import { Menu, Palette, Settings } from "lucide-react";
import ConnectionBadge from "@/components/layout/ConnectionBadge";
import NotificationsMenu from "@/components/layout/NotificationsMenu";
import UserMenu from "@/components/layout/UserMenu";
import { useAuth } from "@/lib/AuthContext";

const ICON_LINK =
  "hidden h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/[0.04] text-bgc-dim transition hover:border-white/20 hover:text-bgc-ink sm:flex";

export default function Topbar({ onOpenMobile, prefs }) {
  const { user } = useAuth();
  const displayName = prefs?.username || user?.full_name || "";
  const firstName = displayName.split(" ")[0] || "jogador";

  return (
    <header className="sticky top-0 z-30 border-b border-white/[0.07] bg-[#05080E]/60 backdrop-blur-2xl">
      <div className="mx-auto flex h-[72px] w-full max-w-[1440px] items-center gap-2 px-4 sm:gap-3 sm:px-6 lg:px-8">
        <button
          type="button"
          onClick={onOpenMobile}
          className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/[0.04] text-bgc-dim transition hover:text-bgc-ink lg:hidden"
          aria-label="Abrir menu"
        >
          <Menu className="h-[18px] w-[18px]" />
        </button>

        <div className="min-w-0 flex-1">
          <p className="truncate font-heading text-[15px] font-semibold text-bgc-ink">Olá, {firstName}!</p>
          <p className="hidden truncate text-xs text-bgc-dim sm:block">
            Vamos deixar seu ambiente pronto para jogar?
          </p>
        </div>

        <ConnectionBadge />
        <Link to="/personalizacao" className={ICON_LINK} aria-label="Personalização">
          <Palette className="h-[18px] w-[18px]" />
        </Link>
        <Link to="/configuracoes" className={ICON_LINK} aria-label="Configurações">
          <Settings className="h-[18px] w-[18px]" />
        </Link>
        <NotificationsMenu />
        <UserMenu avatarUrl={prefs?.avatar_url} prefs={prefs} />
      </div>
    </header>
  );
}