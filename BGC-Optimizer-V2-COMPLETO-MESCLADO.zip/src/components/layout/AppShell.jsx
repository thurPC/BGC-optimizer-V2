import { useEffect, useMemo, useState } from "react";
import AmbientBackground from "@/components/glass/AmbientBackground";
import Sidebar from "@/components/layout/Sidebar";
import Topbar from "@/components/layout/Topbar";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { applyAppearance } from "@/lib/appearance";
import { usePreferences } from "@/lib/usePreferences";
import { cn } from "@/lib/utils";

export default function AppShell({ children }) {
  const { prefs, save } = usePreferences();
  const [mobileOpen, setMobileOpen] = useState(false);
  const collapsed = prefs.sidebar_mode === "compact";

  const signature = useMemo(
    () =>
      JSON.stringify([
        prefs.theme,
        prefs.accent_color,
        prefs.secondary_color,
        prefs.glass_blur,
        prefs.glass_alpha,
        prefs.glow_strength,
        prefs.corner_radius,
        prefs.shadow_strength,
        prefs.border_glow,
        prefs.animations,
      ]),
    [prefs]
  );

  useEffect(() => {
    applyAppearance(prefs);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [signature]);

  return (
    <div className="relative min-h-dvh">
      {prefs.ambient_light !== false && (
        <div className="pointer-events-none" style={{ opacity: Number(prefs.bg_opacity ?? 1) }}>
          <AmbientBackground />
        </div>
      )}

      <div
        className={cn(
          "fixed inset-y-0 left-0 z-40 hidden border-r border-white/[0.07] bg-[#05080E]/45 backdrop-blur-2xl transition-[width] duration-500 ease-out lg:block",
          collapsed ? "w-[84px]" : "w-[262px]"
        )}
      >
        <Sidebar collapsed={collapsed} onToggle={() => save({ sidebar_mode: collapsed ? "expanded" : "compact" })} />
      </div>

      <div className={cn("transition-[padding] duration-500 ease-out", collapsed ? "lg:pl-[84px]" : "lg:pl-[262px]")}>
        <Topbar onOpenMobile={() => setMobileOpen(true)} prefs={prefs} />
        <main className="mx-auto w-full max-w-[1440px] px-4 pb-24 pt-6 sm:px-6 lg:px-8">{children}</main>
      </div>

      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent
          side="left"
          className="w-[280px] border-r border-white/10 bg-[#05080E]/95 p-0 backdrop-blur-2xl"
        >
          <SheetTitle className="sr-only">Navegação</SheetTitle>
          <div className="h-full pt-2">
            <Sidebar mobile onNavigate={() => setMobileOpen(false)} />
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}