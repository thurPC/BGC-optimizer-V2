const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Bell, Check, Sparkles, Swords, UserRound } from "lucide-react";
import { notificationsQuery } from "@/lib/queries";
import { usePreferences } from "@/lib/usePreferences";
import { fmtRelative } from "@/lib/format";
import { cn } from "@/lib/utils";

const ICONS = { system: Bell, recommendation: Sparkles, game: Swords, account: UserRound };
const CATEGORY_FILTER = { system: "notify_system", recommendation: "notify_recommendations", game: "notify_games" };

export default function NotificationsMenu() {
  const queryClient = useQueryClient();
  const { data: notifications = [] } = useQuery(notificationsQuery());
  const { prefs, save } = usePreferences();

  const visible = notifications.filter((n) => {
    const key = CATEGORY_FILTER[n.category];
    if (key && prefs[key] === false) return false;
    return true;
  });
  const own = visible.filter((n) => !n.is_global);
  const dismissed = prefs.dismissed_notifications ?? [];
  const globals = visible.filter((n) => n.is_global && !dismissed.includes(n.id));
  const unread = own.filter((n) => !n.read).length + globals.length;
  const list = [...globals, ...own];

  const markAllRead = async () => {
    const unreadOwn = own.filter((n) => !n.read);
    if (unreadOwn.length) {
      await db.entities.Notification.bulkUpdate(unreadOwn.map((n) => ({ id: n.id, read: true })));
    }
    await save({ dismissed_notifications: [...dismissed, ...globals.map((n) => n.id)] });
    queryClient.invalidateQueries({ queryKey: ["notifications"] });
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <button
          type="button"
          className="relative flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/[0.04] text-bgc-dim transition hover:border-white/20 hover:text-bgc-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bgc-glow/60"
          aria-label="Notificações"
        >
          <Bell className="h-[18px] w-[18px]" />
          {unread > 0 && (
            <span className="absolute right-1.5 top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-bgc-glow px-1 text-[10px] font-bold text-[#04140B]">
              {unread > 9 ? "9+" : unread}
            </span>
          )}
        </button>
      </PopoverTrigger>
      <PopoverContent
        align="end"
        className="w-[340px] border-white/10 bg-[#0A0F18]/95 p-0 text-bgc-ink backdrop-blur-2xl"
      >
        <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
          <p className="font-heading text-sm font-semibold">Notificações</p>
          <button
            type="button"
            onClick={markAllRead}
            className="inline-flex items-center gap-1 text-[11px] text-bgc-dim transition hover:text-bgc-glow"
          >
            <Check className="h-3 w-3" /> Marcar lidas
          </button>
        </div>
        <div className="max-h-[340px] overflow-y-auto no-scrollbar">
          {list.length === 0 && (
            <p className="px-4 py-8 text-center text-xs text-bgc-dim">Nenhuma notificação por aqui.</p>
          )}
          {list.map((n) => {
            const Icon = ICONS[n.category] ?? Bell;
            const isRead = !n.is_global && n.read;
            return (
              <div
                key={n.id}
                className={cn(
                  "flex gap-3 border-b border-white/[0.06] px-4 py-3 last:border-0",
                  !isRead && "bg-white/[0.03]"
                )}
              >
                <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-white/10 bg-white/[0.04] text-bgc-glow">
                  <Icon className="h-3.5 w-3.5" />
                </span>
                <div className="min-w-0">
                  <p className="text-[13px] font-medium leading-tight text-bgc-ink">{n.title}</p>
                  <p className="mt-1 text-xs leading-relaxed text-bgc-dim">{n.message}</p>
                  <p className="mt-1 text-[10px] uppercase tracking-wider text-bgc-dim/60">
                    {fmtRelative(n.created_date)}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </PopoverContent>
    </Popover>
  );
}