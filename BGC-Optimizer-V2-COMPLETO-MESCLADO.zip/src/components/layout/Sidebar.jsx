import { Link, useRouterState } from "@tanstack/react-router";
import { ChevronsLeft, ChevronsRight } from "lucide-react";
import Logo, { Wordmark } from "@/components/brand/Logo";
import { ADMIN_ITEM, NAV_ITEMS } from "@/lib/constants";
import { useAuth } from "@/lib/AuthContext";
import { cn } from "@/lib/utils";

export default function Sidebar({ collapsed = false, onToggle, onNavigate, mobile = false }) {
  const { user } = useAuth();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const items = user?.role === "admin" ? [...NAV_ITEMS, ADMIN_ITEM] : NAV_ITEMS;
  const isCollapsed = mobile ? false : collapsed;

  return (
    <aside className="flex h-full w-full flex-col">
      <div className={cn("flex items-center gap-3 px-5 pt-6", isCollapsed && "justify-center px-0")}>
        <Link to="/dashboard" onClick={onNavigate} className="flex items-center gap-3">
          <Logo size={36} />
          {!isCollapsed && <Wordmark size="sm" />}
        </Link>
      </div>

      <nav className="mt-8 flex-1 space-y-1 overflow-y-auto px-3 no-scrollbar">
        {items.map((item) => {
          const active = pathname === item.to || pathname.startsWith(`${item.to}/`);
          return (
            <Link
              key={item.to}
              to={item.to}
              onClick={onNavigate}
              title={isCollapsed ? item.label : undefined}
              className={cn(
                "group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all duration-300",
                active
                  ? "bg-white/[0.07] text-bgc-ink shadow-[inset_0_1px_0_rgba(255,255,255,0.08)]"
                  : "text-bgc-dim hover:bg-white/[0.04] hover:text-bgc-ink",
                isCollapsed && "justify-center px-0"
              )}
            >
              {active && (
                <span className="absolute left-0 top-1/2 h-6 w-[3px] -translate-y-1/2 rounded-full bg-bgc-glow shadow-[0_0_14px_3px_rgba(57,255,136,0.55)]" />
              )}
              <item.icon
                className={cn(
                  "h-[18px] w-[18px] shrink-0 transition-colors",
                  active ? "text-bgc-glow" : "text-bgc-dim group-hover:text-bgc-ink"
                )}
              />
              {!isCollapsed && <span className="truncate font-medium">{item.label}</span>}
            </Link>
          );
        })}
      </nav>

      <div className="px-3 pb-5">
        {!mobile && (
          <button
            type="button"
            onClick={onToggle}
            className={cn(
              "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-xs font-medium text-bgc-dim transition hover:bg-white/[0.05] hover:text-bgc-ink",
              isCollapsed && "justify-center px-0"
            )}
          >
            {isCollapsed ? <ChevronsRight className="h-4 w-4" /> : <ChevronsLeft className="h-4 w-4" />}
            {!isCollapsed && "Recolher menu"}
          </button>
        )}
        {!isCollapsed && (
          <p className="mt-3 px-3 text-[10px] uppercase tracking-[0.18em] text-bgc-dim/60">
            BGC Optimizer · v1.0
          </p>
        )}
      </div>
    </aside>
  );
}