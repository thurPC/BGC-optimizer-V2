import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { computerQuery } from "@/lib/queries";
import StatusPill from "@/components/glass/StatusPill";

const STATES = {
  disconnected: { tone: "gray", label: "Aguardando conexão" },
  connecting: { tone: "yellow", label: "Conectando" },
  connected: { tone: "green", label: "Conectado" },
  error: { tone: "red", label: "Erro de conexão" },
};

export default function ConnectionBadge({ className, hideOnMobile = true }) {
  const { data: computer, isLoading } = useQuery(computerQuery());
  const state = computer ? STATES[computer.connection_state ?? "disconnected"] : STATES.disconnected;

  return (
    <Link
      to="/hardware"
      className={hideOnMobile ? `hidden sm:block ${className ?? ""}` : className}
      title="Estado da conexão com o computador"
    >
      <StatusPill tone={state.tone} dot className="hover:border-white/25">
        {isLoading && !computer ? "Verificando…" : computer ? state.label : "Sem computador cadastrado"}
      </StatusPill>
    </Link>
  );
}