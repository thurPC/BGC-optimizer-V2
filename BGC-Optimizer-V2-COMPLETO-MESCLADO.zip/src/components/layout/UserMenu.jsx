import { useAuth } from "@/lib/AuthContext";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import UserAvatar from "@/components/layout/UserAvatar";
import { LogOut, Palette, Settings, User } from "lucide-react";
import { Link } from "@tanstack/react-router";

export default function UserMenu({ avatarUrl, prefs }) {
  const { user, logout } = useAuth();
  const displayName = prefs?.username || user?.full_name || user?.email;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          className="relative flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-white/[0.06] transition hover:border-bgc-glow/40 hover:shadow-[0_0_24px_-8px_rgba(57,255,136,0.7)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-bgc-glow/60"
          aria-label="Menu da conta"
        >
          <UserAvatar uri={avatarUrl} name={displayName} className="h-full w-full" textClassName="text-[11px]" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        align="end"
        className="w-60 border-white/10 bg-[#0A0F18]/95 text-bgc-ink backdrop-blur-2xl"
      >
        <DropdownMenuLabel className="font-normal">
          <p className="truncate text-sm font-medium">{user?.full_name || prefs?.username || "Jogador"}</p>
          <p className="truncate text-xs text-bgc-dim">{user?.email}</p>
        </DropdownMenuLabel>
        <DropdownMenuSeparator className="bg-white/10" />
        <DropdownMenuItem asChild className="cursor-pointer focus:bg-white/10">
          <Link to="/perfil" className="flex items-center gap-2">
            <User className="h-4 w-4" /> Perfil
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className="cursor-pointer focus:bg-white/10">
          <Link to="/personalizacao" className="flex items-center gap-2">
            <Palette className="h-4 w-4" /> Personalização
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className="cursor-pointer focus:bg-white/10">
          <Link to="/configuracoes" className="flex items-center gap-2">
            <Settings className="h-4 w-4" /> Configurações
          </Link>
        </DropdownMenuItem>
        <DropdownMenuSeparator className="bg-white/10" />
        <DropdownMenuItem
          onClick={() => logout()}
          className="cursor-pointer text-red-300 focus:bg-red-500/15 focus:text-red-200"
        >
          <LogOut className="mr-2 h-4 w-4" /> Sair da conta
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}