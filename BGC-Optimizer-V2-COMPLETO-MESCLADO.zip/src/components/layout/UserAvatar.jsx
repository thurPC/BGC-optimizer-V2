const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useQuery } from "@tanstack/react-query";

import { Image } from "@/components/ui/image";
import { initialsOf } from "@/lib/format";
import { cn } from "@/lib/utils";

/**
 * Renders the signed-in user's avatar from a private file uri (signed on demand).
 */
export default function UserAvatar({ uri, name, className, textClassName }) {
  const { data: url } = useQuery({
    queryKey: ["avatar-url", uri],
    enabled: !!uri,
    staleTime: 20 * 60 * 1000,
    queryFn: async () => {
      const { signed_url } = await db.integrations.Core.CreateFileSignedUrl({ file_uri: uri, expires_in: 3600 });
      return signed_url;
    },
  });

  return (
    <span
      className={cn(
        "flex items-center justify-center overflow-hidden rounded-full border border-white/15 bg-white/[0.06]",
        className
      )}
    >
      {url ? (
        <Image src={url} alt="" className="h-full w-full object-cover" />
      ) : (
        <span className={cn("font-heading font-semibold text-bgc-ink", textClassName ?? "text-xs")}>
          {initialsOf(name || "BG")}
        </span>
      )}
    </span>
  );
}