import { Check, Copy, Pencil, Trash2 } from "lucide-react";
import { GlassPanel } from "@/components/glass/GlassPanel";
import StatusPill from "@/components/glass/StatusPill";
import { PROFILE_KINDS } from "@/lib/constants";
import { cn } from "@/lib/utils";

export default function ProfileCard({ profile, settingsMap, onActivate, onEdit, onDuplicate, onDelete }) {
  const kind = PROFILE_KINDS[profile.kind] ?? PROFILE_KINDS.custom;
  const keys = profile.settings ?? [];

  return (
    <GlassPanel
      hover
      className={cn("flex flex-col p-5", profile.is_active && "border-bgc-glow/45 shadow-[0_0_50px_-20px_rgba(57,255,136,0.9)]")}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full" style={{ background: profile.accent || kind.accent, boxShadow: `0 0 12px ${profile.accent || kind.accent}` }} />
            <p className="truncate font-heading text-[15px] font-semibold text-bgc-ink">{profile.name}</p>
          </div>
          <p className="mt-1 text-[10px] uppercase tracking-[0.18em] text-bgc-dim">{kind.label}</p>
        </div>
        {profile.is_active ? <StatusPill tone="green" dot>Ativo</StatusPill> : <StatusPill tone="gray">Inativo</StatusPill>}
      </div>

      <p className="mt-3 line-clamp-2 min-h-[34px] text-[12px] leading-relaxed text-bgc-dim">{profile.description}</p>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {keys.slice(0, 3).map((key) => (
          <span key={key} className="rounded-md border border-white/[0.08] bg-white/[0.03] px-2 py-0.5 text-[10px] text-bgc-dim">
            {settingsMap[key] ?? key}
          </span>
        ))}
        {keys.length > 3 && (
          <span className="rounded-md border border-white/[0.08] bg-white/[0.03] px-2 py-0.5 text-[10px] text-bgc-dim">
            +{keys.length - 3}
          </span>
        )}
        {keys.length === 0 && <span className="text-[10px] text-bgc-dim/70">Nenhum ajuste selecionado</span>}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-white/[0.07] pt-3">
        {!profile.is_active && (
          <button
            type="button"
            onClick={() => onActivate(profile)}
            className="inline-flex items-center gap-1.5 rounded-full border border-bgc-glow/30 bg-bgc-glow/10 px-3 py-1.5 text-[11px] font-medium text-bgc-glow transition hover:bg-bgc-glow/20"
          >
            <Check className="h-3 w-3" /> Ativar
          </button>
        )}
        <button
          type="button"
          onClick={() => onEdit(profile)}
          className="inline-flex items-center gap-1.5 rounded-full border border-white/10 px-3 py-1.5 text-[11px] text-bgc-dim transition hover:text-bgc-ink"
        >
          <Pencil className="h-3 w-3" /> Editar
        </button>
        <button
          type="button"
          onClick={() => onDuplicate(profile)}
          className="inline-flex items-center gap-1.5 rounded-full border border-white/10 px-3 py-1.5 text-[11px] text-bgc-dim transition hover:text-bgc-ink"
        >
          <Copy className="h-3 w-3" /> Duplicar
        </button>
        <button
          type="button"
          onClick={() => onDelete(profile)}
          className="ml-auto inline-flex h-7 w-7 items-center justify-center rounded-full border border-white/10 text-bgc-dim transition hover:border-red-400/40 hover:text-red-300"
          aria-label={`Excluir ${profile.name}`}
        >
          <Trash2 className="h-3 w-3" />
        </button>
      </div>
    </GlassPanel>
  );
}