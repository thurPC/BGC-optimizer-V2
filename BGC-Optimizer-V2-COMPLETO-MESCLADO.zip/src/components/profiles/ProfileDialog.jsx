import { useEffect, useState } from "react";
import { Check, Save } from "lucide-react";
import ActionButton from "@/components/glass/ActionButton";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { CATEGORY_META, PROFILE_KINDS } from "@/lib/constants";
import { cn } from "@/lib/utils";

const FIELD = "mt-1.5 border-white/10 bg-white/[0.04] text-bgc-ink placeholder:text-bgc-dim/60";

export default function ProfileDialog({ profile, settings, trigger, onSave, saving, open: controlledOpen, onOpenChange }) {
  const [internalOpen, setInternalOpen] = useState(false);
  const open = controlledOpen !== undefined ? controlledOpen : internalOpen;
  const setOpen = (value) => (onOpenChange ? onOpenChange(value) : setInternalOpen(value));
  const [form, setForm] = useState({ name: "", kind: "custom", description: "", settings: [] });

  useEffect(() => {
    if (!open) return;
    setForm({
      name: profile?.name ?? "",
      kind: profile?.kind ?? "custom",
      description: profile?.description ?? "",
      settings: profile?.settings ?? [],
    });
  }, [open, profile]);

  const grouped = {};
  settings.forEach((s) => {
    grouped[s.category] = grouped[s.category] ?? [];
    grouped[s.category].push(s);
  });

  const toggle = (key) =>
    setForm((current) => ({
      ...current,
      settings: current.settings.includes(key)
        ? current.settings.filter((k) => k !== key)
        : [...current.settings, key],
    }));

  const submit = async (event) => {
    event.preventDefault();
    if (!form.name.trim()) return;
    await onSave({
      name: form.name.trim(),
      kind: form.kind,
      description: form.description.trim(),
      settings: form.settings,
    });
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      {trigger ? <DialogTrigger asChild>{trigger}</DialogTrigger> : null}
      <DialogContent className="glass-strong max-h-[88vh] overflow-y-auto border-white/12 bg-[#0A0F18]/96 text-bgc-ink backdrop-blur-2xl sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-heading">{profile?.id ? "Editar perfil" : "Novo perfil"}</DialogTitle>
          <DialogDescription className="text-bgc-dim">
            Defina quais ajustes pertencem a este perfil. O checklist dos jogos usa essa seleção.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={submit} className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <Label className="text-[10px] uppercase tracking-[0.14em] text-bgc-dim">Nome</Label>
              <Input
                className={FIELD}
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Ex.: Competitivo CS2"
              />
            </div>
            <div>
              <Label className="text-[10px] uppercase tracking-[0.14em] text-bgc-dim">Tipo</Label>
              <div className="mt-1.5 flex flex-wrap gap-1.5">
                {Object.entries(PROFILE_KINDS).map(([key, meta]) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setForm({ ...form, kind: key })}
                    className={cn(
                      "rounded-full border px-2.5 py-1 text-[10.5px] font-medium transition",
                      form.kind === key
                        ? "border-bgc-glow/45 bg-bgc-glow/10 text-bgc-glow"
                        : "border-white/10 text-bgc-dim hover:text-bgc-ink"
                    )}
                  >
                    {meta.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div>
            <Label className="text-[10px] uppercase tracking-[0.14em] text-bgc-dim">Descrição</Label>
            <Textarea
              className={cn(FIELD, "min-h-[64px]")}
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              placeholder="Para que serve este perfil?"
            />
          </div>

          <div className="space-y-4">
            {Object.entries(grouped).map(([category, items]) => (
              <div key={category}>
                <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-bgc-dim">
                  {CATEGORY_META[category]?.label ?? category}
                </p>
                <div className="grid gap-1.5 sm:grid-cols-2">
                  {items.map((item) => {
                    const active = form.settings.includes(item.key);
                    return (
                      <button
                        key={item.key}
                        type="button"
                        onClick={() => toggle(item.key)}
                        className={cn(
                          "flex items-center gap-2.5 rounded-lg border px-3 py-2 text-left transition",
                          active
                            ? "border-bgc-glow/30 bg-bgc-glow/[0.06]"
                            : "border-white/[0.07] bg-white/[0.02] hover:border-white/20"
                        )}
                      >
                        <span
                          className={cn(
                            "flex h-4 w-4 shrink-0 items-center justify-center rounded border",
                            active ? "border-bgc-glow bg-bgc-glow text-[#04140B]" : "border-white/25 text-transparent"
                          )}
                        >
                          <Check className="h-2.5 w-2.5" />
                        </span>
                        <span className="truncate text-[12px] text-bgc-ink">{item.title}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-between gap-3 border-t border-white/[0.08] pt-3">
            <span className="text-[11px] text-bgc-dim">{form.settings.length} ajustes selecionados</span>
            <div className="flex gap-2">
              <ActionButton variant="ghost" size="sm" onClick={() => setOpen(false)}>
                Cancelar
              </ActionButton>
              <ActionButton type="submit" size="sm" loading={saving} disabled={!form.name.trim()}>
                <Save className="h-3.5 w-3.5" /> Salvar perfil
              </ActionButton>
            </div>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}