import { cn } from "@/lib/utils";

/**
 * BGC Optimizer brand mark — a glass hexagon holding a performance bolt.
 */
export default function Logo({ size = 40, className }) {
  return (
    <span
      className={cn(
        "relative inline-flex items-center justify-center rounded-[30%] border border-white/15",
        className
      )}
      style={{
        width: size,
        height: size,
        background:
          "linear-gradient(150deg, rgba(57,255,136,0.22), rgba(18,61,43,0.55) 55%, rgba(255,255,255,0.05))",
        boxShadow:
          "0 0 24px -6px rgba(57,255,136,0.5), inset 0 1px 0 rgba(255,255,255,0.35), inset 0 -8px 18px rgba(0,0,0,0.35)",
      }}
    >
      <svg
        viewBox="0 0 24 24"
        width={size * 0.56}
        height={size * 0.56}
        fill="none"
        aria-hidden="true"
      >
        <path
          d="M13.6 2.5 6 13.2h4.6L9.9 21.5 18 10.4h-4.9l.5-7.9Z"
          fill="url(#bgc-bolt)"
        />
        <defs>
          <linearGradient id="bgc-bolt" x1="6" y1="3" x2="18" y2="21" gradientUnits="userSpaceOnUse">
            <stop stopColor="#B9FFD4" />
            <stop offset="0.5" stopColor="#39FF88" />
            <stop offset="1" stopColor="#22C55E" />
          </linearGradient>
        </defs>
      </svg>
    </span>
  );
}

export function Wordmark({ className, size = "md" }) {
  const scale = { sm: "text-sm", md: "text-base", lg: "text-xl" }[size] ?? "text-base";
  return (
    <span className={cn("font-heading font-semibold tracking-[0.22em] text-bgc-ink", scale, className)}>
      BGC<span className="text-bgc-glow/90"> · </span>OPTIMIZER
    </span>
  );
}