import { CheckCircle2, CircleDashed, ListChecks } from "lucide-react";
import { GlassPanel } from "@/components/glass/GlassPanel";
import { cn } from "@/lib/utils";

export default function ChecklistSummary({ done = [], skipped = [], pending = [] }) {
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <GlassPanel className="p-5">
        <div className="flex items-center gap-2">
          <CheckCircle2 className="h-4 w-4 text-bgc-glow" />
          <p className="font-heading text-sm font-semibold text-bgc-ink">Ajustes verificados</p>
          <span className="ml-auto text-[11px] text-bgc-dim">{done.length}</span>
        </div>
        <div className="mt-3 space-y-1.5">
          {done.length === 0 ? (
            <p className="text-[12px] text-bgc-dim">Nenhum item verificado.</p>
          ) : (
            done.map((title, i) => (
              <p key={i} className="flex items-start gap-2 text-[12px] text-bgc-ink">
                <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-bgc-glow" />
                {title}
              </p>
            ))
          )}
        </div>
      </GlassPanel>

      <GlassPanel className="p-5">
        <div className="flex items-center gap-2">
          <CircleDashed className="h-4 w-4 text-amber-300" />
          <p className="font-heading text-sm font-semibold text-bgc-ink">Itens pendentes</p>
          <span className="ml-auto text-[11px] text-bgc-dim">{pending.length}</span>
        </div>
        <div className="mt-3 space-y-1.5">
          {pending.length === 0 ? (
            <p className="text-[12px] text-bgc-dim">Nenhum item pendente.</p>
          ) : (
            pending.map((title, i) => (
              <p key={i} className="flex items-start gap-2 text-[12px] text-bgc-ink">
                <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-amber-300" />
                {title}
              </p>
            ))
          )}
        </div>
      </GlassPanel>

      <GlassPanel className="p-5">
        <div className="flex items-center gap-2">
          <ListChecks className="h-4 w-4 text-bgc-dim" />
          <p className="font-heading text-sm font-semibold text-bgc-ink">Ignorados</p>
          <span className="ml-auto text-[11px] text-bgc-dim">{skipped.length}</span>
        </div>
        <div className="mt-3 space-y-1.5">
          {skipped.length === 0 ? (
            <p className="text-[12px] text-bgc-dim">Nenhum item ignorado.</p>
          ) : (
            skipped.map((title, i) => (
              <p key={i} className="flex items-start gap-2 text-[12px] text-bgc-dim">
                <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-bgc-dim" />
                {title}
              </p>
            ))
          )}
        </div>
      </GlassPanel>
    </div>
  );
}