import { ArrowDownRight, ArrowUpRight, Minus, TrendingUp, TrendingDown, Activity } from "lucide-react";
import { GlassPanel } from "@/components/glass/GlassPanel";
import { fmtMetric, summarizeComparison } from "@/lib/prepare";
import { cn } from "@/lib/utils";

export default function MetricCompareTable({ rows }) {
  const summary = summarizeComparison(rows);

  if (rows.length === 0) {
    return (
      <GlassPanel className="p-5">
        <div className="flex items-center gap-2">
          <Activity className="h-4 w-4 text-bgc-glow" />
          <p className="font-heading text-sm font-semibold text-bgc-ink">Comparação de métricas</p>
        </div>
        <p className="mt-3 text-xs leading-relaxed text-bgc-dim">
          Sem medições reais registradas antes e depois desta preparação. Registre uma sessão de monitoramento após jogar
          para habilitar a comparação — nenhum ganho é inventado.
        </p>
      </GlassPanel>
    );
  }

  return (
    <GlassPanel className="p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Activity className="h-4 w-4 text-bgc-glow" />
          <p className="font-heading text-sm font-semibold text-bgc-ink">Comparação real</p>
        </div>
        <div className="flex items-center gap-2 text-[11px]">
          <span className="inline-flex items-center gap-1 rounded-full border border-bgc-glow/30 bg-bgc-glow/10 px-2 py-0.5 text-bgc-glow">
            <TrendingUp className="h-3 w-3" /> {summary.improved} melhoraram
          </span>
          <span className="inline-flex items-center gap-1 rounded-full border border-rose-400/30 bg-rose-400/10 px-2 py-0.5 text-rose-300">
            <TrendingDown className="h-3 w-3" /> {summary.regressed} pioraram
          </span>
          <span className="inline-flex items-center gap-1 rounded-full border border-white/15 bg-white/5 px-2 py-0.5 text-bgc-dim">
            <Minus className="h-3 w-3" /> {summary.stable} estáveis
          </span>
        </div>
      </div>

      <div className="mt-4 overflow-x-auto">
        <table className="w-full min-w-[420px] border-collapse text-[12px]">
          <thead>
            <tr className="text-left text-[10px] uppercase tracking-wider text-bgc-dim">
              <th className="pb-2 font-medium">Métrica</th>
              <th className="pb-2 text-right font-medium">Antes</th>
              <th className="pb-2 text-right font-medium">Depois</th>
              <th className="pb-2 text-right font-medium">Variação</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => {
              const isUp = r.direction === "up";
              const isDown = r.direction === "down";
              const Icon = isUp ? ArrowUpRight : isDown ? ArrowDownRight : Minus;
              const tone = isUp ? "text-bgc-glow" : isDown ? "text-rose-300" : "text-bgc-dim";
              const sign = r.delta > 0 ? "+" : "";
              return (
                <tr key={r.key} className="border-t border-white/[0.06]">
                  <td className="py-2 font-medium text-bgc-ink">{r.label}</td>
                  <td className="py-2 text-right text-bgc-dim">{fmtMetric(r.before, r.unit)}</td>
                  <td className="py-2 text-right text-bgc-ink">{fmtMetric(r.after, r.unit)}</td>
                  <td className={cn("py-2 text-right font-medium", tone)}>
                    <span className="inline-flex items-center justify-end gap-1">
                      <Icon className="h-3 w-3" />
                      {sign}
                      {fmtMetric(Math.abs(r.delta), r.unit, r.unit === "ms" ? 2 : 0)}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </GlassPanel>
  );
}