import { Gauge } from "lucide-react";
import { GlassPanel } from "@/components/glass/GlassPanel";
import { fmtMetric, HARDWARE_FIELDS, METRIC_DEFS } from "@/lib/prepare";
import { fmtDateTime as fmtDT } from "@/lib/format";
import { cn } from "@/lib/utils";

function StateCard({ title, tone, icon: Icon, state, metric, hint }) {
  return (
    <GlassPanel className="p-5">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Icon className={cn("h-4 w-4", tone === "green" ? "text-bgc-glow" : tone === "amber" ? "text-amber-300" : "text-bgc-dim")} />
          <p className="font-heading text-sm font-semibold text-bgc-ink">{title}</p>
        </div>
        <span
          className={cn(
            "rounded-full border px-2 py-0.5 text-[10px] font-medium",
            state?.agent?.connected
              ? "border-bgc-glow/30 bg-bgc-glow/10 text-bgc-glow"
              : "border-amber-400/30 bg-amber-400/10 text-amber-300"
          )}
        >
          {state?.agent?.connected ? "Agente online" : "Agente offline"}
        </span>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2.5">
        {HARDWARE_FIELDS.map((f) => (
          <div key={f.key} className="rounded-lg border border-white/[0.06] bg-white/[0.02] px-2.5 py-1.5">
            <p className="text-[9px] uppercase tracking-wider text-bgc-dim">{f.label}</p>
            <p className="truncate text-[12px] font-medium text-bgc-ink">
              {state?.hardware?.[f.key] ? `${state.hardware[f.key]}${f.suffix ?? ""}` : "—"}
            </p>
          </div>
        ))}
      </div>

      <div className="mt-4">
        <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-bgc-dim">Métricas reais</p>
        {metric ? (
          <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
            {METRIC_DEFS.map((def) => (
              <div key={def.key} className="rounded-lg border border-white/[0.06] bg-white/[0.02] px-2.5 py-1.5">
                <p className="text-[9px] uppercase tracking-wider text-bgc-dim">{def.label}</p>
                <p className="text-[13px] font-semibold text-bgc-ink">{fmtMetric(metric[def.key], def.unit)}</p>
              </div>
            ))}
          </div>
        ) : (
          <div className="rounded-xl border border-white/[0.08] bg-white/[0.02] p-3">
            <p className="text-[12px] text-bgc-dim">
              {hint ?? "Nenhuma medição real registrada neste momento. Conecte o agente Windows e registre uma sessão de monitoramento."}
            </p>
          </div>
        )}
        {metric?.recorded_at && (
          <p className="mt-2 text-[10px] text-bgc-dim/70">Medição de {fmtDT(metric.recorded_at)}</p>
        )}
      </div>
    </GlassPanel>
  );
}

export default function BeforeAfterCards({ before, after, afterDate }) {
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <StateCard
        title="Antes"
        tone="amber"
        icon={Gauge}
        state={before}
        metric={before?.metric ?? null}
        hint="Nenhuma medição real registrada antes desta preparação."
      />
      <StateCard
        title="Depois"
        tone="green"
        icon={Gauge}
        state={before}
        metric={after ?? null}
        hint={
          afterDate
            ? "Nenhuma medição real registrada após a preparação ainda. Registre uma sessão de monitoramento após jogar para comparar."
            : "Aguardando medição pós-preparação. Jogue e registre uma sessão de monitoramento para habilitar a comparação."
        }
      />
    </div>
  );
}