import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { ArrowLeft, History, Rocket, ShieldAlert } from "lucide-react";
import PageHeader from "@/components/glass/PageHeader";
import { GlassPanel } from "@/components/glass/GlassPanel";
import StatusPill from "@/components/glass/StatusPill";
import ActionButton from "@/components/glass/ActionButton";
import BeforeAfterCards from "@/components/prepare/BeforeAfterCards";
import MetricCompareTable from "@/components/prepare/MetricCompareTable";
import ChecklistSummary from "@/components/prepare/ChecklistSummary";
import { PROFILE_KINDS } from "@/lib/constants";
import { fetchLatestGameMetricAfter } from "@/lib/queries";
import { compareMetrics } from "@/lib/prepare";
import { fmtDateTime, fmtRelative } from "@/lib/format";

export default function PrepareResult({ session }) {
  const before = session?.before_state ? JSON.parse(session.before_state) : null;
  const gameName = session?.game_name;

  const { data: afterMetric, isLoading } = useQuery({
    queryKey: ["after-metric", session?.id],
    queryFn: () => fetchLatestGameMetricAfter(gameName, session.started_at),
    enabled: !!session?.id && !!gameName,
  });

  if (!session) {
    return (
      <GlassPanel className="p-8 text-center">
        <p className="text-sm text-bgc-dim">Sessão não encontrada.</p>
        <Link to="/sessoes" className="mt-2 inline-block text-[12px] text-bgc-glow hover:underline">
          Ver histórico de sessões →
        </Link>
      </GlassPanel>
    );
  }

  const beforeMetric = before?.metric ?? null;
  const rows = compareMetrics(beforeMetric, afterMetric ?? null);
  const hasComparison = rows.length > 0;
  const agentConnected = before?.agent?.connected ?? false;
  const kindLabel = PROFILE_KINDS[session.profile_kind]?.label ?? session.profile_kind ?? "—";

  return (
    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
      <Link to="/booster/$gameId" params={{ gameId: session.game_id }} className="inline-flex items-center gap-2 text-[11px] font-medium text-bgc-dim transition hover:text-bgc-ink">
        <ArrowLeft className="h-3.5 w-3.5" /> Voltar ao jogo
      </Link>

      <PageHeader
        eyebrow="Resumo da preparação"
        title={session.game_name}
        description={`Sessão registrada em ${fmtDateTime(session.completed_at ?? session.started_at)} · perfil ${kindLabel}`}
        actions={
          <Link to="/sessoes">
            <ActionButton size="sm" variant="ghost">
              <History className="h-3.5 w-3.5" /> Histórico de sessões
            </ActionButton>
          </Link>
        }
      />

      <div className="mb-5 flex flex-wrap items-center gap-2">
        <StatusPill tone="green">{session.checklist_done?.length ?? 0} verificados</StatusPill>
        <StatusPill tone="yellow">{session.checklist_pending?.length ?? 0} pendentes</StatusPill>
        <StatusPill tone="gray">{session.checklist_skipped?.length ?? 0} ignorados</StatusPill>
        <StatusPill tone={agentConnected ? "green" : "amber"}>
          {agentConnected ? "Agente conectado" : "Agente offline"}
        </StatusPill>
        <StatusPill tone={hasComparison ? "green" : "gray"}>
          {hasComparison ? "Comparação real disponível" : "Sem comparação real ainda"}
        </StatusPill>
      </div>

      <BeforeAfterCards before={before} after={afterMetric ?? null} afterDate={!!afterMetric} />

      <div className="mt-5">
        {isLoading ? (
          <GlassPanel className="p-5">
            <p className="text-[12px] text-bgc-dim">Buscando medição pós-preparação…</p>
          </GlassPanel>
        ) : (
          <MetricCompareTable rows={rows} />
        )}
      </div>

      {!hasComparison && !isLoading && (
        <div className="mt-4 rounded-xl border border-bgc-glow/20 bg-bgc-glow/[0.05] p-4">
          <p className="flex items-start gap-2 text-[12px] leading-relaxed text-bgc-ink/85">
            <Rocket className="mt-0.5 h-3.5 w-3.5 shrink-0 text-bgc-glow" />
            Para ver a comparação real, jogue este jogo e registre uma sessão de monitoramento. Assim que houver uma
            medição posterior a {fmtRelative(session.started_at)}, o antes/depois aparece automaticamente aqui — sem
            inventar ganhos.
          </p>
        </div>
      )}

      <div className="mt-5">
        <ChecklistSummary
          done={session.adjustments ?? []}
          pending={session.pending_items ?? []}
          skipped={session.checklist_skipped ?? []}
        />
      </div>

      <div className="mt-5">
        <GlassPanel className="p-4">
          <p className="flex items-start gap-2 text-[11px] leading-relaxed text-amber-200/90">
            <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            Checklist concluído registra que você verificou os ajustes dentro do aplicativo. Não equivale a uma
            otimização aplicada no Windows — para isso é necessário o agente nativo conectado.
          </p>
        </GlassPanel>
      </div>
    </div>
  );
}