import { Link } from "@tanstack/react-router";
import { CircleAlert, Gamepad2, Layers, Plug, Sparkles } from "lucide-react";
import { GlassPanel } from "@/components/glass/GlassPanel";
import StatusPill from "@/components/glass/StatusPill";
import { PROFILE_KINDS } from "@/lib/constants";
import { fmtRelative } from "@/lib/format";

export default function OverviewSidebar({ active, computer, gameCount, pending, recommendations }) {
  const kind = active ? PROFILE_KINDS[active.kind] : null;

  return (
    <div className="space-y-4">
      <GlassPanel className="p-5">
        <div className="flex items-center justify-between">
          <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-bgc-dim">Perfil atual</p>
          <Layers className="h-4 w-4 text-bgc-glow" />
        </div>
        {active ? (
          <>
            <p className="mt-2 font-heading text-lg font-semibold text-bgc-ink">{active.name}</p>
            <p className="mt-1 text-xs leading-relaxed text-bgc-dim">{kind?.description}</p>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <StatusPill tone="green" dot>
                Ativo
              </StatusPill>
              <StatusPill tone="gray">{(active.settings ?? []).length} ajustes</StatusPill>
            </div>
          </>
        ) : (
          <p className="mt-2 text-sm text-bgc-dim">Nenhum perfil criado ainda.</p>
        )}
        <Link to="/perfis" className="mt-4 inline-block text-[11px] font-medium text-bgc-glow hover:underline">
          Gerenciar perfis →
        </Link>
      </GlassPanel>

      <GlassPanel className="p-5">
        <div className="flex items-center justify-between">
          <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-bgc-dim">Estado do sistema</p>
          <Plug className="h-4 w-4 text-bgc-glow" />
        </div>
        <div className="mt-3 space-y-2.5 text-sm">
          <div className="flex items-center justify-between gap-2">
            <span className="text-bgc-dim">Computador</span>
            <span className="truncate text-bgc-ink">{computer?.name || "Não cadastrado"}</span>
          </div>
          <div className="flex items-center justify-between gap-2">
            <span className="text-bgc-dim">Conexão</span>
            <StatusPill tone={computer?.connection_state === "connected" ? "green" : "gray"} dot>
              {computer?.connection_state === "connected" ? "Conectado" : "Aguardando conexão"}
            </StatusPill>
          </div>
          <div className="flex items-center justify-between gap-2">
            <span className="text-bgc-dim">Última sincronização</span>
            <span className="text-bgc-ink">{computer?.last_sync ? fmtRelative(computer.last_sync) : "—"}</span>
          </div>
          <div className="flex items-center justify-between gap-2">
            <span className="text-bgc-dim">Jogos cadastrados</span>
            <span className="flex items-center gap-1.5 text-bgc-ink">
              <Gamepad2 className="h-3.5 w-3.5 text-bgc-dim" /> {gameCount}
            </span>
          </div>
        </div>
        <Link to="/hardware" className="mt-4 inline-block text-[11px] font-medium text-bgc-glow hover:underline">
          Ver hardware →
        </Link>
      </GlassPanel>

      <GlassPanel className="p-5">
        <div className="flex items-center justify-between">
          <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-bgc-dim">
            Recomendações pendentes
          </p>
          {pending > 0 ? (
            <CircleAlert className="h-4 w-4 text-amber-300" />
          ) : (
            <Sparkles className="h-4 w-4 text-bgc-glow" />
          )}
        </div>
        <p className="mt-2 font-heading text-2xl font-semibold text-bgc-ink">{pending}</p>
        <div className="mt-2 space-y-2">
          {recommendations.slice(0, 2).map((r) => (
            <p key={r.id} className="line-clamp-2 text-xs leading-relaxed text-bgc-dim">
              · {r.title}
            </p>
          ))}
          {pending === 0 && <p className="text-xs text-bgc-dim">Tudo aplicado no seu perfil ativo.</p>}
        </div>
        <Link to="/otimizacoes" className="mt-4 inline-block text-[11px] font-medium text-bgc-glow hover:underline">
          Ver otimizações →
        </Link>
      </GlassPanel>
    </div>
  );
}