import { Cpu, HardDrive, MemoryStick, MonitorPlay } from "lucide-react";
import { GlassPanel } from "@/components/glass/GlassPanel";
import StatusPill from "@/components/glass/StatusPill";
import { fmtNumber } from "@/lib/format";
import { cn } from "@/lib/utils";

const AWAIT = "Aguardando conexão";

function StatRow({ label, value, muted }) {
  return (
    <div className="flex items-baseline justify-between gap-3 py-1">
      <span className="text-[11px] uppercase tracking-wider text-bgc-dim/80">{label}</span>
      <span className={cn("truncate font-mono text-[12px]", muted ? "text-bgc-dim/70" : "text-bgc-ink")}>
        {value}
      </span>
    </div>
  );
}

function HardwareCard({ icon: Icon, label, model, live, rows, accent }) {
  return (
    <GlassPanel hover className="p-4">
      <div className="flex items-start justify-between gap-2">
        <span
          className="flex h-9 w-9 items-center justify-center rounded-xl border"
          style={{
            borderColor: `${accent}44`,
            background: `${accent}18`,
            color: accent,
            boxShadow: `0 0 22px -8px ${accent}`,
          }}
        >
          <Icon className="h-4 w-4" />
        </span>
        <StatusPill tone={live ? "green" : "gray"} dot={live}>
          {live ? "Ao vivo" : "Offline"}
        </StatusPill>
      </div>
      <p className="mt-3 text-[11px] font-medium uppercase tracking-[0.2em] text-bgc-dim">{label}</p>
      <p className="mt-1 truncate font-heading text-sm font-semibold text-bgc-ink" title={model}>
        {model || "Não informado"}
      </p>
      <div className="mt-3 border-t border-white/[0.07] pt-2">{rows}</div>
    </GlassPanel>
  );
}

export default function HardwareOverview({ computer }) {
  const live = computer?.connection_state === "connected";

  const cards = [
    {
      icon: Cpu,
      label: "Processador",
      accent: "#22C55E",
      model: computer?.cpu_model,
      rows: (
        <>
          <StatRow label="Utilização" value={live ? "—" : AWAIT} muted={!live} />
          <StatRow label="Temperatura" value={live ? "—" : AWAIT} muted={!live} />
          <StatRow label="Frequência" value={live ? "—" : AWAIT} muted={!live} />
          <StatRow label="Núcleos" value={computer?.cpu_cores ? `${computer.cpu_cores} núcleos` : "—"} />
        </>
      ),
    },
    {
      icon: MonitorPlay,
      label: "Placa de vídeo",
      accent: "#38BDF8",
      model: computer?.gpu_model,
      rows: (
        <>
          <StatRow label="Utilização" value={live ? "—" : AWAIT} muted={!live} />
          <StatRow label="Temperatura" value={live ? "—" : AWAIT} muted={!live} />
          <StatRow label="VRAM" value={computer?.gpu_vram_gb ? `${fmtNumber(computer.gpu_vram_gb)} GB` : "—"} />
        </>
      ),
    },
    {
      icon: MemoryStick,
      label: "Memória RAM",
      accent: "#A78BFA",
      model: computer?.ram_gb ? `${fmtNumber(computer.ram_gb)} GB` : "Não informado",
      rows: (
        <>
          <StatRow label="Em uso" value={live ? "—" : AWAIT} muted={!live} />
          <StatRow label="Disponível" value={live ? "—" : AWAIT} muted={!live} />
          <StatRow label="Frequência" value={computer?.ram_speed_mhz ? `${computer.ram_speed_mhz} MHz` : "—"} />
        </>
      ),
    },
    {
      icon: HardDrive,
      label: "Armazenamento",
      accent: "#F59E0B",
      model: computer?.storage_label || computer?.storage_type,
      rows: (
        <>
          <StatRow
            label="Livre"
            value={
              computer?.free_space_gb
                ? `${fmtNumber(computer.free_space_gb)} GB${computer.total_space_gb ? ` / ${fmtNumber(computer.total_space_gb)} GB` : ""}`
                : "—"
            }
          />
          <StatRow label="Saúde" value={computer?.storage_health ? `${fmtNumber(computer.storage_health)}%` : "—"} />
          <StatRow label="Temperatura" value={live ? "—" : AWAIT} muted={!live} />
        </>
      ),
    },
  ];

  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {cards.map((card) => (
        <HardwareCard key={card.label} {...card} live={live} />
      ))}
    </div>
  );
}