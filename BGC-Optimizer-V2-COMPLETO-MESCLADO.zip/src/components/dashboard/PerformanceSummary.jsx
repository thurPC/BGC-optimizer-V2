import { Activity, ArrowUpRight, Gauge } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { GlassPanel } from "@/components/glass/GlassPanel";
import EmptyState from "@/components/glass/EmptyState";
import StatusPill from "@/components/glass/StatusPill";
import { fmtNumber } from "@/lib/format";

function ChartTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-xl border border-white/12 bg-[#0A0F18]/95 px-3 py-2 text-xs backdrop-blur-xl">
      <p className="mb-1 font-medium text-bgc-ink">{label}</p>
      {payload.map((p) => (
        <p key={p.dataKey} className="text-bgc-dim">
          <span className="mr-2 inline-block h-2 w-2 rounded-full" style={{ background: p.color }} />
          {p.name}: <span className="font-mono text-bgc-ink">{fmtNumber(p.value, 0)}</span>
        </p>
      ))}
    </div>
  );
}

export default function PerformanceSummary({ sessions }) {
  const chartData = [...sessions]
    .slice(0, 10)
    .reverse()
    .map((s) => ({
      name: s.game_name?.slice(0, 12) || "Sessão",
      fps: s.fps_avg,
      low: s.fps_1_low,
    }));

  const latest = sessions[0];

  return (
    <GlassPanel className="p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-bgc-dim">Resumo de desempenho</p>
          <p className="mt-1 font-heading text-lg font-semibold text-bgc-ink">Histórico de sessões</p>
        </div>
        <Link
          to="/monitoramento"
          className="inline-flex items-center gap-1 text-[11px] font-medium text-bgc-glow transition hover:text-bgc-glow/80"
        >
          Monitoramento <ArrowUpRight className="h-3 w-3" />
        </Link>
      </div>

      {sessions.length === 0 ? (
        <div className="mt-4">
          <EmptyState
            icon={Gauge}
            tone="base"
            title="Nenhuma sessão registrada"
            description="Registre suas medições no monitoramento para acompanhar a evolução de FPS, 1% low e frametime."
            className="border-none bg-transparent px-0 py-8"
            action={
              <Link to="/monitoramento" className="text-xs font-medium text-bgc-glow hover:underline">
                Registrar primeira sessão
              </Link>
            }
          />
        </div>
      ) : (
        <>
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              { label: "FPS médio", value: latest?.fps_avg },
              { label: "1% low", value: latest?.fps_1_low },
              { label: "0,1% low", value: latest?.fps_01_low },
              { label: "Frametime", value: latest?.frametime_ms, suffix: " ms" },
            ].map((item) => (
              <div key={item.label} className="rounded-xl border border-white/[0.08] bg-white/[0.03] p-3">
                <p className="text-[10px] uppercase tracking-wider text-bgc-dim">{item.label}</p>
                <p className="mt-1 font-mono text-lg text-bgc-ink">
                  {item.value === undefined || item.value === null ? "—" : `${fmtNumber(item.value)}${item.suffix ?? ""}`}
                </p>
              </div>
            ))}
          </div>

          <div className="mt-5 h-[190px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 4, right: 4, bottom: 0, left: -22 }}>
                <defs>
                  <linearGradient id="fpsFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#39FF88" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="#39FF88" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="lowFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#38BDF8" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#38BDF8" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
                <XAxis dataKey="name" tick={{ fill: "#94A3B8", fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "#94A3B8", fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip content={<ChartTooltip />} />
                <Area type="monotone" dataKey="fps" name="FPS médio" stroke="#39FF88" strokeWidth={2} fill="url(#fpsFill)" />
                <Area type="monotone" dataKey="low" name="1% low" stroke="#38BDF8" strokeWidth={1.5} fill="url(#lowFill)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <p className="mt-2 flex items-center gap-2 text-[10px] uppercase tracking-wider text-bgc-dim/70">
            <Activity className="h-3 w-3" /> Sessões registradas manualmente por você
          </p>
        </>
      )}
    </GlassPanel>
  );
}