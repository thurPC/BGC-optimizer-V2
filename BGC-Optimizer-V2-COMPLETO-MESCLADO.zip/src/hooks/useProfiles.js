const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";

import { BUILT_IN_PROFILES } from "@/lib/constants";
import { optimizationProfilesQuery } from "@/lib/queries";

/** Creates the five built-in performance profiles the first time a user opens the app. */
export function useEnsureProfiles() {
  const queryClient = useQueryClient();
  const { data: profiles = [], isLoading } = useQuery(optimizationProfilesQuery());
  const [seeding, setSeeding] = useState(false);

  useEffect(() => {
    if (isLoading || seeding || profiles.length > 0) return;
    setSeeding(true);
    db.entities.OptimizationProfile.bulkCreate(
      BUILT_IN_PROFILES.map((p, index) => ({
        ...p,
        built_in: true,
        is_active: index === 0,
      }))
    )
      .then(() => queryClient.invalidateQueries({ queryKey: ["optimization-profiles"] }))
      .finally(() => setSeeding(false));
  }, [isLoading, profiles.length, seeding, queryClient]);

  const active = profiles.find((p) => p.is_active) ?? profiles[0] ?? null;
  return { profiles, active, isLoading: isLoading || seeding };
}